from flask import Flask, request, jsonify, render_template, flash
import database as db
import hashlib

app = Flask(__name__)

# USER ROUTES ==========================================================================
@app.route("/loginUser", methods=["POST"])
def loginUser():
    if request.method == "POST":
        username = request.form.get("username")
        passHash = request.form.get("passHash")
        return str(db.loginUser(username, passHash))

@app.route("/createUser", methods = ["POST"])
def createUser():
    if request.method == "POST":
        username = request.form.get("username")
        passHash = request.form.get("passHash")
        email = request.form.get("email")
        return str(db.createUser(username, passHash, email))

@app.route("/deleteUser", methods = ["POST"])
def deleteUser():
    if request.method == "POST":
        userID = int(request.form.get("userID"))
        return str(db.deleteUser(userID))

@app.route("/getUser", methods=["POST"]) # THIS IS SO THAT I CAN PUT IT ON WELCOME PAGE
def getUser():
    username = request.form.get("username")
    if not username:
        return jsonify({"error": "username required"}), 400

    user = db.getUserByUsername(username)
    if not user:
        return jsonify({"error": "not found"}), 404

    # user = (userID, username, emailAddress)
    return jsonify({
        "userID": user[0],
        "username": user[1],
        "email": user[2]
    })

@app.route("/forgotPassword", methods=["POST"])
def forgotPassword():
    username = request.form.get("username")
    if not username:
        return jsonify({"ok": False, "error": "username required"}), 400

    user = db.getUserByUsername(username)
    if not user:
        return jsonify({"ok": False, "error": "not found"}), 404

    # user = (userID, username, emailAddress)
    return jsonify({
        "ok": True,
        "email": user[2] 
    })

@app.route("/resetPassword", methods=["POST"])
def resetPassword():
    username = request.form.get("username")
    new_pass = request.form.get("passHash")
    updated = db.updateUserPassword(username, new_pass)

    if not username or not new_pass:
        return jsonify({"ok": False, "error": "username and passHash required"}), 400

    updated = db.updateUserPassword(username, new_pass)
    if updated:
        return jsonify({"ok": True})
    else:
        return jsonify({"ok": False, "error": "user not found"}), 404


# GROUPS ROUTES ========================================================================
@app.route("/getGroups", methods=["POST"])
def getGroups():
    userID = int(request.form.get("userID"))
    groups = db.getGroups(userID) 
    items = [
        {
            "groupID": g[0],
            "name": g[1],
            "leaderID": g[2]
        }
        for g in groups
    ]
    return jsonify({"items": items})

@app.route("/getGroupMembers", methods = ["POST"])
def getGroupMembers():
    if request.method == "POST":
        groupID = int(request.form.get("groupID"))
        users = db.getGroupMembers(groupID)
        output = ""
        for user in users:
            output += str(user)
        return output

@app.route("/createGroup", methods = ["POST"])
def createGroup():
    if request.method == "POST":
        name = request.form.get("name")
        leaderID = int(request.form.get("leaderID"))
        return str(db.createGroup(name, leaderID))

@app.route("/addMember2Group", methods = ["POST"])
def addMember2Group():
    if request.method == "POST":
        groupID = int(request.form.get("groupID"))
        userID = int(request.form.get("userID"))
        return str(db.addMember2Group(groupID, userID))

@app.route("/deleteGroup", methods = ["POST"])
def deleteGroup():
    if request.method == "POST":
        groupID = int(request.form.get("groupID"))
        return str(db.deleteGroup(groupID))
    
#User logins in then gets added to target group
@app.route("/joinGroup/<groupID>", methods = ["GET", "POST"])
def joinGroup(groupID = None):
    if request.method == "GET":
        print('launch')
        return render_template("joinGroup.html", groupID = groupID)
    elif request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        print((username, password))
        # password = password.encode()
        # password = hashlib.sha256(password).hexdigest()
        
        loggedIn = db.loginUser(username, password)
        if loggedIn:
            userID = db.getUserID(username)[0]
            db.addMember2Group(groupID, userID)
            print("logged in")
            return render_template("joined.html")
        else:
            print(":(")
            return render_template("joinGroup.html", groupID = groupID)

# ROUTES FOR MOVIE INFORMATION ==================================================================

@app.route("/movies", methods=["GET"])
def list_movies():
    search = request.args.get("search", "").strip()
    limit = int(request.args.get("limit", "20"))
    offset = int(request.args.get("offset", "0"))

    conn, c = db.openConnection()
    if search:
        c.execute("""
            SELECT movieID, title, rating, release
            FROM movies
            WHERE title LIKE ?
            ORDER BY rating DESC
            LIMIT ? OFFSET ?;
        """, (f"%{search}%", limit, offset))
    else:
        c.execute("""
            SELECT movieID, title, rating, release
            FROM movies
            ORDER BY rating DESC
            LIMIT ? OFFSET ?;
        """, (limit, offset))
    rows = c.fetchall()

  
    if search:
        c.execute("SELECT COUNT(*) FROM movies WHERE title LIKE ?;", (f"%{search}%",))
    else:
        c.execute("SELECT COUNT(*) FROM movies;")
    total = c.fetchone()[0]

    db.closeConnection(c, conn)
    data = [
        {"movieID": r[0], "title": r[1], "rating": r[2], "release": r[3]}
        for r in rows
    ]
    return jsonify({"total": total, "items": data})

@app.route("/movie/<int:movie_id>", methods=["GET"])
def get_movie(movie_id):
    conn, c = db.openConnection()
    c.execute("SELECT movieID, title, overview, rating, release FROM movies WHERE movieID = ?;", (movie_id,))
    row = c.fetchone()
    db.closeConnection(c, conn)
    if not row:
        return jsonify({"error": "not found"}), 404
    return jsonify({"movieID": row[0], "title": row[1], "overview": row[2], "rating": row[3], "release": row[4]})

@app.route("/movie/<int:movie_id>/rate", methods=["POST"])
def rate_movie(movie_id):
    new_rating = request.json.get("rating", None)
    if new_rating is None:
        return jsonify({"error": "rating required"}), 400

    conn, c = db.openConnection()
    c.execute("UPDATE movies SET rating = ? WHERE movieID = ?;", (float(new_rating), movie_id))
    conn.commit()
    db.closeConnection(c, conn)
    return jsonify({"ok": True})

@app.route("/genres", methods=["GET"])
def list_genres():
    conn, c = db.openConnection()
    c.execute("SELECT DISTINCT genre FROM genreMovieRelation ORDER BY genre;")
    rows = c.fetchall()
    db.closeConnection(c, conn)
    genres = [r[0] for r in rows]
    return jsonify({"genres": genres})

@app.route("/moviesByGenre", methods=["GET"])
def movies_by_genre():
    genre = request.args.get("genre", "").strip()
    if not genre:
        return jsonify({"items": []})

    conn, c = db.openConnection()
    # join movies with genreMovieRelation
    c.execute("""
        SELECT m.movieID, m.title, m.rating, m.release
        FROM movies m
        JOIN genreMovieRelation g ON m.movieID = g.movieID
        WHERE g.genre = ?
        ORDER BY m.rating DESC;
    """, (genre,))
    rows = c.fetchall()
    db.closeConnection(c, conn)

    items = [
        {
            "movieID": r[0],
            "title": r[1],
            "rating": r[2],
            "release": r[3],
        }
        for r in rows
    ]
    return jsonify({"items": items})

# EVENTS --> FOR SCHEDULES ==================================================================
@app.route("/getEvents", methods=["POST"])
def get_events():
    user_id = request.form.get("userID", type=int)
    if user_id is None:
        rows = db.getEvents()
    else:
        rows = db.getEventsForUser(user_id)

    items = [
        {
            "eventID": r[0],
            "title": r[1],
            "date": r[2]
        }
        for r in rows
    ]
    return jsonify({"items": items})


@app.route("/addEvent", methods=["POST"])
def add_event():
    title = request.form.get("title")
    date_str = request.form.get("date")
    user_id = request.form.get("userID", type=int)

    if not (title and date_str):
        return "False"

    if user_id is not None:
        ok = db.addEventForUser(user_id, title, date_str)
        return str(ok)

    ok = db.addEvent(title, date_str)
    return str(ok)


@app.route("/deleteEvent", methods=["POST"])
def delete_event():
    event_id = request.form.get("eventID")
    if not event_id:
        return "False"
    ok = db.deleteEvent(int(event_id))
    return str(ok)

@app.route("/updateEvent", methods=["POST"])
def update_event():
    event_id = request.form.get("eventID")
    title = request.form.get("title")
    date_str = request.form.get("date")

    if not (event_id and title and date_str):
        return "False"

    ok = db.updateEvent(int(event_id), title, date_str)
    return str(ok)

# WatchLists ==================================================================
@app.route("/getWatchList", methods = ["POST"])
def getWatchList():
    ownerID = request.form.get("ownerID")
    isGroupList = request.form.get("isGroupList")
    isAntiList = request.form.get("isAntiList")
    
    if not (ownerID and isGroupList and isAntiList):
        rows = []
    else:
        ownerID = int(ownerID)
        
        if isGroupList == "true":
            isGroupList = True
        else:
            isGroupList = False
        
        if isAntiList == "true":
            isAntiList = True
        else:
            isAntiList = False
        
        rows = db.getWatchList(ownerID, isGroupList, isAntiList)
    items = [{"movieID": row[0], "title": row[1], "rating": row[2], "release": row[3]} for row in rows]
    return jsonify({items: items})

@app.route("/add2WatchList", methods = ["POST"])
def add2WatchList():
    ownerID = request.form.get("ownerID")
    movieID = request.form.get("movieID")
    isGroupList = request.form.get("isGroupList")
    isAntiList = request.form.get("isAntiList")

    if not(ownerID and movieID and isGroupList and isAntiList):
        return "False"
    else:
        ownerID = int(ownerID)
        movieID = int(movieID)

        if isGroupList == "true":
            isGroupList = True
        else:
            isGroupList = False
        
        if isAntiList == "true":
            isAntiList = True
        else:
            isAntiList = False
    result = db.add2WatchList(ownerID, movieID, isGroupList, isAntiList)
    return str(result)

@app.route("/removeFromWatchList", methods = ["POST"])
def removeFromWatchList():
    ownerID = request.form.get("ownerID")
    movieID = request.form.get("movieID")
    isGroupList = request.form.get("isGroupList")
    isAntiList = request.form.get("isAntiList")

    if not(ownerID and movieID and isGroupList and isAntiList):
        return "False"
    else:
        ownerID = int(ownerID)
        movieID = int(movieID)

        if isGroupList == "true":
            isGroupList = True
        else:
            isGroupList = False
        
        if isAntiList == "true":
            isAntiList = True
        else:
            isAntiList = False
    result = db.removeFromWatchList(ownerID, movieID, isGroupList, isAntiList)
    return str(result)

if __name__ == "__main__":
    app.run(debug = app.debug, host = "0.0.0.0", port=8097)


import sqlite3
import json
import csv
import re

ENCODING = "utf8"
DATABASE_NAME = "movieWatchNight.db"
MOVIES_FILENAME = "movies_metadata.json"
CLEANED_MOVIES = "cleanedMovies.json"

# OPENING AND CLOSING CONNECTIONS ===================================
def openConnection():
    connection = sqlite3.connect(DATABASE_NAME)
    cursor = connection.cursor()
    return connection, cursor

def closeConnection(cursor, connection):
    if cursor is not None:
        cursor.close()
    if connection is not None:
        connection.close()

def createTables():
    conn, c = openConnection()
    commands = []

    # USERS
    commandString = """CREATE TABLE users (
        userID INTEGER PRIMARY KEY AUTOINCREMENT,
        username text UNIQUE,
        passHash text,
        emailAddress text
    );
    """
    commands.append(commandString)

    # MOVIES
    commandString = """CREATE TABLE movies (
        movieID int PRIMARY KEY,
        title text,
        overview text,
        rating float,
        release date
    );
    """
    commands.append(commandString)

    # USER WATCHLIST
    commandString = """CREATE TABLE userWatchList (
        userID int,
        movieID int,
        FOREIGN KEY (userID) REFERENCES users(userID),
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # USER ANTI-WATCHLIST 
    commandString = """CREATE TABLE userAntiWatchList (
        userID int,
        movieID int,
        FOREIGN KEY (userID) REFERENCES users(userID),
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # GROUPS
    commandString = """CREATE TABLE groups (
        groupID INTEGER PRIMARY KEY AUTOINCREMENT,
        groupName text,
        leaderID int,
        FOREIGN KEY (leaderID) REFERENCES users(userID)
    );
    """
    commands.append(commandString)

    # GROUP MEMBER RELATION
    commandString = """CREATE TABLE groupMemberRelation (
        groupID int,
        userID int,
        vote int,
        FOREIGN KEY (groupID) REFERENCES groups(groupID),
        FOREIGN KEY (userID) REFERENCES users(userID),
        FOREIGN KEY (vote) REFERENCES movies(movieID),
        PRIMARY KEY (groupID, userID)
    );
    """
    commands.append(commandString)

    # GROUP WATCHLIST
    commandString = """CREATE TABLE groupWatchList (
        groupID int,
        movieID int,
        FOREIGN KEY (groupID) REFERENCES groups(groupID),
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # GROUP ANTI-WATCHLIST 
    commandString = """CREATE TABLE groupAntiWatchList (
        groupID int,
        movieID int,
        FOREIGN KEY (groupID) REFERENCES groups(groupID),
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # GENRE ↔ MOVIE
    commandString = """CREATE TABLE genreMovieRelation (
        movieID int,
        genre text,
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # EVENTS
    commandString = """CREATE TABLE events (
        eventID INTEGER PRIMARY KEY AUTOINCREMENT,
        title text,
        date date
    );
    """
    commands.append(commandString)

    # GROUP ↔ EVENT
    commandString = """CREATE TABLE groupEventRelation (
        groupID int,
        eventID int,
        FOREIGN KEY (eventID) REFERENCES events(eventID),
        FOREIGN KEY (groupID) REFERENCES groups(groupID)
    );
    """
    commands.append(commandString)

    # USER ↔ EVENT
    commandString = """CREATE TABLE userEventRelation (
        userID int,
        eventID int,
        FOREIGN KEY (userID) REFERENCES users(userID),
        FOREIGN KEY (eventID) REFERENCES events(eventID)
    );
    """
    commands.append(commandString)

    for command in commands:
        c.execute(command)

    conn.commit()
    closeConnection(c, conn)


# USER SECTION =================================================
def loginUser(username: str, passwordHash: str) -> bool:
    conn, c = openConnection()

    commandString = f"SELECT COUNT(*) FROM users \
                      WHERE username = '{username}' AND passHash = '{passwordHash}'"
    c.execute(commandString)
    result = c.fetchone()
    closeConnection(c, conn)
    if result[0] == 1:
        return True
    else:
        return False

def createUser(username: str, passwordHash: str, emailAddress: str) -> bool:
    conn, c = openConnection()
    try:
        commandString = f"INSERT INTO users (username, passHash, emailAddress) \
                        VALUES ('{username}', '{passwordHash}', '{emailAddress}');"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    return True
    
def deleteUser(userID: int) -> bool:
    conn, c = openConnection()

    try:
        commandString = f"DELETE FROM groupMemberRelation \
                          WHERE userID = {userID}"
        c.execute(commandString)

        commandString = f"DELETE FROM groups \
                          WHERE leaderID = {userID}"
        c.execute(commandString)

        commandString = f"DELETE FROM users \
                          WHERE userID = {userID}"
        c.execute(commandString)

        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    
def getUserByUsername(username: str):
    conn, c = openConnection()
    c.execute(
        "SELECT userID, username, emailAddress FROM users WHERE username = ?;",
        (username,)
    )
    row = c.fetchone()
    closeConnection(c, conn)
    return row 

def updateUserPassword(username: str, new_pass_hash: str) -> bool:
    conn, c = openConnection()
    c.execute(
        "UPDATE users SET passHash = ? WHERE username = ?;",
        (new_pass_hash, username)
    )
    conn.commit()
    changed = c.rowcount 
    closeConnection(c, conn)
    return changed == 1

def getUserID(username: str) -> int:
    conn, c = openConnection()
    commandString = f"SELECT userID FROM users WHERE username == '{username}';"
    c.execute(commandString)
    result = c.fetchall()
    return result[0]

# GROUPS SECTION =======================================
def getGroups(userID: int) -> list:
    conn, c = openConnection()
    c.execute("""
        SELECT g.groupID, g.groupName, g.leaderID
        FROM groups g
        JOIN groupMemberRelation r ON g.groupID = r.groupID
        WHERE r.userID = ?
        ORDER BY g.groupID ASC;
    """, (userID,))
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

def getGroupMembers(groupID: int) -> list:
    conn, c = openConnection()

    commandString = f"SELECT groupID FROM groupMemberRelation \
                      WHERE groupID = {groupID};"
    c.execute(commandString)
    output = c.fetchall()
    closeConnection(c, conn)
    return output

def createGroup(name: str, leaderID: int) -> bool:
    conn, c = openConnection()
    try:
        # create the group
        c.execute(
            "INSERT INTO groups (groupName, leaderID) VALUES (?, ?);",
            (name, leaderID)
        )
        group_id = c.lastrowid

        # automatically add the leader as a member
        c.execute(
            "INSERT INTO groupMemberRelation (groupID, userID) VALUES (?, ?);",
            (group_id, leaderID)
        )

        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

def addMember2Group(groupID: int, userID: int) -> bool:
    conn, c = openConnection()
    try:
        commandString = f"INSERT INTO groupMemberRelation (groupID, userID) \
                        VALUES ({groupID}, {userID});"
        print(commandString)
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

def deleteGroup(groupID: int) -> bool:
    conn, c = openConnection()
    try:
        commandString = f"DELETE FROM groupMemberRelation \
                        WHERE groupID = {groupID};"
        c.execute(commandString)
        
        commandString = f"DELETE FROM groups \
                        WHERE groupID = {groupID};"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

# WATCHLISTS SECTION ===================================================
def add2WatchList(ownerID: int, movieID: int, isGroupList: bool, isAntiList: bool):
    conn, c = openConnection()
    ownerType = "user"
    prefix = ""

    if isGroupList:
        ownerType = "group"
    
    if isAntiList:
        prefix = "Anti"
        
    try:
        commandString = f"INSERT INTO {ownerType}{prefix}WatchList ({ownerType}ID, movieID) \
                        VALUES ({ownerID}, {movieID});"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

def getWatchList(ownerID: int, isGroupList: bool, isAntiList: bool):
    conn, c = openConnection()
    ownerType = "user"
    prefix = ""

    if isGroupList:
        ownerType = "group"
    
    if isAntiList:
        prefix = "Anti"
        
    try:
        commandString = f"SELECT m.movieID, m.title, m.rating, m.release FROM movies m\
                            INNER JOIN {ownerType}{prefix}WatchList w\
                            ON m.movieID = w.movieID\
                            WHERE {ownerType}ID = {ownerID};"
        c.execute(commandString)
        output = c.fetchall()
        closeConnection(c, conn)
        return output
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return []

def removeFromWatchList(ownerID: int, movieID: int, isGroupList: bool, isAntiList: bool):
    conn, c = openConnection()
    ownerType = "user"
    prefix = ""

    if isGroupList:
        ownerType = "group"
    
    if isAntiList:
        prefix = "Anti"
        
    try:
        commandString = f"DELETE FROM {ownerType}{prefix}WatchList \
                            WHERE {ownerType}ID = {ownerID} AND movieID = {movieID};"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

# MOVIES SECTION ===================================================
# util for converting csv files to json files
def csv2Json(inputFile, outputFile):
    with open(inputFile, "r", encoding=ENCODING) as inFile:
        with open(outputFile, "w", encoding=ENCODING) as outFile:
            reader = csv.DictReader(inFile)
            data = list(reader)
            json.dump(data, outFile, indent = 4)

def cleanMovieFile():
    with open(MOVIES_FILENAME, "r", encoding=ENCODING) as file:
        content = json.load(file)
    foundIDs = []
    output = []
    for movie in content:
        try:
            id = int(movie["id"])
            if id not in foundIDs and movie["title"] != None:
                movie["title"] = movie["title"].replace("\"", "'")
                
                foundIDs.append(id)
                output.append(movie)
        except ValueError:
            continue
    
    with open(CLEANED_MOVIES, "w", encoding=ENCODING) as file:
        json.dump(output, file, indent = 4)

def addMovies():
    with open(CLEANED_MOVIES, "r", encoding=ENCODING) as file:
        content = json.load(file)
    
    conn, c = openConnection()
    for movie in content:
        id = int(movie["id"])
        title = movie["title"]
        rating = float(movie["vote_average"])
        release = movie["release_date"]
        overview = movie["overview"].replace("\"", "'")
        commandString = f'INSERT INTO movies (movieID, title, overview, rating, release) \
                          VALUES ({id}, "{title}", "{overview}", {rating}, "{release}");'
        c.execute(commandString)
    
    conn.commit()
    
def addGenres():
    genreMatch = r"'name': '(.+?)'}"
    conn, c = openConnection()
    with open(CLEANED_MOVIES, "r", encoding=ENCODING) as file:
        content = json.load(file)
    for movie in content:
        genres = movie["genres"]
        movieID = int(movie["id"])
        hits = re.findall(genreMatch, genres)
        for hit in hits:
            commandString = f"INSERT INTO genreMovieRelation (movieID, genre) VALUES \
                             ({movieID}, '{hit}');"
            c.execute(commandString)
    conn.commit()
    closeConnection(c, conn)

# EVENTS SECTION =====================================================  
def getEvents() -> list:
    conn, c = openConnection()
    c.execute("SELECT eventID, title, date FROM events ORDER BY date ASC;")
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

def addEvent(title: str, date_str: str) -> bool:
    conn, c = openConnection()
    try:
        c.execute(
            "INSERT INTO events (title, date) VALUES (?, ?);",
            (title, date_str)
        )
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

def deleteEvent(event_id: int) -> bool:
    conn, c = openConnection()
    try:
        c.execute("DELETE FROM events WHERE eventID = ?;", (event_id,))
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    
def updateEvent(event_id: int, title: str, date_str: str) -> bool:
    conn, c = openConnection()
    try:
        c.execute(
            "UPDATE events SET title = ?, date = ? WHERE eventID = ?;",
            (title, date_str, event_id)
        )
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    
def getEventsForUser(user_id: int) -> list:
    conn, c = openConnection()
    c.execute("""
        SELECT e.eventID, e.title, e.date
        FROM events e
        JOIN userEventRelation uer ON e.eventID = uer.eventID
        WHERE uer.userID = ?
        ORDER BY e.date ASC;
    """, (user_id,))
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

def addEventForUser(user_id: int, title: str, date_str: str) -> bool:
    conn, c = openConnection()
    try:
        # insert event
        c.execute(
            "INSERT INTO events (title, date) VALUES (?, ?);",
            (title, date_str)
        )
        event_id = c.lastrowid
        # link event to user
        c.execute(
            "INSERT INTO userEventRelation (userID, eventID) VALUES (?, ?);",
            (user_id, event_id)
        )
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

# RESETS DATABASE ============================================
# DESTROYS ALL TABLES - DONT USE UNLESS ITS LAST RESORT
def dropTables():
    conn, c = openConnection()
    tableNames = ["userEventRelation", "groupEventRelation", "events", "genreMovieRelation", "groupAntiWatchList", "groupWatchList", "groupMemberRelation", "groups", "userAntiWatchList", "userWatchList", "movies", "users"]

    for table in tableNames:
        commandString = "DROP TABLE IF EXISTS " + table + ";"
        c.execute(commandString)
    
    conn.commit()
    closeConnection(c, conn)
    
def resetDB():
    dropTables()
    createTables()

def test():
    resetDB()
    if not createUser("test", "test", "test@test.com"):
        print("Create Test Failed")
    createUser("test2", "test2", "test2@test.com")


    if not loginUser("test", "test"):
        print("Login Test Failed")
    
    if not createGroup("testGroup", 0):
        print("Create Group Failed")
    
    if not addMember2Group(0, 1):
        print("Add member2Group Failed")
    
    if not getGroups(1):
        print("GetGroups failed")
    
    if not deleteGroup(0):
        print("Delete Group failed")
    
    if not deleteUser(1):
        print("Delete User failed")

    
if __name__ == "__main__":
    # resetDB()
    # addMovies()
    # addGenres()
    createUser("test", "test", "test")
    createUser("test1", "test1", "test1")
    createGroup("testG", 0)


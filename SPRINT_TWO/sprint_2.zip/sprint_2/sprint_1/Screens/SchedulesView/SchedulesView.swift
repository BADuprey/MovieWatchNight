import SwiftUI

struct SchedulesView: View {
    @State private var selectedDate = Date()
    @State private var timeForNew = Date()
    @State private var newTitle: String = ""
    @State private var events: [DBEvent] = []

    // for editing the event
    @State private var editingEvent: DBEvent? = nil
    @State private var editTitle: String = ""
    @State private var editDate: Date = Date()
    @State private var showingEdit = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {

                    DatePicker("Select date",
                               selection: $selectedDate,
                               displayedComponents: .date)
                        .datePickerStyle(.graphical)
                        .frame(height: 340)
                        .padding(.bottom, 4)

                    Text("Movies on this day")
                        .font(.headline)

                    VStack(spacing: 8) {
                        if eventsForSelectedDay.isEmpty {
                            Text("No movies for this day.")
                                .foregroundColor(.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding()
                                .background(Color(UIColor.secondarySystemBackground))
                                .cornerRadius(12)
                        } else {
                            ForEach(eventsForSelectedDay) { event in
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(event.title)
                                        if let d = parseDate(event.date) {
                                            Text(timeString(from: d))
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                    }
                                    Spacer()
                                    Button {
                                        deleteEvent(event)
                                    } label: {
                                        Image(systemName: "trash")
                                            .foregroundColor(.red)
                                    }
                                    .buttonStyle(.borderless)
                                }
                                .padding()
                                .background(Color(UIColor.secondarySystemBackground))
                                .cornerRadius(12)
                                .onTapGesture {
                                    startEditing(event)
                                }
                            }
                        }
                    }

                    // add section
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Add a movie for this day")
                            .font(.subheadline)

                        TextField("Movie title", text: $newTitle)
                            .textFieldStyle(.roundedBorder)

                        DatePicker("Time",
                                   selection: $timeForNew,
                                   displayedComponents: .hourAndMinute)
                            .datePickerStyle(.compact)

                        Button("Add") {
                            addEvent()
                        }
                    }

                    Spacer(minLength: 20)
                }
                .padding()
            }
            .navigationTitle("Schedules")
            .onAppear {
                loadEvents()
            }
            .sheet(isPresented: $showingEdit) {
                editSheet
            }
        }
    }

    // edit event
    private var editSheet: some View {
        NavigationStack {
            Form {
                Section("Title") {
                    TextField("Title", text: $editTitle)
                }
                Section("Date & time") {
                    DatePicker("When", selection: $editDate)
                }
            }
            .navigationTitle("Edit event")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showingEdit = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { saveEdit() }
                }
            }
        }
    }

    private func startEditing(_ event: DBEvent) {
        editingEvent = event
        editTitle = event.title
        editDate = parseDate(event.date) ?? Date()
        showingEdit = true
    }

    private func saveEdit() {
        guard let event = editingEvent else { return }
        let dateString = formatDate(editDate)

        APIService.shared.updateEvent(eventID: event.eventID,
                                      title: editTitle,
                                      dateString: dateString) { ok in
            if ok {
                loadEvents()
            }
        }
        showingEdit = false
    }

    // changing event
    private var eventsForSelectedDay: [DBEvent] {
        events
            .filter {
                if let d = parseDate($0.date) {
                    return Calendar.current.isDate(d, inSameDayAs: selectedDate)
                }
                return false
            }
            .sorted {
                guard let d1 = parseDate($0.date), let d2 = parseDate($1.date) else { return false }
                return d1 < d2
            }
    }

    // actions like loading or adding
    private func loadEvents() {
        APIService.shared.fetchEvents { items in
            DispatchQueue.main.async {
                self.events = items
            }
        }
    }

    private func addEvent() {
        guard !newTitle.isEmpty else { return }

        let fullDate = mergeDateAndTime(day: selectedDate, time: timeForNew)
        let dateString = formatDate(fullDate)

        APIService.shared.addEvent(title: newTitle, dateString: dateString) { ok in
            if ok {
                loadEvents()
            }
        }

        newTitle = ""
    }

    private func deleteEvent(_ event: DBEvent) {
        APIService.shared.deleteEvent(eventID: event.eventID) { ok in
            if ok {
                DispatchQueue.main.async {
                    self.events.removeAll { $0.eventID == event.eventID }
                }
            }
        }
    }

    // some helpers for dates (i'll add citations in our documentation doc.) 
    private func mergeDateAndTime(day: Date, time: Date) -> Date {
        let cal = Calendar.current
        let d = cal.dateComponents([.year, .month, .day], from: day)
        let t = cal.dateComponents([.hour, .minute], from: time)

        var comps = DateComponents()
        comps.year = d.year
        comps.month = d.month
        comps.day = d.day
        comps.hour = t.hour
        comps.minute = t.minute

        return cal.date(from: comps) ?? day
    }

    private func formatDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm"
        return f.string(from: date)
    }

    private func parseDate(_ s: String) -> Date? {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm"
        return f.date(from: s)
    }

    private func timeString(from date: Date) -> String {
        let f = DateFormatter()
        f.timeStyle = .short
        return f.string(from: date)
    }
}

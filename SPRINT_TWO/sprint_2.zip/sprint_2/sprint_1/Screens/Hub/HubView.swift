import SwiftUI

struct HubView: View {
    let username: String
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {

                    // VStack for the welcome card
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Welcome to Movie Watch Night!")
                            .font(.title3).bold()
                        Text(username.isEmpty ? "User" : username)
                            .foregroundColor(.pink)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 1, y: 1)

                    // movie coming up rectangle
                    Spacer()
                    
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Movie coming up on xx.xx!")
                            Text("From - group name").bold()
                        }
                        Spacer()
                        Image(systemName: "mappin.and.ellipse")
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 1, y: 1)

                    Spacer()
                    // groups + info buttons rectangles
                    HStack(spacing: 12) {
                        Button("Groups") { }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 1, y: 1)

                        NavigationLink("Info page") {
                            InfoView()
                        }
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 1, y: 1)
                    }

                    Spacer()
                    // trending movie rectalngle
                    VStack(alignment: .leading, spacing: 6) {
                        Text("trending movie")
                            .font(.headline)
                        Text("~ placeholder ~")
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 1, y: 1)

                    Spacer(minLength: 20)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
            }
            .navigationTitle("Hub")
            .background(Color.white)
        }
    }
}

#Preview {
    HubView(username: "test")
}

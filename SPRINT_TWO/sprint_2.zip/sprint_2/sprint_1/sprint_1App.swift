//
//  sprint_1App.swift
//  sprint_1
//
//  Created by Sasha Jazmin Abuin on 10/12/25.
//

import SwiftUI

@main
struct sprint_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

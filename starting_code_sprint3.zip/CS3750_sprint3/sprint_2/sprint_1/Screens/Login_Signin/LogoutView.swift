import SwiftUI

struct LogoutView: View {
    let onLogout: () -> Void

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Signed in")
                    .font(.title2)

                Button(role: .destructive) {
                    onLogout()
                } label: {
                    Text("Log Out")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)

                Spacer()
            }
            .padding()
            .navigationTitle("Log Out")
        }
    }
}

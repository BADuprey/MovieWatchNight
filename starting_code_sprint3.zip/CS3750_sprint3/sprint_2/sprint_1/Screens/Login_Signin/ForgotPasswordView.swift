import SwiftUI

struct ForgotPasswordView: View {
    @State private var username: String = ""
    @State private var isLoading = false
    @State private var successMessage: String?
    @State private var errorMessage: String?
    @State private var maskedEmail: String?

    // to show reset screen
    @State private var showReset = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.93, green: 0.97, blue: 1.0),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 16) {
                Text("Forgot Password?")
                    .font(.title.bold())

                Text("Enter your username and we’ll verify your account.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)

                TextField("Username", text: $username)
                    .padding(10)
                    .background(textFieldColor)
                    .cornerRadius(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black.opacity(0.15), lineWidth: 1)
                    )
                    .padding(.horizontal, 40)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)

                if let success = successMessage {
                    VStack(spacing: 4) {
                        Text(success)
                            .foregroundColor(.green)
                        if let maskedEmail {
                            Text("Account found: \(maskedEmail)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }

                    Button("Reset password now") {
                        showReset = true
                    }
                    .padding(.top, 4)
                }

                if let error = errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .font(.footnote)
                }

                Button(action: verifyUser) {
                    HStack {
                        if isLoading {
                            ProgressView().tint(.white)
                        } else {
                            Text("Check Account")
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(username.isEmpty ? Color.blue.opacity(0.4) : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 40)
                }
                .disabled(username.isEmpty || isLoading)

                Spacer()
            }
            .padding(.top, 50)
            // navigation to reset screen
            .sheet(isPresented: $showReset) {
                ResetPasswordView(username: username)
            }
        }
    }

    private func verifyUser() {
        errorMessage = nil
        successMessage = nil
        maskedEmail = nil
        isLoading = true

        APIService.shared.forgotPassword(username: username) { ok, email in
            DispatchQueue.main.async {
                self.isLoading = false
                if ok {
                    self.successMessage = "Account found!"
                    if let email, !email.isEmpty {
                        self.maskedEmail = maskEmail(email)
                    } else {
                        self.maskedEmail = "••••@example.com"
                    }
                } else {
                    self.errorMessage = "We couldn’t find that username."
                }
            }
        }
    }

    private func maskEmail(_ email: String) -> String {
        let parts = email.split(separator: "@")
        guard parts.count == 2 else { return email }
        let name = parts[0]
        let domain = parts[1]
        if let first = name.first {
            return "\(first)•••@\(domain)"
        } else {
            return "•••@\(domain)"
        }
    }
}

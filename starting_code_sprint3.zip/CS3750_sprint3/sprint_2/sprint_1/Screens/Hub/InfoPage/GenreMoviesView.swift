import SwiftUI

struct GenreMoviesView: View {
    let genre: String
    var preselectedMovieID: Int? = nil

    @State private var movies: [MovieSummary] = []
    @State private var isLoading = true

    @State private var showPreselectedDetail = false
    @State private var resolvedPreselectedID: Int? = nil
    @State private var didAutoNavigate = false

    var body: some View {
        List {
            if isLoading {
                Text("Loading \(genre) movies...")
            } else if movies.isEmpty {
                Text("No movies found.")
            } else {
                ForEach(movies) { movie in
                    NavigationLink(movie.title) {
                        MovieDetailView(movieID: movie.movieID)
                    }
                }
            }
        }
        .navigationTitle(genre)
        .navigationDestination(isPresented: $showPreselectedDetail) {
            MovieDetailView(movieID: resolvedPreselectedID ?? 0)
        }
        .onAppear {
            APIService.shared.fetchMovies(genre: genre) { result in
                DispatchQueue.main.async {
                    self.movies = result
                    self.isLoading = false

                    if !didAutoNavigate,
                       let target = preselectedMovieID,
                       result.contains(where: { $0.movieID == target }) {

                        self.resolvedPreselectedID = target
                        self.didAutoNavigate = true

                        DispatchQueue.main.async {
                            self.showPreselectedDetail = true
                        }
                    }
                }
            }
        }
    }
}

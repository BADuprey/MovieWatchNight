import SwiftUI

struct GroupsView: View {
    @State private var groups: [Group] = []
    @State private var showAddGroup = false
    @State private var isLoading = false
    
    let userID: Int
    let username: String
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                VStack {
                    if isLoading {
                        ProgressView("Loading groups...")
                            .padding()
                    } else if groups.isEmpty {
                        VStack {
                            Spacer()
                            Text("You’re not in any groups yet.")
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding()
                            Spacer()
                        }
                    } else {
                        ScrollView {
                            VStack(spacing: 12) {
                                ForEach(groups) { group in
                                    GroupRow(group: group)
                                }
                                .padding(.horizontal)
                            }
                        }
                    }
                }
                .padding(.top)
                .background(Color(.systemGray6))
                .navigationTitle("My Groups")
                .onAppear(perform: loadGroups)
                
                Button(action: { showAddGroup = true }) {
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 60, height: 60)
                        .background(Color.pink)
                        .clipShape(Circle())
                        .shadow(radius: 4, y: 2)
                }
                .padding()
                .sheet(isPresented: $showAddGroup) {
                    AddGroupView(userID: userID, onAdd: loadGroups)
                }
            }
        }
    }
    
    // Fetch groups from database
    private func loadGroups() {
        isLoading = true
        APIService.shared.fetchGroups(userID: userID) { groups in
            DispatchQueue.main.async {
                self.groups = groups
                self.isLoading = false
            }
        }
    }
}

struct GroupRow: View {
    let group: Group
    
    var body: some View {
        NavigationLink(destination: DetailedGroupView(group: group)) {
            Text(group.name)
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.white)
                .cornerRadius(12)
                .shadow(radius: 1, y: 1)
        }
    }
}

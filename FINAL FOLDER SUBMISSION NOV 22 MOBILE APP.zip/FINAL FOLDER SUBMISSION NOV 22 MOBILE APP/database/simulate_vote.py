# simulate_vote.py
import database as db

def run_simulation():
    print("============================================================")
    print("RESET DB")
    print("============================================================")
    db.resetDB()

    # 1) Create users
    print("\nCreating users...")
    db.createUser("Rachel", "pw1", "rachel@example.com")
    db.createUser("Julia",  "pw2", "julia@example.com")
    db.createUser("Sam",    "pw3", "sam@example.com")

    rachel_id = db.getUserByUsername("Rachel")[0]
    julia_id  = db.getUserByUsername("Julia")[0]
    sam_id    = db.getUserByUsername("Sam")[0]

    print(f"Rachel ID = {rachel_id}, Julia ID = {julia_id}, Sam ID = {sam_id}")

    # 2) Create group "Testing" with Rachel as leader
    print("\nCreating group 'Testing' with Rachel as leader...")
    db.createGroup("Testing", rachel_id)

    groups_for_rachel = db.getGroups(rachel_id)
    if not groups_for_rachel:
        print("ERROR: no groups returned for Rachel")
        return

    groupID = groups_for_rachel[0][0]
    print(f"'Testing' groupID = {groupID}")

    # 3) Add Julia + Sam to the group
    print("\nAdding Julia and Sam to group...")
    db.addMember2Group(groupID, julia_id)
    db.addMember2Group(groupID, sam_id)

    members = db.getGroupMembers(groupID)
    print("Group members (userIDs):", members)

    # 4) MOVIE ROUND: Rachel & Julia suggest, Sam votes
    print("\n============================================================")
    print("MOVIE ROUND")
    print("============================================================")

    print("Rachel suggests 'Movie A'...")
    db.suggestMovie(groupID, rachel_id, "Movie A")

    print("Julia suggests 'Movie B'...")
    db.suggestMovie(groupID, julia_id, "Movie B")

    suggestions = db.getSuggestionsForGroup(groupID)
    print("\nCurrent suggestions:")
    for s in suggestions:
        # s = (suggestionID, movieTitle, username, voteCount)
        print(f"  suggestionID={s[0]}, title='{s[1]}', by {s[2]}, votes={s[3]}")

    if len(suggestions) < 2:
        print("ERROR: expected at least 2 suggestions")
        return

    # just pick the first suggestion as the one Sam will vote for
    suggestion_id_for_sam = suggestions[0][0]
    print(f"\nSam votes for suggestionID={suggestion_id_for_sam}...")
    db.voteForSuggestion(suggestion_id_for_sam, sam_id)

    # After Sam's vote, ALL 3 members have voted → movie round should be closed
    roundInfo = db.getCurrentRoundForGroup(groupID)
    print("\n============================================================")
    print("FETCH DATE VOTING ROUND")
    print("============================================================")
    print("Round info:", roundInfo)

    if roundInfo is None:
        print("No date voting round found. That means the movie round never closed.")
        print("Check that countGroupMembers and countMovieVoters match and that all users voted.")
        return

    roundID, r_groupID, winningSuggestionID, movieTitle, winningDate, isComplete = roundInfo
    print(f"roundID={roundID}, groupID={r_groupID}, winningSuggestionID={winningSuggestionID}")
    print(f"movieTitle='{movieTitle}', winningDate={winningDate}, isComplete={isComplete}")

    # 5) DATE ROUND: each user proposes/votes on a date
    print("\n============================================================")
    print("DATE ROUND")
    print("============================================================")

    # Dates in your format: yyyy-MM-dd HH:mm
    date1 = "2025-12-01 19:00"
    date2 = "2025-12-02 20:00"

    print(f"Rachel votes for {date1}")
    db.voteForDate(roundID, rachel_id, date1)

    print(f"Julia votes for {date2}")
    db.voteForDate(roundID, julia_id, date2)

    print(f"Sam votes for {date1}")
    db.voteForDate(roundID, sam_id, date1)

    # At this point, all 3 have voted on dates, so _closeDateRound should have run.
    # This should create an event and link it to the group, and also finalize the round.

    updatedRoundInfo = db.getCurrentRoundForGroup(groupID)
    print("\nUPDATED ROUND INFO:", updatedRoundInfo)

    print("\n============================================================")
    print("GROUP EVENTS AFTER DATE ROUND CLOSES")
    print("============================================================")
    events = db.getEventsForGroup(groupID)
    if not events:
        print("No events found for group (something went wrong).")
    else:
        for e in events:
            # e = (eventID, title, date)
            print(f"eventID={e[0]}, title='{e[1]}', date={e[2]}")

    print("\nSimulation complete.\n")


if __name__ == "__main__":
    run_simulation()
import Foundation

// DO NOT TOUCH API SERVICE FINAL CLASS :O - SASHA =========================================
final class APIService {
    static let shared = APIService()
    private init() {}

    // Builds a POST request with form-url-encoded body.
    fileprivate func makeFormRequest(path: String, params: [String: String]) -> URLRequest? {
        guard let base = ServerConfig.shared.baseURL else {
            return nil
        }
        let url = base.appendingPathComponent(path)
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let bodyString = params.map { key, value in
            let escaped = value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? value
            return "\(key)=\(escaped)"
        }.joined(separator: "&")

        request.httpBody = bodyString.data(using: .utf8)
        return request
    }
}

// AUTHENTICATION SECTION =========================================
extension APIService {
    // POST /loginUser  -> "True" / "False"
    func login(username: String, password: String, completion: @escaping (Bool) -> Void) {
        // hash before sending
        let hashed = sha256(password)

        guard let request = makeFormRequest(path: "loginUser", params: [
            "username": username,
            "passHash": hashed
        ]) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, error in
            guard let data = data, error == nil else {
                completion(false)
                return
            }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true")
        }.resume()
    }

    // POST /createUser -> "True" / "False"
    func signup(username: String, password: String, email: String, completion: @escaping (Bool) -> Void) {
        // hash before sending back
        let hashed = sha256(password)

        guard let request = makeFormRequest(path: "createUser", params: [
            "username": username,
            "passHash": hashed,
            "email": email
        ]) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, error in
            guard let data = data, error == nil else {
                completion(false)
                return
            }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true")
        }.resume()
    }
    
    func resetPassword(username: String, newPassword: String, completion: @escaping (Bool) -> Void) {
        let hashed = sha256(newPassword)

        guard let request = makeFormRequest(path: "resetPassword", params: [
            "username": username,
            "passHash": hashed
        ]) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, error in
            guard let data = data, error == nil else {
                completion(false); return
            }

            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let ok = json["ok"] as? Bool {
                completion(ok)
            } else {
                completion(false)
            }
        }.resume()
    }

    // POST /forgotPassword  -> { "ok": true, "email": "..." }
    func forgotPassword(username: String, completion: @escaping (Bool, String?) -> Void) {
        guard let request = makeFormRequest(path: "forgotPassword", params: [
            "username": username
        ]) else {
            completion(false, nil)
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            guard let data = data, error == nil else {
                completion(false, nil)
                return
            }
            
            // try to read JSON { "ok": ..., "email": ... }
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let ok = json["ok"] as? Bool {
                let email = json["email"] as? String
                completion(ok, email)
            } else {
                completion(false, nil)
            }
        }.resume()
    }
    
}

// USER PROFILE SECTION ===============================================================
struct UserProfile: Decodable, Identifiable {
    let userID: Int
    let username: String
    let email: String?
    
    var id: Int { userID }
}

struct UserList: Decodable{
    let items: [UserProfile]
}

extension APIService {
    // POST /getUser
    func fetchUser(username: String, completion: @escaping (UserProfile?) -> Void) {
        guard let request = makeFormRequest(path: "getUser", params: [
            "username": username
        ]) else {
            completion(nil)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion(nil)
                return
            }
            let decoded = try? JSONDecoder().decode(UserProfile.self, from: data)
            completion(decoded)
        }.resume()
    }
}

// WATCH LIST SECTION ===============================================================
extension APIService {
    // POST /getWatchList
    func getWatchList(ownerID: Int, isGroupList: Bool, isAntiList: Bool, completion: @escaping([MovieSummary]) -> Void) {
        guard let request = makeFormRequest(path: "getWatchList", params: [
            "ownerID": String(ownerID),
            "isGroupList": String(isGroupList),
            "isAntiList": String(isAntiList)
        ]) else {
            completion([])
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }
            let decoded = try? JSONDecoder().decode(MovieList.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }
    
    // POST /removeMovieFromWatchList
    func removeMovieFromList(ownerID: Int,
                                 movieID: Int,
                                 isGroupList: Bool,
                                 isAntiList: Bool,
                                 completion: @escaping (Bool) -> Void) {
            guard let request = makeFormRequest(path: "removeFromWatchList", params: [
                "ownerID": String(ownerID),
                "movieID": String(movieID),
                "isGroupList": String(isGroupList),
                "isAntiList": String(isAntiList)
            ]) else {
                completion(false)
                return
            }
            
            URLSession.shared.dataTask(with: request) { data, _, _ in
                guard let data = data,
                      let text = String(data: data, encoding: .utf8)?
                        .trimmingCharacters(in: .whitespacesAndNewlines) else {
                    completion(false)
                    return
                }
                
                // backend will return "True" or "False"
                completion(text == "True" || text == "true")
            }.resume()
        }
    
    // POST /add2WatchList
    func add2WatchList(ownerID: Int, movieID: Int, isGroupList: Bool, isAntiList: Bool, completion: @escaping(Bool) -> Void) {
        guard let request = makeFormRequest(path: "add2WatchList", params: [
            "ownerID": String(ownerID),
            "movieID": String(movieID),
            "isGroupList": String(isGroupList),
            "isAntiList": String(isAntiList)
        ]) else {
            completion(false)
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion(false)
                return
            }
            completion(true)
        }.resume()
    }

    func addToUserWatchList(userID: Int, movieID: Int, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(
            path: "add2WatchList",
            params: [
                "ownerID": String(userID),
                "movieID": String(movieID),
                "isGroupList": "false",
                "isAntiList": "false"
            ]
        ) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion(false)
                return
            }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }


//Create custom movie from list (by this we mean --> they can type the name of any movie and add it)
struct AddCustomMovieResponse: Decodable {
    let ok: Bool
    let movieID: Int?
}

    func createCustomMovie(title: String,
                           completion: @escaping (Int?) -> Void) {
        guard let request = makeFormRequest(path: "addCustomMovie", params: [
            "title": title
        ]) else {
            completion(nil)
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion(nil)
                return
            }
            let decoded = try? JSONDecoder().decode(AddCustomMovieResponse.self, from: data)
            if decoded?.ok == true, let id = decoded?.movieID {
                completion(id)
            } else {
                completion(nil)
            }
        }.resume()
    }
    
    func addFreeTextMovieToList(ownerID: Int,
                                title: String,
                                isGroupList: Bool,
                                isAntiList: Bool,
                                completion: @escaping (Bool) -> Void) {
        createCustomMovie(title: title) { movieID in
            guard let movieID = movieID else {
                completion(false)
                return
            }
            
            self.add2WatchList(ownerID: ownerID,
                               movieID: movieID,
                               isGroupList: isGroupList,
                               isAntiList: isAntiList) { ok in
                completion(ok)
            }
        }
    }


    func addToWatchList(ownerID: Int, movieID: Int, isGroupList: Bool,isAntiList: Bool, completion: @escaping (Bool) -> Void) {
        let params: [String: String] = [
            "ownerID": String(ownerID),
            "movieID": String(movieID),
            "isGroupList": isGroupList ? "true" : "false",
            "isAntiList": isAntiList ? "true" : "false"
        ]

        guard let request = makeFormRequest(path: "add2WatchList", params: params) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard
                let data = data,
                let text = String(data: data, encoding: .utf8)?
                    .trimmingCharacters(in: .whitespacesAndNewlines)
            else {
                completion(false)
                return
            }

            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }
}


// MOVIE SECTION FOR INFO PAGE ==========================================================================
struct GenreList: Decodable {
    let genres: [String]
}

struct MovieSummary: Decodable, Identifiable {
    let movieID: Int
    let title: String
    let rating: Double?
    let release: String?

    var id: Int { movieID }
}

struct MovieList: Decodable {
    let items: [MovieSummary]
}

struct MovieDetail: Decodable {
    let movieID: Int
    let title: String
    let rating: Double?
    let release: String?
    let overview: String?
    
    var id: Int { movieID }
}

extension APIService {
    // GET /genres
    func fetchGenres(completion: @escaping ([String]) -> Void) {
        guard let base = ServerConfig.shared.baseURL else {
            completion([])
            return
        }
        let url = base.appendingPathComponent("genres")
        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }
            let decoded = try? JSONDecoder().decode(GenreList.self, from: data)
            completion(decoded?.genres ?? [])
        }.resume()
    }

    // GET /moviesByGenre?genre=Action
    func fetchMovies(genre: String, completion: @escaping ([MovieSummary]) -> Void) {
        guard let base = ServerConfig.shared.baseURL else {
            completion([])
            return
        }
        var comps = URLComponents(url: base.appendingPathComponent("moviesByGenre"), resolvingAgainstBaseURL: false)
        comps?.queryItems = [URLQueryItem(name: "genre", value: genre)]
        guard let url = comps?.url else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }
            let decoded = try? JSONDecoder().decode(MovieList.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }

    // GET /movie/{id}
    func fetchMovieDetail(id: Int, completion: @escaping (MovieDetail?) -> Void) {
        guard let base = ServerConfig.shared.baseURL else {
            completion(nil)
            return
        }
        let url = base.appendingPathComponent("movie/\(id)")
        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data else {
                completion(nil)
                return
            }
            let decoded = try? JSONDecoder().decode(MovieDetail.self, from: data)
            completion(decoded)
        }.resume()
    }
}

// EVENT SECTION (SCHEDULES) =======================================================
struct DBEvent: Decodable, Identifiable {
    let eventID: Int
    let title: String
    let date: String
    let groupName: String?

    var id: Int { eventID }
}

struct DBEventList: Decodable {
    let items: [DBEvent]
}

extension APIService {
    // GET /getEvents
    func fetchEvents(userID: Int, completion: @escaping ([DBEvent]) -> Void) {
        guard let request = makeFormRequest(path: "getEvents", params: [
            "userID": String(userID)
        ]) else {
            completion([]); return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion([]); return
            }
            let decoded = try? JSONDecoder().decode(DBEventList.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }

    func addEvent(userID: Int, title: String, dateString: String, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(path: "addEvent", params: [
            "userID": String(userID),
            "title": title,
            "date": dateString
        ]) else {
            completion(false); return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else { completion(false); return }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }

    // POST /deleteEvent
    func deleteEvent(eventID: Int, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(path: "deleteEvent", params: [
            "eventID": String(eventID)
        ]) else {
            completion(false); return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else { completion(false); return }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true")
        }.resume()
    }

    // POST /updateEvent
    func updateEvent(eventID: Int, title: String, dateString: String, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(path: "updateEvent", params: [
            "eventID": String(eventID),
            "title": title,
            "date": dateString
        ]) else {
            completion(false); return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else { completion(false); return }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true")
        }.resume()
    }
}

// RECOMMENDATIONS SECTION -----------------------------
extension APIService {
    // GET /recommendations?userID=...
    func fetchRecommendations(userID: Int?, limit: Int = 20, completion: @escaping ([MovieSummary]) -> Void) {
        guard let base = ServerConfig.shared.baseURL else {
            completion([])
            return
        }

        var comps = URLComponents(
            url: base.appendingPathComponent("recommendations"),
            resolvingAgainstBaseURL: false
        )

        var queryItems: [URLQueryItem] = [
            URLQueryItem(name: "limit", value: String(limit))
        ]
        if let userID = userID {
            queryItems.append(URLQueryItem(name: "userID", value: String(userID)))
        }
        comps?.queryItems = queryItems

        guard let url = comps?.url else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }
            let decoded = try? JSONDecoder().decode(MovieList.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }
}

// GROUP SECTION ===============================================================
struct Group: Identifiable, Decodable {
    let groupID: Int
    let name: String
    let leaderID: Int
    
    var id: Int { groupID }
}

struct GroupList: Decodable {
    let items: [Group]
}

extension APIService {
    // POST /getGroups
    func fetchGroups(userID: Int, completion: @escaping ([Group]) -> Void) {
                
        guard let request = makeFormRequest(path: "getGroups", params: [
            "userID": String(userID)
        ]) else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }
            
            print(String(data: data, encoding: .utf8) ?? "no data")

            let decoded = try? JSONDecoder().decode(GroupList.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }

    // POST /createGroup
    func createGroup(name: String, leaderID: Int, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(path: "createGroup", params: [
            "name": name,
            "leaderID": String(leaderID)
        ]) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion(false)
                return
            }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }
    
    // POST /getGroupMembers
    func fetchGroupMembers(groupID: Int, completion: @escaping ([UserProfile]) -> Void) {
        guard let request = makeFormRequest(path: "getGroupMembers", params: [
            "groupID": String(groupID)
        ]) else {
            completion([])
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }

            print(String(data: data, encoding: .utf8) ?? "no data")
            
            let decoded = try? JSONDecoder().decode(UserList.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }
    

    func deleteGroup(groupID: Int, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(
            path: "deleteGroup",
            params: ["groupID": String(groupID)]
        ) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data,
                  let text = String(data: data, encoding: .utf8)?
                        .trimmingCharacters(in: .whitespacesAndNewlines)
            else {
                completion(false)
                return
            }

            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }

    func removeMemberFromGroup(groupID: Int, userID: Int, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(
            path: "removeMemberFromGroup",
            params: [
                "groupID": String(groupID),
                "userID": String(userID)
            ]
        ) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard
                let data = data,
                let text = String(data: data, encoding: .utf8)?
                    .trimmingCharacters(in: .whitespacesAndNewlines)
            else {
                completion(false)
                return
            }

            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }

    // POST /getGroupEvents
    func fetchGroupEvents(groupID: Int, completion: @escaping ([DBEvent]) -> Void) {
        guard let request = makeFormRequest(path: "getGroupEvents", params: [
            "groupID": String(groupID)
        ]) else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }

            let decoded = try? JSONDecoder().decode(DBEventList.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }

    // POST /addGroupEvent
    func addGroupEvent(groupID: Int,
                       title: String,
                       dateString: String,
                       completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(path: "addGroupEvent", params: [
            "groupID": String(groupID),
            "title": title,
            "date": dateString
        ]) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion(false)
                return
            }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }
}

// GROUP MOVIE SUGGESTIONS ====================================================
struct MovieSuggestion: Decodable, Identifiable {
    let suggestionID: Int
    let movieTitle: String
    let suggestedBy: String
    let voteCount: Int

    var id: Int { suggestionID }
}

struct MovieSuggestionList: Decodable {
    let items: [MovieSuggestion]
}

extension APIService {
    // POST /suggestMovie
    func suggestMovie(groupID: Int, userID: Int, movieTitle: String, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(path: "suggestMovie", params: [
            "groupID": String(groupID),
            "userID": String(userID),
            "movieTitle": movieTitle
        ]) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion(false)
                return
            }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }

    // POST /voteForMovie
    func voteForMovie(suggestionID: Int, userID: Int, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(path: "voteForMovie", params: [
            "suggestionID": String(suggestionID),
            "userID": String(userID)
        ]) else {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion(false)
                return
            }
            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            completion(text == "True" || text == "true" || text == "1")
        }.resume()
    }

    // POST /getSuggestions
    func fetchSuggestions(groupID: Int, completion: @escaping ([MovieSuggestion]) -> Void) {
        guard let request = makeFormRequest(path: "getSuggestions", params: [
            "groupID": String(groupID)
        ]) else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }
            let decoded = try? JSONDecoder().decode(MovieSuggestionList.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }
}

//VOTING ROUNDS FOR GROUPS -----------------------------
struct VotingRoundInfo: Decodable {
    let roundID: Int
    let groupID: Int
    let winningSuggestionID: Int?
    let movieTitle: String
    let winningDate: String?
    let isComplete: Bool
}

struct VotingRoundResponse: Decodable {
    let round: VotingRoundInfo?
}

extension APIService {

    func fetchCurrentRound(groupID: Int, completion: @escaping (VotingRoundInfo?) -> Void) {
        guard let request = makeFormRequest(path: "getCurrentRound", params: [
            "groupID": String(groupID)
        ]) else {
            DispatchQueue.main.async { completion(nil) }
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("fetchCurrentRound error:", error)
                DispatchQueue.main.async { completion(nil) }
                return
            }

            guard let data = data else {
                print("fetchCurrentRound: no data")
                DispatchQueue.main.async { completion(nil) }
                return
            }

            if let raw = String(data: data, encoding: .utf8) {
                print("fetchCurrentRound raw response:", raw)
            }

            do {
                let decoded = try JSONDecoder().decode(VotingRoundResponse.self, from: data)
                print("fetchCurrentRound decoded round:", decoded.round as Any)
                DispatchQueue.main.async {
                    completion(decoded.round)
                }
            } catch {
                print("fetchCurrentRound decode error:", error)
                DispatchQueue.main.async { completion(nil) }
            }
        }.resume()
    }

    func voteForDate(roundID: Int, userID: Int, dateChoice: String, completion: @escaping (Bool) -> Void) {
        guard let request = makeFormRequest(path: "voteForDate", params: [
            "roundID": String(roundID),
            "userID": String(userID),
            "dateChoice": dateChoice
        ]) else {
            DispatchQueue.main.async { completion(false) }
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print("voteForDate error:", error)
                DispatchQueue.main.async { completion(false) }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async { completion(false) }
                return
            }

            let text = String(data: data, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)

            print("voteForDate raw response:", text ?? "nil")

            DispatchQueue.main.async {
                completion(text == "True" || text == "true" || text == "1")
            }
        }.resume()
    }
}

struct DateVoteOption: Decodable, Identifiable {
    let dateChoice: String
    let voteCount: Int
    let youVoted: Bool

    var id: String { dateChoice }

    var date: Date? {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = TimeZone(secondsFromGMT: 0)
        f.dateFormat = "yyyy-MM-dd HH:mm"
        return f.date(from: dateChoice)
    }
}

struct DateVotesResponse: Decodable {
    let items: [DateVoteOption]
}

extension APIService {

    func fetchDateVotes(
        roundID: Int,
        userID: Int,
        completion: @escaping ([DateVoteOption]) -> Void
    ) {
        guard let request = makeFormRequest(
            path: "getDateVotes",
            params: [
                "roundID": String(roundID),
                "userID": String(userID)
            ]
        ) else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data = data else {
                completion([])
                return
            }

            let decoded = try? JSONDecoder().decode(DateVotesResponse.self, from: data)
            completion(decoded?.items ?? [])
        }.resume()
    }
}

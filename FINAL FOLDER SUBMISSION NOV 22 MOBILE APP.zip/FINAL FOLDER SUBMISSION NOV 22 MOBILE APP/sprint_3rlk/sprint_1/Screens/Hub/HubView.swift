import SwiftUI

struct MovieJump: Hashable {
    let genre: String
    let movieID: Int?
    let movieTitle: String
}

struct HubView: View {
    let username: String
    let userID: Int

    @State private var genres: [String] = []
    @State private var currentMovieTitle: String = "Tap the button to get a movie 🎬"
    @State private var currentMovieID: Int? = nil
    @State private var currentMovieGenre: String? = nil
    @State private var isFetchingMovie = false

    // for navigation to GenreMoviesView
    @State private var jumpToGenre: MovieJump?
    
    @State private var upcomingEventTitle: String? = nil
    @State private var upcomingEventDate: Date? = nil

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {

                    // welcome card
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Welcome to Movie Watch Night!")
                            .font(.title3).bold()
                        Text(username.isEmpty ? "Guest" : username)
                            .foregroundColor(Color(red: 0.29, green: 0.55, blue: 0.98))
                            .font(.subheadline)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(16)
                    .shadow(color: Color.black.opacity(0.03), radius: 6, y: 3)

                    // upcoming movie card
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            if let date = upcomingEventDate,
                               let title = upcomingEventTitle {
                                Text("Movie coming up on \(shortDateString(from: date))")
                                    .font(.subheadline)
                                Text(title)
                                    .font(.subheadline.weight(.semibold))
                            } else {
                                Text("No upcoming movie night yet")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                Text("Add one in your schedule or groups")
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }
                        }
                        Spacer()
                        Image(systemName: "paperclip.circle.fill")
                            .foregroundColor(Color(red: 0.29, green: 0.55, blue: 0.98))
                            .font(.title3)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(16)
                    .shadow(color: Color.black.opacity(0.03), radius: 6, y: 3)

                    // buttons row
                    HStack(spacing: 12) {
                        NavigationLink(destination: GroupsView(userID: userID, username: username)) {
                            Text("Groups")
                                .font(.subheadline.bold())
                                .foregroundColor(.primary)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.white)
                                .cornerRadius(14)
                                .shadow(color: Color.black.opacity(0.02), radius: 3, y: 2)
                        }

                        NavigationLink("Info page") {
                            InfoView(userID: userID)
                        }
                        .font(.subheadline.bold())
                        .foregroundColor(.primary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.white)
                        .cornerRadius(14)
                        .shadow(color: Color.black.opacity(0.02), radius: 3, y: 2)
                    }

                    //Random movie card
                    Button {
                        if let g = currentMovieGenre {
                            jumpToGenre = MovieJump(
                                genre: g,
                                movieID: currentMovieID,
                                movieTitle: currentMovieTitle
                            )
                        }
                    } label: {
                        ZStack {
                            LinearGradient(
                                colors: [
                                    Color(red: 0.11, green: 0.42, blue: 0.87),
                                    Color(red: 0.22, green: 0.74, blue: 0.95)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                            .cornerRadius(20)
                            .shadow(color: Color(red: 0.11, green: 0.42, blue: 0.87).opacity(0.35),
                                    radius: 10, y: 6)

                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    HStack(spacing: 4) {
                                        Image(systemName: "sparkles")
                                        Text("Random movie")
                                    }
                                    .font(.caption.bold())
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 4)
                                    .background(Color.white.opacity(0.18))
                                    .clipShape(Capsule())

                                    Spacer()
                                    Text("🍿")
                                        .font(.title2)
                                }

                                Text(currentMovieTitle)
                                    .foregroundColor(.white)
                                    .font(.title3.weight(.semibold))
                                    .multilineTextAlignment(.leading)

                                Button(action: loadRandomMovie) {
                                    HStack(spacing: 6) {
                                        Image(systemName: "film.fill")
                                        if isFetchingMovie {
                                            ProgressView().tint(.white)
                                        } else {
                                            Text("Show me a movie!")
                                        }
                                    }
                                    .font(.subheadline.bold())
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 9)
                                    .background(Color.white.opacity(0.22))
                                    .foregroundColor(.white)
                                    .clipShape(Capsule())
                                }
                                .buttonStyle(.plain)
                            }
                            .padding(18)
                        }
                    }
                    .buttonStyle(.plain)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)

                    Spacer(minLength: 20)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
            }
            .background(Color(red: 0.95, green: 0.96, blue: 0.99))
            .navigationTitle("Hub")
            .navigationDestination(item: $jumpToGenre) { info in
                GenreMoviesView(
                    genre: info.genre,
                    userID: userID,
                    preselectedMovieID: info.movieID
                )
            }
        }
        .onAppear {
            loadGenresIfNeeded()
            loadUpcomingEvent()
        }
    }

    //functions
    private func loadGenresIfNeeded() {
        guard genres.isEmpty else { return }
        APIService.shared.fetchGenres { result in
            DispatchQueue.main.async {
                self.genres = result
            }
        }
    }

    private func loadRandomMovie() {
        guard !genres.isEmpty else {
            currentMovieTitle = "No genres available"
            currentMovieID = nil
            currentMovieGenre = nil
            return
        }

        isFetchingMovie = true
        let genre = genres.randomElement() ?? genres[0]

        APIService.shared.fetchMovies(genre: genre) { movies in
            DispatchQueue.main.async {
                self.isFetchingMovie = false
                if movies.isEmpty {
                    self.currentMovieTitle = "No movies found in \(genre)"
                    self.currentMovieID = nil
                    self.currentMovieGenre = genre
                } else {
                    let movie = movies.randomElement()!
                    self.currentMovieTitle = movie.title
                    self.currentMovieID = movie.movieID
                    self.currentMovieGenre = genre
                }
            }
        }
    }
    
    private func parseDate(_ s: String) -> Date? {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm"
        f.locale = Locale(identifier: "en_US_POSIX")
        return f.date(from: s)
    }

    private func shortDateString(from date: Date) -> String {
        let f = DateFormatter()
        f.dateStyle = .medium
        f.timeStyle = .short
        return f.string(from: date)
    }
    
    private func loadUpcomingEvent() {
        APIService.shared.fetchEvents(userID: userID) { events in
            DispatchQueue.main.async {
                let now = Date()

                let upcoming = events
                    .compactMap { event -> (DBEvent, Date)? in
                        guard let d = parseDate(event.date) else { return nil }
                        return (event, d)
                    }
                    .filter { $0.1 >= now }
                    .sorted { $0.1 < $1.1 }
                    .first

                if let (event, date) = upcoming {
                    self.upcomingEventTitle = event.title
                    self.upcomingEventDate = date
                } else {
                    self.upcomingEventTitle = nil
                    self.upcomingEventDate = nil
                }
            }
        }
    }
}

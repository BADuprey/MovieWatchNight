import SwiftUI

struct GroupsView: View {
    @State private var groups: [Group] = []
    @State private var isLoading = false
    @State private var showAddGroup = false
    @State private var errorMessage: String?

    @State private var showDeleteAlert = false
    @State private var groupPendingDeletion: Group?

    let userID: Int
    let username: String

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                VStack {
                    if isLoading {
                        ProgressView("Loading groups...")
                            .padding()
                    } else if groups.isEmpty {
                        // if no groups then we are in empty state
                        VStack(spacing: 10) {
                            Spacer()

                            Text("You’re not in any groups yet.")
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)

                            Text("Join a group!")
                                .font(.headline)
                                .foregroundColor(.gray)

                            Button(action: { showAddGroup = true }) {
                                Text("Create Group")
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.blue.opacity(0.2))
                                    .cornerRadius(10)
                            }
                            .padding(.horizontal)

                            Spacer()
                        }
                    } else {
                        ScrollView {
                            VStack(spacing: 16) {
                                ForEach(groups) { group in
                                    GroupRow(
                                        group: group,
                                        currentUserID: userID
                                    ) {
                                        // leader tapped delete in the row for the group
                                        groupPendingDeletion = group
                                        showDeleteAlert = true
                                    }
                                }
                            }
                            .padding(.horizontal)
                            .padding(.top, 8)
                        }
                    }

                    if let errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.footnote)
                            .padding(.top, 4)
                    }
                }
                .padding(.top)
                .background(Color(.systemGray6))
                .navigationTitle("My Groups")
                .onAppear(perform: loadGroups)

                // Floating add button
                Button(action: { showAddGroup = true }) {
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 50, height: 40)
                        .background(Color.blue)
                        .clipShape(Circle())
                        .shadow(radius: 4, y: 2)
                }
                .padding()
            }
            // Sheet for creating and/or joining a group
            .sheet(isPresented: $showAddGroup, onDismiss: loadGroups) {
                AddGroupView(userID: userID, onAdd: loadGroups)
            }
            // Delete group alert
            .alert("Delete group?",
                   isPresented: $showDeleteAlert) {
                Button("Delete", role: .destructive) {
                    if let g = groupPendingDeletion {
                        deleteGroup(g)
                    }
                }
                Button("Cancel", role: .cancel) {
                    groupPendingDeletion = nil
                }
            } message: {
                if let g = groupPendingDeletion {
                    Text("This will delete \"\(g.name)\" for all members.")
                } else {
                    Text("This will delete the group for all members.")
                }
            }
        }
    }

    // Fetch groups from database
    private func loadGroups() {
        isLoading = true
        errorMessage = nil

        APIService.shared.fetchGroups(userID: userID) { groups in
            DispatchQueue.main.async {
                self.groups = groups
                self.isLoading = false
            }
        }
    }

    private func deleteGroup(_ group: Group) {
        errorMessage = nil
        APIService.shared.deleteGroup(groupID: group.groupID) { success in
            DispatchQueue.main.async {
                if success {
                    groups.removeAll { $0.groupID == group.groupID }
                    groupPendingDeletion = nil
                } else {
                    errorMessage = "Could not delete group. Please try again."
                }
            }
        }
    }
}

struct GroupRow: View {
    let group: Group
    let currentUserID: Int
    let onDeleteTapped: (() -> Void)?

    init(group: Group, currentUserID: Int, onDeleteTapped: (() -> Void)? = nil) {
        self.group = group
        self.currentUserID = currentUserID
        self.onDeleteTapped = onDeleteTapped
    }

    var body: some View {
        HStack(spacing: 8) {
            NavigationLink(
                destination: DetailedGroupView(
                    group: group,
                    currentUserID: currentUserID
                )
            ) {
                HStack {
                    Text(group.name)
                        .font(.headline)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.white)
                .cornerRadius(12)
                .shadow(radius: 1, y: 1)
            }

            // Only show delete button if current user is the leader (non-leaders cannot delete)
            if currentUserID == group.leaderID {
                Button {
                    onDeleteTapped?()
                } label: {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                        .padding(8)
                }
                .buttonStyle(.borderless)
            }
        }
    }
}

#Preview {
    GroupsView(userID: 1, username: "ExampleUser")
}

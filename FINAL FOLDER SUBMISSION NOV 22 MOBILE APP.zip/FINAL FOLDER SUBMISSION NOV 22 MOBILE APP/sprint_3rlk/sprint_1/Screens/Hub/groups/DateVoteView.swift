import SwiftUI

struct DateVoteView: View {
    let group: Group
    let round: VotingRoundInfo
    let currentUserID: Int
    
    @Environment(\.dismiss) private var dismiss
    @State private var selectedDate = Date()
    @State private var isSubmitting = false
    @State private var errorMessage: String?
    
    @State private var options: [DateVoteOption] = [] // for the current votes
    
    var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 24) {
                    // Header card
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Vote on a Date")
                            .font(.title2.bold())
                            .foregroundColor(.primary)
                        
                        Text("Movie: \(round.movieTitle)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white.opacity(0.95))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.04), radius: 5, y: 3)
                    .padding(.horizontal)
                    .padding(.top, 8)
                    
                    //Current votes summary
                    if !options.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Current time choices")
                                .font(.subheadline.bold())
                                .foregroundColor(.primary)
                            
                            VStack(spacing: 8) {
                                ForEach(options) { option in
                                    HStack(alignment: .center, spacing: 12) {
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(formattedDate(from: option.dateChoice))
                                                .font(.subheadline.weight(.semibold))
                                            
                                            Text("\(option.voteCount) vote\(option.voteCount == 1 ? "" : "s")")
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                        
                                        Spacer()
                                        
                                        if option.youVoted {
                                            HStack(spacing: 4) {
                                                Image(systemName: "checkmark.circle.fill")
                                                    .font(.caption)
                                                Text("Your vote")
                                            }
                                            .font(.caption.bold())
                                            .padding(.horizontal, 8)
                                            .padding(.vertical, 4)
                                            .background(Color.purple.opacity(0.12))
                                            .foregroundColor(.purple)
                                            .cornerRadius(10)
                                        }
                                    }
                                    .padding(10)
                                    .background(Color.white)
                                    .cornerRadius(14)
                                    .shadow(color: .black.opacity(0.03), radius: 3, y: 2)
                                }
                            }
                        }
                        .padding()
                        .background(Color.white.opacity(0.95))
                        .cornerRadius(18)
                        .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
                        .padding(.horizontal)
                    }
                    
                    // Date picker card
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Pick a date & time")
                            .font(.subheadline.bold())
                            .foregroundColor(.primary)
                        
                        DatePicker(
                            "",
                            selection: $selectedDate,
                            displayedComponents: [.date, .hourAndMinute]
                        )
                        .datePickerStyle(.graphical)
                        .background(Color.white)
                        .cornerRadius(18)
                    }
                    .padding()
                    .background(Color.white.opacity(0.95))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
                    .padding(.horizontal)
                    
                    if let errorMessage {
                        Text(errorMessage)
                            .font(.footnote)
                            .foregroundColor(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal)
                    }
                    
                    // Submit button
                    Button(action: submitVote) {
                        HStack {
                            if isSubmitting {
                                ProgressView()
                            } else {
                                Image(systemName: "paperplane.fill")
                                Text("Submit Date Vote")
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple.opacity(0.9))
                        .foregroundColor(.white)
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.18), radius: 6, y: 3)
                    }
                    .disabled(isSubmitting)
                    .padding(.horizontal)
                    
                    Spacer(minLength: 30)
                }
            }
        }
        .navigationTitle("Pick a Date")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            loadVotes()
        }
    }
    
    //Functions
    private func submitVote() {
        isSubmitting = true
        errorMessage = nil
        
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        
        let dateString = formatter.string(from: selectedDate)
        
        APIService.shared.voteForDate(
            roundID: round.roundID,
            userID: currentUserID,
            dateChoice: dateString
        ) { success in
            DispatchQueue.main.async {
                isSubmitting = false
                if success {
                    loadVotes()
                } else {
                    errorMessage = "You might have already voted for this round."
                }
            }
        }
    }
    
    private func loadVotes() {
        APIService.shared.fetchDateVotes(
            roundID: round.roundID,
            userID: currentUserID
        ) { items in
            DispatchQueue.main.async {
                self.options = items
            }
        }
    }
    
    private func formattedDate(from raw: String) -> String {
        let inF = DateFormatter()
        inF.locale = Locale(identifier: "en_US_POSIX")
        inF.timeZone = .current
        inF.dateFormat = "yyyy-MM-dd HH:mm"
        
        let outF = DateFormatter()
        outF.locale = .current
        outF.timeZone = .current
        outF.dateStyle = .medium
        outF.timeStyle = .short
        
        if let d = inF.date(from: raw) {
            return outF.string(from: d)
        } else {
            return raw
        }
    }
}

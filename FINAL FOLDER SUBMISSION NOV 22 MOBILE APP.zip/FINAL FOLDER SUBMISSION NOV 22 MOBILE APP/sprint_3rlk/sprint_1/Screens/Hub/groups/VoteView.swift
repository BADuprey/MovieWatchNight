import SwiftUI

struct VoteView: View {
    let group: Group
    let currentUserID: Int

    @State private var suggestions: [MovieSuggestion] = []
    @State private var isLoading = false
    @State private var isSubmitting = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 16) {
            if isLoading {
                ProgressView("Loading suggestions...")
                    .padding()
            } else if suggestions.isEmpty {
                Text("No suggestions yet for this group.")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List {
                    ForEach(suggestions) { suggestion in
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(suggestion.movieTitle)
                                    .font(.headline)
                                Text("Suggested by \(suggestion.suggestedBy)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            VStack(alignment: .trailing, spacing: 4) {
                                Text("\(suggestion.voteCount) votes")
                                    .font(.caption)
                                Button("Vote") {
                                    vote(for: suggestion)
                                }
                                .disabled(isSubmitting)
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }

            if let errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }
        }
        .navigationTitle("Vote on Movies")
        .onAppear(perform: loadSuggestions)
    }

    //functions
    private func loadSuggestions() {
        isLoading = true
        errorMessage = nil
        APIService.shared.fetchSuggestions(groupID: group.groupID) { suggestions in
            DispatchQueue.main.async {
                self.suggestions = suggestions
                self.isLoading = false
            }
        }
    }

    private func vote(for suggestion: MovieSuggestion) {
        isSubmitting = true
        errorMessage = nil

        APIService.shared.voteForMovie(suggestionID: suggestion.suggestionID, userID: currentUserID) { success in
            DispatchQueue.main.async {
                isSubmitting = false
                if success {
                    loadSuggestions()
                } else {
                    errorMessage = "You have already voted this round."
                }
            }
        }
    }
}

import SwiftUI

struct AccountView: View {
    let username: String
    let userID: Int
    let onLogout: () -> Void

    @State private var email: String = ""
    @State private var isLoading = false

    private var gradientBackground: LinearGradient {
        LinearGradient(
            colors: [
                Color(red: 0.93, green: 0.97, blue: 1.0),
                Color.white
            ],
            startPoint: .top,
            endPoint: .bottom
        )
    }

    var body: some View {
        NavigationStack {
            ZStack {
                gradientBackground.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 18) {

                        // Top profile card
                        profileHeaderCard

                        // Account details / loading state
                        if isLoading {
                            loadingCard
                        } else {
                            detailsCard
                        }

                        // Logout button card
                        logoutCard

                        Spacer(minLength: 30)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 20)
                }
            }
            .navigationTitle("Account")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear(perform: loadUser)
        }
    }

    //Cards
    private var profileHeaderCard: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.white)
                    .frame(width: 56, height: 56)
                    .shadow(color: .black.opacity(0.08), radius: 6, y: 4)

                Text(username.isEmpty ? "🙂" : String(username.prefix(1)).uppercased())
                    .font(.title2.bold())
                    .foregroundColor(Color(red: 0.11, green: 0.42, blue: 0.87))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(username.isEmpty ? "Guest" : username)
                    .font(.title3.bold())
                    .foregroundColor(.primary)

                Text("Movie Watch Night")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }

            Spacer()
        }
        .padding(18)
        .background(Color.white.opacity(0.9))
        .background(.ultraThinMaterial)
        .cornerRadius(20)
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
    }

    private var loadingCard: some View {
        HStack {
            ProgressView()
            Text("Loading account…")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .center)
        .padding(18)
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.04), radius: 6, y: 3)
    }

    private var detailsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            infoRow(label: "Username", value: username)
            Divider().padding(.vertical, 2)
            infoRow(label: "User ID", value: "\(userID)")

            if !email.isEmpty {
                Divider().padding(.vertical, 2)
                infoRow(label: "Email", value: email)
            }
        }
        .padding(18)
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.04), radius: 6, y: 3)
    }

    private func infoRow(label: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label.uppercased())
                .font(.caption2)
                .fontWeight(.semibold)
                .foregroundColor(.secondary)

            Text(value)
                .font(.body)
                .foregroundColor(.primary)
        }
    }

    private var logoutCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Session")
                .font(.headline)
                .foregroundColor(.primary)

            Text("You’re currently signed in. You can log out of Movie Watch Night below.")
                .font(.footnote)
                .foregroundColor(.secondary)

            Button(role: .destructive) {
                onLogout()
            } label: {
                HStack {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                    Text("Log Out")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
            }
            .buttonStyle(.borderedProminent)
            .tint(.red.opacity(0.9))
        }
        .padding(18)
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.04), radius: 6, y: 3)
    }

    //User's data

    private func loadUser() {
        guard !username.isEmpty else { return }
        isLoading = true

        APIService.shared.fetchUser(username: username) { profile in
            DispatchQueue.main.async {
                self.isLoading = false
                self.email = profile?.email ?? ""
            }
        }
    }
}

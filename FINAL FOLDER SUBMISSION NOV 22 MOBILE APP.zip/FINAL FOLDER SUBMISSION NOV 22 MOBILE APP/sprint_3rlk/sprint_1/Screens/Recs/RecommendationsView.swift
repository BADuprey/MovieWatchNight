import SwiftUI

struct RecommendationsView: View {
    let userID: Int

    @State private var movies: [MovieSummary] = []
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    // for choosing which list to add to
    @State private var showAddSheet = false
    @State private var moviePendingAdd: MovieSummary?

    // small feedback text (like i mean “Added…”, “Already in…”, etc)
    @State private var feedbackMessage: String?
    @State private var feedbackColor: Color = .secondary

    // Sort movies by rating (high to low)
    private var rankedMovies: [MovieSummary] {
        movies.sorted { (lhs, rhs) in
            let l = lhs.rating ?? 0
            let r = rhs.rating ?? 0
            return l > r
        }
    }

    private var topPick: MovieSummary? {
        rankedMovies.first
    }

    private var otherPicks: [MovieSummary] {
        Array(rankedMovies.dropFirst())
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {

                    // MAIN RECOMMENDATION CARD = highest rating
                    if let topMovie = topPick {
                        NavigationLink {
                            MovieDetailView(movieID: topMovie.movieID, userID: userID)
                        } label: {
                            mainRecommendationCard(for: topMovie)
                        }
                        .buttonStyle(.plain)
                    } else {
                        emptyRecommendationCard
                    }

                    // ERROR / INFO
                    if let message = errorMessage {
                        Text(message)
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 8)
                    }

                    if let feedback = feedbackMessage {
                        Text(feedback)
                            .font(.footnote)
                            .foregroundColor(feedbackColor)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 8)
                    }

                    // MORE PICKS = rest of group, sorted by rating
                    if !otherPicks.isEmpty {
                        HStack {
                            Text("More picks for you")
                                .font(.headline)
                            Spacer()
                        }
                        .padding(.top, 4)

                        ForEach(otherPicks) { movie in
                            NavigationLink {
                                MovieDetailView(movieID: movie.movieID, userID: userID)
                            } label: {
                                recommendationRow(movie)
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    Spacer(minLength: 24)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
            }
            .background(Color(red: 0.95, green: 0.96, blue: 0.99).ignoresSafeArea())
            .navigationTitle("Recommendations")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    if isLoading {
                        ProgressView()
                    } else {
                        Button {
                            loadRecommendations()
                        } label: {
                            Image(systemName: "arrow.clockwise")
                        }
                    }
                }
            }
            .onAppear {
                if movies.isEmpty {
                    loadRecommendations()
                }
            }
            // choose which list to add to (either ignore or watch)
            .confirmationDialog(
                "Add to which list?",
                isPresented: $showAddSheet,
                presenting: moviePendingAdd
            ) { movie in
                Button("Watch / Favorite List") {
                    addMovie(movie, toAnti: false)
                }
                Button("Ignore List") {
                    addMovie(movie, toAnti: true)
                }
                Button("Cancel", role: .cancel) { }
            } message: { movie in
                Text("Add \"\(movie.title)\" to a list.")
            }
        }
    }

    // recommmendation card for top pick (this is the movie with the hhighest rating)
    private func mainRecommendationCard(for movie: MovieSummary) -> some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.11, green: 0.42, blue: 0.87),
                    Color(red: 0.22, green: 0.74, blue: 0.95)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .cornerRadius(20)
            .shadow(color: Color(red: 0.11, green: 0.42, blue: 0.87).opacity(0.35),
                    radius: 10, y: 6)

            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    HStack(spacing: 4) {
                        Image(systemName: "sparkles")
                        Text("Top pick")
                    }
                    .font(.caption.bold())
                    .foregroundColor(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.white.opacity(0.18))
                    .clipShape(Capsule())

                    Spacer()
                    Text("🍿")
                        .font(.title2)
                }

                Text(movie.title)
                    .foregroundColor(.white)
                    .font(.title3.weight(.semibold))
                    .multilineTextAlignment(.leading)

                HStack(spacing: 10) {
                    if let rating = movie.rating {
                        Text("⭐️ \(rating, specifier: "%.1f")")
                    }
                    if let release = movie.release, !release.isEmpty {
                        Text(release)
                    }
                }
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.9))

                Text("Tap to see more about this movie.")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.9))
                    .padding(.top, 2)
            }
            .padding(18)
        }
        .frame(maxWidth: .infinity)
    }

    private var emptyRecommendationCard: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.11, green: 0.42, blue: 0.87),
                    Color(red: 0.22, green: 0.74, blue: 0.95)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .cornerRadius(20)
            .shadow(color: Color(red: 0.11, green: 0.42, blue: 0.87).opacity(0.35),
                    radius: 10, y: 6)

            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    HStack(spacing: 4) {
                        Image(systemName: "sparkles")
                        Text("Recommendations")
                    }
                    .font(.caption.bold())
                    .foregroundColor(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.white.opacity(0.18))
                    .clipShape(Capsule())

                    Spacer()
                    Text("🎬")
                        .font(.title2)
                }

                Text("Tap the refresh button to get your first recommendations!")
                    .foregroundColor(.white)
                    .font(.title3.weight(.semibold))
                    .multilineTextAlignment(.leading)
            }
            .padding(18)
        }
        .frame(maxWidth: .infinity)
    }

    // recommendation cards for "More picks"
    private func recommendationRow(_ movie: MovieSummary) -> some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.white)
                    .frame(width: 40, height: 40)
                    .shadow(color: Color.black.opacity(0.04), radius: 4, y: 2)

                Text(String(movie.title.prefix(1)))
                    .font(.headline.bold())
                    .foregroundColor(Color(red: 0.11, green: 0.42, blue: 0.87))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(movie.title)
                    .font(.headline)

                HStack(spacing: 8) {
                    if let rating = movie.rating {
                        Label("\(rating, specifier: "%.1f")", systemImage: "star.fill")
                    }
                    if let release = movie.release, !release.isEmpty {
                        Label(release, systemImage: "calendar")
                    }
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }

            Spacer()

            // "add" button. This will open “which list?” question so that user can pick ignore/watch
            Button {
                moviePendingAdd = movie
                showAddSheet = true
            } label: {
                Image(systemName: "plus.circle.fill")
                    .font(.title3)
            }
            .buttonStyle(.plain)
        }
        .padding(12)
        .background(Color.white)
        .cornerRadius(14)
        .shadow(color: Color.black.opacity(0.03), radius: 5, y: 3)
    }

    // Loading info from database
    private func loadRecommendations() {
        isLoading = true
        errorMessage = nil
        feedbackMessage = nil

        let idToSend: Int? = (userID > 0) ? userID : nil

        APIService.shared.fetchRecommendations(userID: idToSend) { recs in
            DispatchQueue.main.async {
                self.isLoading = false
                if recs.isEmpty {
                    self.movies = []
                    self.errorMessage = "No recommendations yet. Try adding movies to your lists or check again later."
                } else {
                    self.movies = recs
                    self.errorMessage = nil
                }
            }
        }
    }

    // Add to watch/ignore, but skip duplicates in that list
    private func addMovie(_ movie: MovieSummary, toAnti: Bool) {
        guard userID > 0 else { return }

        // Load the chosen list to see if the movie is already there
        APIService.shared.getWatchList(
            ownerID: userID,
            isGroupList: false,
            isAntiList: toAnti
        ) { existing in
            let already = existing.contains { $0.movieID == movie.movieID }

            if already {
                DispatchQueue.main.async {
                    self.feedbackMessage = toAnti
                        ? "That movie is already in your Ignore List."
                        : "That movie is already in your Watch List."
                    self.feedbackColor = .orange
                }
                return
            }

            // Actually add to list
            APIService.shared.addToWatchList(
                ownerID: userID,
                movieID: movie.movieID,
                isGroupList: false,
                isAntiList: toAnti
            ) { success in
                DispatchQueue.main.async {
                    if success {
                        self.feedbackMessage = toAnti
                            ? "Added to your Ignore List."
                            : "Added to your Watch List."
                        self.feedbackColor = .green
                    } else {
                        self.feedbackMessage = "Could not add movie. Please try again."
                        self.feedbackColor = .red
                    }
                }
            }
        }
    }
}

#Preview {
    RecommendationsView(userID: 1)
}

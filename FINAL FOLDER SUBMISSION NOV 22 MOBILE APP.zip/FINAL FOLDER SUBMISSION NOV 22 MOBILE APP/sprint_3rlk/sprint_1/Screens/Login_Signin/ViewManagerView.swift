import SwiftUI

struct ViewManagerView: View {
    enum Views {
        case logInView
        case newUserView
        case forgotPasswordView
    }

    @State private var currentView = Views.logInView
    @Binding var isLoggedIn: Bool
    @Binding var currentUsername: String
    @Binding var currentUserID: Int 

    var body: some View {
        VStack {
            switch currentView {
            case .logInView:
                LogInView(
                    isLoggedIn: $isLoggedIn,
                    currentUsername: $currentUsername,
                    currentUserID: $currentUserID
                )
            case .newUserView:
                NewUserView()
            case .forgotPasswordView:
                ForgotPasswordView()
            }

            Spacer()

            VStack {
                if currentView == .logInView {
                    Button("Forgot Password?") {
                        currentView = .forgotPasswordView
                    }
                    .padding(10)

                    Button("New User? Sign Up!") {
                        currentView = .newUserView
                    }
                    .padding(10)
                } else {
                    Button("Back <-") {
                        currentView = .logInView
                    }
                }
            }
        }
    }
}

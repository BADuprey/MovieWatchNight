import SwiftUI

struct LogoutView: View {
    let onLogout: () -> Void

    private var gradientBackground: LinearGradient {
        LinearGradient(
            colors: [
                Color(red: 0.93, green: 0.97, blue: 1.0),
                Color.white
            ],
            startPoint: .top,
            endPoint: .bottom
        )
    }

    var body: some View {
        NavigationStack {
            ZStack {
                gradientBackground.ignoresSafeArea()

                VStack {
                    Spacer(minLength: 40)

                    VStack(spacing: 16) {
                        HStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(Color.white)
                                    .frame(width: 46, height: 46)
                                    .shadow(color: .black.opacity(0.05), radius: 5, y: 3)

                                Image(systemName: "person.fill")
                                    .foregroundColor(Color(red: 0.11, green: 0.42, blue: 0.87))
                                    .font(.title3)
                            }

                            VStack(alignment: .leading, spacing: 4) {
                                Text("You’re signed in")
                                    .font(.headline)
                                Text("Log out of Movie Watch Night on this device.")
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }

                            Spacer()
                        }

                        Button(role: .destructive) {
                            onLogout()
                        } label: {
                            HStack {
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                Text("Log Out")
                                    .fontWeight(.semibold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.red.opacity(0.95))

                        Text("You can always sign back in with your username and password.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(20)
                    .background(Color.white.opacity(0.95))
                    .background(.ultraThinMaterial)
                    .cornerRadius(20)
                    .shadow(color: .black.opacity(0.08), radius: 10, y: 6)
                    .padding(.horizontal, 24)

                    Spacer()
                }
            }
            .navigationTitle("Log Out")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

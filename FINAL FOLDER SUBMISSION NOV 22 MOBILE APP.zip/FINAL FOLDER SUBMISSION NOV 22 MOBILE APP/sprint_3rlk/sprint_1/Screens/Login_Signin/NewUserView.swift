import SwiftUI

struct NewUserView: View {
    @State private var username: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var confirmedPassword: String = ""

    @State private var showWarning = false
    @State private var warningText = ""
    @State private var isLoading = false
    @State private var signupOK = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.93, green: 0.97, blue: 1.0),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack {
                Spacer(minLength: 40)

                Text("Sign Up")
                    .font(.largeTitle.bold())
                    .foregroundColor(.primary)

                Text("Create your Movie Watch Night account")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding(.bottom, 12)

                // CARD
                VStack(spacing: 14) {
                    // Username
                    HStack {
                        Image(systemName: "person")
                            .foregroundColor(.blue)
                        TextField("Username", text: $username)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                    }
                    .padding(12)
                    .background(textFieldBG)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.03), radius: 3, y: 1)

                    // Email
                    HStack {
                        Image(systemName: "envelope")
                            .foregroundColor(.blue)
                        TextField("Email (@gmail.com)", text: $email)
                            .keyboardType(.emailAddress)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                    }
                    .padding(12)
                    .background(textFieldBG)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.03), radius: 3, y: 1)

                    // Password
                    HStack {
                        Image(systemName: "lock")
                            .foregroundColor(.blue)
                        SecureField("Password", text: $password)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .textContentType(.oneTimeCode)
                    }
                    .padding(12)
                    .background(textFieldBG)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.03), radius: 3, y: 1)

                    // Confirm Password
                    HStack {
                        Image(systemName: "lock.rotation")
                            .foregroundColor(.blue)
                        SecureField("Confirm Password", text: $confirmedPassword)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .textContentType(.oneTimeCode)
                    }
                    .padding(12)
                    .background(textFieldBG)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.03), radius: 3, y: 1)

                    // Password rule hint
                    VStack(alignment: .leading, spacing: 2) {
                        Text("• Password must be at least 8 characters")
                        Text("• Must contain at least one number (0–9)")
                        Text("• Must contain at least one symbol (e.g. ! ? # &)")
                        Text("• Email must end with @gmail.com")
                    }
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                    if showWarning {
                        Text(warningText)
                            .foregroundColor(.red)
                            .font(.caption)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    if signupOK {
                        Text("Account created!")
                            .foregroundColor(.green)
                            .font(.caption)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    Button(action: makeUser) {
                        HStack {
                            if isLoading {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Text("Sign Up")
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(canSubmit ? Color.green.opacity(0.9) : Color.green.opacity(0.45))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(!canSubmit || isLoading)
                }
                .padding(20)
                .background(Color.white.opacity(0.4))
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                .padding(.horizontal, 26)

                Spacer()
            }
        }
    }

    private var canSubmit: Bool {
        !username.isEmpty &&
        !email.isEmpty &&
        !password.isEmpty &&
        !confirmedPassword.isEmpty
    }

    //Validation helpers

    private func isValidEmail(_ email: String) -> Bool {
        let lower = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let suffix = "@gmail.com"
        guard lower.hasSuffix(suffix) else { return false }
        // something before @
        return lower.count > suffix.count
    }

    private func isStrongPassword(_ password: String) -> Bool {
        let trimmed = password.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 8 else { return false }

        // at least one special symbol
        let specials = CharacterSet.punctuationCharacters.union(.symbols)
        guard trimmed.rangeOfCharacter(from: specials) != nil else { return false }

        // at least one number
        let digits = CharacterSet.decimalDigits
        guard trimmed.rangeOfCharacter(from: digits) != nil else { return false }

        return true
    }


    //Sign up

    private func makeUser() {
        showWarning = false
        signupOK = false
        warningText = ""

        guard !username.isEmpty, !email.isEmpty, !password.isEmpty, !confirmedPassword.isEmpty else {
            showWarning = true
            warningText = "Please fill in all fields."
            return
        }

        guard isValidEmail(email) else {
            showWarning = true
            warningText = "Email must be a @gmail.com address."
            return
        }

        guard isStrongPassword(password) else {
            showWarning = true
            warningText = "Password must be at least 8 characters and include a number and a symbol (e.g. 3, !, ? , #, &)."
            return
        }

        guard password == confirmedPassword else {
            showWarning = true
            warningText = "Passwords do not match."
            return
        }

        isLoading = true

        APIService.shared.signup(username: username, password: password, email: email) { success in
            DispatchQueue.main.async {
                self.isLoading = false
                if success {
                    self.signupOK = true
                    self.showWarning = false
                } else {
                    self.showWarning = true
                    self.warningText = "Username already taken or server error."
                }
            }
        }
    }
}

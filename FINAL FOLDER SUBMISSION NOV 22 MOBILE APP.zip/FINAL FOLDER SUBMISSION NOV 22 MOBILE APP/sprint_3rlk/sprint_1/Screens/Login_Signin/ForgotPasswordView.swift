import SwiftUI

struct ForgotPasswordView: View {
    @State private var username: String = ""
    @State private var isLoading = false
    @State private var successMessage: String?
    @State private var errorMessage: String?
    @State private var maskedEmail: String?

    @State private var showReset = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.93, green: 0.97, blue: 1.0),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack {
                Spacer(minLength: 40)

                Text("Forgot Password")
                    .font(.largeTitle.bold())
                    .foregroundColor(.primary)

                Text("Enter your username and we’ll look up your account.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
                    .padding(.bottom, 12)

                // card
                VStack(spacing: 14) {
                    // username field
                    HStack {
                        Image(systemName: "person.fill.questionmark")
                            .foregroundColor(.blue)
                        TextField("Username", text: $username)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                    }
                    .padding(12)
                    .background(textFieldBG)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.03), radius: 3, y: 1)

                    // messages
                    if let success = successMessage {
                        VStack(alignment: .leading, spacing: 4) {
                            HStack(spacing: 6) {
                                Image(systemName: "checkmark.seal.fill")
                                    .foregroundColor(.green)
                                Text(success)
                            }
                            .font(.subheadline)
                            .foregroundColor(.green)

                            if let maskedEmail {
                                Text("Account found: \(maskedEmail)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }

                            Button {
                                showReset = true
                            } label: {
                                Text("Reset password now")
                                    .font(.subheadline.bold())
                            }
                            .padding(.top, 4)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .transition(.opacity)
                    }

                    if let error = errorMessage {
                        HStack(spacing: 6) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundColor(.red)
                            Text(error)
                        }
                        .font(.caption)
                        .foregroundColor(.red)
                        .transition(.opacity)
                    }

                    // button
                    Button(action: verifyUser) {
                        HStack {
                            if isLoading {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Text("Check Account")
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(username.isEmpty ? Color.blue.opacity(0.35) : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(username.isEmpty || isLoading)
                }
                .padding(20)
                .background(Color.white.opacity(0.4))
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                .padding(.horizontal, 26)

                Spacer()
            }
            .sheet(isPresented: $showReset) {
                ResetPasswordView(username: username)
            }
        }
    }

    private func verifyUser() {
        errorMessage = nil
        successMessage = nil
        maskedEmail = nil
        isLoading = true

        APIService.shared.forgotPassword(username: username) { ok, email in
            DispatchQueue.main.async {
                self.isLoading = false
                if ok {
                    self.successMessage = "Account found!"
                    if let email, !email.isEmpty {
                        self.maskedEmail = maskEmail(email)
                    } else {
                        self.maskedEmail = "••••@example.com"
                    }
                } else {
                    self.errorMessage = "We couldn’t find that username."
                }
            }
        }
    }

    private func maskEmail(_ email: String) -> String {
        let parts = email.split(separator: "@")
        guard parts.count == 2 else { return email }
        let name = parts[0]
        let domain = parts[1]
        if let first = name.first {
            return "\(first)•••@\(domain)"
        } else {
            return "•••@\(domain)"
        }
    }
}

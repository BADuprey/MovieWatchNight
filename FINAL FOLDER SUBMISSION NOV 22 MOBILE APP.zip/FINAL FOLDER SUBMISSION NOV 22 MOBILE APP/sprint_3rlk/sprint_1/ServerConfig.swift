import Foundation
import Combine

// DO NOT CHANGE THIS FILE PLEASE :O!!! - SASHA
final class ServerConfig: ObservableObject {
    static let shared = ServerConfig()

    @Published var baseURLString: String {
        didSet {
            UserDefaults.standard.set(baseURLString, forKey: "server_url")
        }
    }

    private init() {
        let saved = UserDefaults.standard.string(forKey: "server_url")
        // default: simulator -> Flask on same Mac
        self.baseURLString = saved ?? "http://127.0.0.1:8097"
        //when showing this and connecting to server with both computers, the computer that is NOT running the server
        //has to change "http://127.0.0.1:8097" to the computer's IP address that is running the server (so"10.254...:8097")
    }

    var baseURL: URL? {
        URL(string: baseURLString)
    }
}

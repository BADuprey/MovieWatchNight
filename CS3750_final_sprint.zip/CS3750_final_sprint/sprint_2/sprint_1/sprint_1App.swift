import SwiftUI

@main
struct sprint_1App: App {
    @State private var showSplash = true

    var body: some Scene {
        WindowGroup {
            if showSplash {
                PopcornSplashView {
                    showSplash = false
                }
            } else {
                ContentView()  
            }
        }
    }
}


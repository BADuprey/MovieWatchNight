import SwiftUI

// light bluish
let textFieldColor = Color.white
    .opacity(0.9)

//let textFieldColor = Color(red: 0.93, green: 0.97, blue: 1.0)


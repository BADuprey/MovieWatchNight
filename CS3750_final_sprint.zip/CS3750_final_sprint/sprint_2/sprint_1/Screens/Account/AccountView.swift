import SwiftUI

struct AccountView: View {
    let username: String
    let userID: Int
    let onLogout: () -> Void

    @State private var email: String = ""
    @State private var isLoading = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                if isLoading {
                    ProgressView("Loading account…")
                } else {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Username")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(username)
                            .font(.title3.bold())

                        Text("User ID")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("\(userID)")
                            .font(.body)

                        if !email.isEmpty {
                            Text("Email")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(email)
                                .font(.body)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(.systemBackground))
                    .cornerRadius(16)
                    .shadow(radius: 2)
                }

                Button(role: .destructive) {
                    onLogout()
                } label: {
                    Text("Log Out")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top)

                Spacer()
            }
            .padding()
            .navigationTitle("Account")
            .onAppear(perform: loadUser)
        }
    }

    private func loadUser() {
        guard !username.isEmpty else { return }
        isLoading = true
        APIService.shared.fetchUser(username: username) { profile in
            DispatchQueue.main.async {
                self.isLoading = false
                self.email = profile?.email ?? ""
            }
        }
    }
}


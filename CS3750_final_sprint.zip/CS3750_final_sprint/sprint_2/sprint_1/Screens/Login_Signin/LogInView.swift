import SwiftUI

let textFieldBG = Color.white

struct LogInView: View {
    @Binding var isLoggedIn: Bool
    @Binding var currentUsername: String
    @Binding var currentUserID: Int

    @State private var username: String = ""
    @State private var password: String = ""
    @State private var loginFailed = false
    @State private var isLoading = false

    var body: some View {
        ZStack {
            // background
            LinearGradient(
                colors: [
                    Color(red: 0.93, green: 0.97, blue: 1.0),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack {
                Spacer(minLength: 40)

                Text("Log In")
                    .font(.largeTitle.bold())
                    .foregroundColor(.primary)

                Text("Movie Watch Night")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding(.bottom, 12)

                // card
                VStack(spacing: 14) {
                    // username
                    HStack {
                        Image(systemName: "person")
                            .foregroundColor(.blue)
                        TextField("Username", text: $username)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                    }
                    .padding(12)
                    .background(textFieldBG)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.03), radius: 3, y: 1)

                    // password
                    HStack {
                        Image(systemName: "lock")
                            .foregroundColor(.blue)
                        SecureField("Password", text: $password)
                    }
                    .padding(12)
                    .background(textFieldBG)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.03), radius: 3, y: 1)

                    if loginFailed {
                        HStack(spacing: 6) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundColor(.red)
                            Text("Login failed. Check username/password.")
                        }
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.top, 2)
                    }

                    Button(action: handleLogin) {
                        HStack {
                            if isLoading {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Text("Log In")
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(canSubmit ? Color.blue : Color.blue.opacity(0.35))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(!canSubmit || isLoading)
                }
                .padding(20)
                .background(Color.white.opacity(0.4))
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                .padding(.horizontal, 26)

                Spacer()
            }
        }
    }

    private var canSubmit: Bool {
        !username.isEmpty && !password.isEmpty
    }

    private func handleLogin() {
        loginFailed = false
        isLoading = true

        APIService.shared.login(username: username, password: password) { success in
            DispatchQueue.main.async {
                if success {
                    self.currentUsername = self.username
                    self.isLoggedIn = true
                    self.isLoading = false


                    APIService.shared.fetchUser(username: self.username) { profile in
                        DispatchQueue.main.async {
                            if let profile = profile {
                                self.currentUsername = profile.username
                                self.currentUserID = profile.userID
                            }
                        }
                    }
                } else {
                    self.isLoading = false
                    self.loginFailed = true
                }
            }
        }
    }
}

//View for recommendations
import SwiftUI

struct RecommendationsView: View {
    var body: some View {
        NavigationStack {
            Text("Movie recommendations (placeholder)")
                .padding()
                .navigationTitle("Recommendations")
        }
    }
}

#Preview {
    RecommendationsView()
}

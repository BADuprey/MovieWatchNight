import SwiftUI

enum Tab : Hashable {
    case hub
    case recs
    case lists
    case schedules
    case account
    case logout
}

struct ContentView: View {
    @State private var selectedTab: Tab = .hub
    @State private var isLoggedIn: Bool = false
    @State private var currentUsername: String = "Jane Doe"
    @State private var currentUserID: Int = 0

    var body: some View {
        if isLoggedIn {
            TabView(selection: $selectedTab) {
                RecommendationsView()
                    .tabItem {
                        Image(systemName: "sparkles")
                        Text("Recs")
                    }.tag(Tab.recs)

                ListsView()
                    .tabItem {
                        Image(systemName: "list.bullet")
                        Text("Lists")
                    }.tag(Tab.lists)

                HubView(username: currentUsername)
                    .tabItem {
                        Image(systemName: "house.fill")
                        Text("Hub")
                    }.tag(Tab.hub)

                SchedulesView(userID: currentUserID)
                    .tabItem {
                        Image(systemName: "calendar")
                        Text("Schedules")
                    }.tag(Tab.schedules)

                AccountView(
                    username: currentUsername,
                    userID: currentUserID,
                    onLogout: {
                        isLoggedIn = false
                        selectedTab = .hub
                    }
                )
                .tabItem {
                    Image(systemName: "person.circle")
                    Text("Account")
                }
                .tag(Tab.account)

                LogoutView {
                    isLoggedIn = false
                    selectedTab = .hub
                }
                .tabItem {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                    Text("Log Out")
                }
                .tag(Tab.logout)
            }
        } else {
            ViewManagerView(
                isLoggedIn: $isLoggedIn,
                currentUsername: $currentUsername,
                currentUserID: $currentUserID
            )
        }
    }
}

#Preview {
    ContentView()
}


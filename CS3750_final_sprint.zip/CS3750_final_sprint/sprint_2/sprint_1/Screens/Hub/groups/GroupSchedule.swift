import SwiftUI

struct GroupSchedule: View {
    let groupName: String
    
    var body: some View {
        NavigationStack {
            Text("Group Schedule for \(groupName)")
                .padding()

        }
    }
}

#Preview {
    GroupSchedule(groupName: "Example Group")
}

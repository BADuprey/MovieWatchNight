import SwiftUI

struct DetailedGroupView: View {
    let group: Group
    let currentUserID: Int

    @State private var currentRound: VotingRoundInfo?
    @State private var isLoadingRound = false

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {

                // Header
                VStack(spacing: 8) {
                    Text(group.name)
                        .font(.largeTitle)
                        .bold()

                    Text("Group ID: \(group.groupID)")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 20)

                // Podium
                VStack(alignment: .leading, spacing: 10) {
                    Text("Top Movies")
                        .font(.title2)
                        .bold()
                    PodiumView(groupID: group.groupID)
                }

                // Schedule
                HStack(spacing: 16) {
                    NavigationLink(destination: GroupSchedule(groupName: group.name)) {
                        Text("Schedule")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 1, y: 1)
                    }


                }

                // Vote on Movies
                VStack(spacing: 16) {
                    NavigationLink(destination: SuggestMovieView(group: group, currentUserID: currentUserID)) {
                        Text("Suggest a Movie")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green.opacity(0.35))
                            .cornerRadius(10)
                            .shadow(radius: 1, y: 1)
                    }

                    NavigationLink(destination: VoteView(group: group, currentUserID: currentUserID)) {
                        Text("Vote on Movies")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue.opacity(0.35))
                            .cornerRadius(10)
                            .shadow(radius: 1, y: 1)
                    }
                }

                // Date voting / result section
                if isLoadingRound {
                    ProgressView("Checking round status…")
                } else if let round = currentRound {
                    if let winningDate = round.winningDate, round.isComplete {
                        VStack(spacing: 8) {
                            Text("Movie Night Scheduled")
                                .font(.headline)
                            Text("\(round.movieTitle) on \(winningDate)")
                                .foregroundColor(.secondary)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 1, y: 1)
                    } else {
                        VStack(spacing: 10) {
                            Text("Next Step: Pick a Date for \(round.movieTitle)")
                                .font(.headline)
                            NavigationLink(destination: DateVoteView(group: group, round: round, currentUserID: currentUserID)) {
                                Text("Vote on Date")
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.purple.opacity(0.35))
                                    .cornerRadius(10)
                                    .shadow(radius: 1, y: 1)
                            }
                        }
                    }
                }

                Spacer(minLength: 40)
            }
            .padding()
        }
        .navigationTitle(group.name)
        .background(Color(.systemGroupedBackground))
        .onAppear(perform: loadRound)
    }

    private func loadRound() {
        isLoadingRound = true
        APIService.shared.fetchCurrentRound(groupID: group.groupID) { round in
            DispatchQueue.main.async {
                self.currentRound = round
                self.isLoadingRound = false
            }
        }
    }
}

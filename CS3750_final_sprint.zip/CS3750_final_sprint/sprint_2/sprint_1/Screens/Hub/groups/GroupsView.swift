import SwiftUI

struct GroupsView: View {

    @State private var groups: [Group] = []
    @State private var isLoading = false
    @State private var showAddGroup = false
    @State private var errorMessage: String?

    let userID: Int

    var body: some View {
        NavigationStack {
            VStack {
                if isLoading {
                    ProgressView("Loading groups...")
                        .padding()
                } else if groups.isEmpty {
                    VStack(spacing: 10) {
                        Text("Join a group!")
                            .font(.headline)
                            .foregroundColor(.gray)

                        Button(action: { showAddGroup = true }) {
                            Text("Create Group")
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.blue.opacity(0.2))
                                .cornerRadius(10)
                        }
                        .padding(.horizontal)
                    }
                    .padding(.top, 40)
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(groups) { group in
                                NavigationLink(destination:
                                    DetailedGroupView(
                                        group: group,
                                        currentUserID: userID
                                    )
                                ) {
                                    HStack {
                                        Text(group.name)
                                            .font(.headline)
                                        Spacer()
                                        Image(systemName: "chevron.right")
                                            .foregroundColor(.gray)
                                    }
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.white)
                                    .cornerRadius(12)
                                    .shadow(radius: 1, y: 1)
                                }
                            }
                        }
                        .padding()
                    }
                }

                Spacer()
            }
            .navigationTitle("My Groups")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: { showAddGroup = true }) {
                        Image(systemName: "plus")
                            .font(.title2)
                    }
                }
            }
            .sheet(isPresented: $showAddGroup, onDismiss: loadGroups) {
                AddGroupView(userID: userID, onAdd: loadGroups)
            }
            .onAppear(perform: loadGroups)
        }
    }

    // Load groups
    private func loadGroups() {
        isLoading = true
        errorMessage = nil

        APIService.shared.fetchGroups(userID: userID) { groups in
            DispatchQueue.main.async {
                self.groups = groups
                self.isLoading = false
            }
        }
    }
}

#Preview {
    GroupsView(userID: 1)
}

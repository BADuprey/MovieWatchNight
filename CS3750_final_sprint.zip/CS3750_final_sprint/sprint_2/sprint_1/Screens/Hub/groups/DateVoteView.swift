import SwiftUI

struct DateVoteView: View {
    let group: Group
    let round: VotingRoundInfo
    let currentUserID: Int

    @Environment(\.dismiss) private var dismiss
    @State private var selectedDate = Date()
    @State private var isSubmitting = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 20) {
            Text("Vote on a Date")
                .font(.largeTitle)
                .bold()

            Text("Movie: \(round.movieTitle)")
                .font(.headline)
                .foregroundColor(.secondary)

            DatePicker(
                "Pick a date",
                selection: $selectedDate,
                displayedComponents: .date
            )
            .datePickerStyle(.graphical)
            .padding()

            if let errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }

            Button(action: submitVote) {
                if isSubmitting {
                    ProgressView()
                } else {
                    Text("Submit Date Vote")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .padding(.horizontal)
            .disabled(isSubmitting)

            Spacer()
        }
        .padding()
        .navigationTitle("Pick a Date")
    }

    private func submitVote() {
        isSubmitting = true
        errorMessage = nil

        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let dateString = formatter.string(from: selectedDate)

        APIService.shared.voteForDate(roundID: round.roundID, userID: currentUserID, dateChoice: dateString) { success in
            DispatchQueue.main.async {
                isSubmitting = false
                if success {
                    dismiss()
                } else {
                    errorMessage = "You might have already voted for this round."
                }
            }
        }
    }
}

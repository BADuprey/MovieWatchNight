import SwiftUI

struct InfoView: View {
    let userID: Int  // to see who is logged in

    // optional movie info coming from Hub
    var movieTitle: String? = nil
    var movieID: Int? = nil

    @State private var genres: [String] = []
    @State private var isLoading = true
    @State private var message: String?

    // feedback when adding from "Selected movie" section
    @State private var addStatus: String?

    private let backgroundColor = Color(red: 0.95, green: 0.96, blue: 0.99)

    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()

            List {
                // if we came from the hub with a movie, show it first
                if let movieTitle = movieTitle {
                    Section("Selected movie") {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(movieTitle)
                                .font(.headline)

                            if let movieID = movieID {
                                Text("ID: \(movieID)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }

                            Text("Browse genres below to find similar movies, or add this movie to a list.")
                                .font(.caption)
                                .foregroundColor(.secondary)

                            // buttons to add the movie by MovieID
                            if let _ = movieID, userID > 0 {
                                HStack(spacing: 10) {
                                    Button {
                                        addMovieToList(isAnti: false)
                                    } label: {
                                        Label("Add to Watch List", systemImage: "heart.fill")
                                            .font(.caption.bold())
                                    }
                                    .buttonStyle(.borderedProminent)

                                    Button {
                                        addMovieToList(isAnti: true)
                                    } label: {
                                        Label("Add to Ignore List", systemImage: "hand.thumbsdown.fill")
                                            .font(.caption.bold())
                                    }
                                    .buttonStyle(.bordered)
                                }
                                .padding(.top, 4)

                                if let addStatus {
                                    Text(addStatus)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }

                if let message = message {
                    Section {
                        Text(message)
                            .foregroundColor(.red)
                    }
                } else if isLoading {
                    Section {
                        HStack {
                            ProgressView()
                            Text("Loading genres...")
                        }
                    }
                } else if genres.isEmpty {
                    Section {
                        Text("No genres returned from server.")
                            .foregroundColor(.secondary)
                    }
                } else {
                    Section("Genres") {
                        ForEach(genres, id: \.self) { genre in
                            NavigationLink {
                                GenreMoviesView(genre: genre, userID: userID)
                            } label: {
                                HStack {
                                    Text(genre)
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .listStyle(.insetGrouped)
        }
        .navigationTitle(movieTitle == nil ? "Genres" : "Movie info")
        .onAppear {
            APIService.shared.fetchGenres { result in
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.genres = result
                    if result.isEmpty {
                        self.message = "Got empty list from /genres"
                    }
                }
            }
        }
    }

    //Add movie to watch / ignore list
    private func addMovieToList(isAnti: Bool) {
        guard userID > 0, let movieID = movieID else { return }

        APIService.shared.addToWatchList(
            ownerID: userID,
            movieID: movieID,
            isGroupList: false,   // personal list
            isAntiList: isAnti    // false = watch and true = ignore
        ) { success in
            DispatchQueue.main.async {
                if success {
                    self.addStatus = isAnti
                        ? "Added to your Ignore List."
                        : "Added to your Watch List."
                } else {
                    self.addStatus = "That movie is already in this list or could not be added."
                }
            }
        }
    }

}

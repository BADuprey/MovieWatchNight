import SwiftUI

struct MovieDetailView: View {
    let movieID: Int
    let userID: Int

    @State private var detail: MovieDetail?
    @State private var isLoading = true

    @State private var showAddSheet = false
    @State private var feedbackMessage: String?
    @State private var feedbackColor: Color = .secondary

    private var backgroundGradient: LinearGradient {
        LinearGradient(
            colors: [
                Color(red: 0.93, green: 0.96, blue: 1.0),
                Color(red: 0.86, green: 0.91, blue: 0.99)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    var body: some View {
        ZStack {
            backgroundGradient.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {
                    if isLoading {
                        HStack {
                            ProgressView()
                            Text("Loading…")
                        }
                        .padding()
                    } else if let detail = detail {
                        VStack(alignment: .leading, spacing: 12) {
                            // Title
                            Text(detail.title)
                                .font(.title2.bold())

                            // Rating / release row
                            HStack(spacing: 12) {
                                if let rating = detail.rating {
                                    Text("⭐️ \(rating, specifier: "%.1f")")
                                }
                                if let release = detail.release {
                                    Text(release)
                                }
                            }
                            .font(.subheadline)
                            .foregroundColor(.secondary)

                            Divider()

                            Text("Overview")
                                .font(.headline)

                            if let overview = detail.overview, !overview.isEmpty {
                                Text(overview)
                                    .font(.body)
                            } else {
                                Text("No overview available.")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }

                            if let feedback = feedbackMessage {
                                Text(feedback)
                                    .font(.footnote)
                                    .foregroundColor(feedbackColor)
                                    .padding(.top, 4)
                            }
                        }
                        .padding(16)
                        .background(Color.white)
                        .cornerRadius(16)
                        .shadow(color: Color.black.opacity(0.08), radius: 4, y: 2)
                        .padding(.horizontal, 16)
                        .padding(.top, 12)
                    } else {
                        Text("Movie not found")
                            .foregroundColor(.secondary)
                            .padding()
                    }

                    Spacer(minLength: 24)
                }
            }
        }
        .navigationTitle("Movie")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if detail != nil && userID > 0 {
                    Button {
                        showAddSheet = true
                    } label: {
                        Image(systemName: "plus.circle")
                    }
                }
            }
        }
        .confirmationDialog(
            "Add to which list?",
            isPresented: $showAddSheet
        ) {
            Button("Watch / Favorite List") {
                addMovie(toAnti: false)
            }
            Button("Ignore List") {
                addMovie(toAnti: true)
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("Add \"\(detail?.title ?? "this movie")\" to a list.")
        }
        .onAppear {
            APIService.shared.fetchMovieDetail(id: movieID) { result in
                DispatchQueue.main.async {
                    self.detail = result
                    self.isLoading = false
                }
            }
        }
    }

    // Add to watch/ignore and skip duplicated movies
    private func addMovie(toAnti: Bool) {
        guard userID > 0 else { return }

        APIService.shared.getWatchList(
            ownerID: userID,
            isGroupList: false,
            isAntiList: toAnti
        ) { existing in
            let already = existing.contains { $0.movieID == movieID }

            if already {
                DispatchQueue.main.async {
                    self.feedbackMessage = toAnti
                        ? "That movie is already in your Ignore List."
                        : "That movie is already in your Watch List."
                    self.feedbackColor = .orange
                }
                return
            }

            APIService.shared.addToWatchList(
                ownerID: userID,
                movieID: movieID,
                isGroupList: false,
                isAntiList: toAnti
            ) { success in
                DispatchQueue.main.async {
                    if success {
                        self.feedbackMessage = toAnti
                            ? "Added to your Ignore List."
                            : "Added to your Watch List."
                        self.feedbackColor = .green
                    } else {
                        self.feedbackMessage = "Could not add movie. Please try again."
                        self.feedbackColor = .red
                    }
                }
            }
        }
    }
}

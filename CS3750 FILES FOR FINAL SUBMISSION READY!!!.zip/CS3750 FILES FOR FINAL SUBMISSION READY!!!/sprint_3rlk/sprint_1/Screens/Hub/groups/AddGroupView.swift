import SwiftUI

struct AddGroupView: View {
    @Environment(\.dismiss) var dismiss
    @State private var groupName = ""
    @State private var isSubmitting = false
    @State private var showError = false
    
    let userID: Int
    let onAdd: () -> Void
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemGroupedBackground)
                    .ignoresSafeArea()
                
                VStack(spacing: 24) {
                    // Header card
                    HStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(Color.white)
                                .frame(width: 46, height: 46)
                                .shadow(color: .black.opacity(0.06), radius: 4, y: 2)
                            
                            Image(systemName: "person.3.fill")
                                .font(.title2)
                                .foregroundColor(Color.blue)
                        }
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Create a New Group")
                                .font(.title3.bold())
                                .foregroundColor(.primary)
                            Text("Give your movie night group a name.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                    }
                    .padding()
                    .background(Color.white.opacity(0.9))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.04), radius: 5, y: 3)
                    .padding(.horizontal)
                    .padding(.top, 8)
                    
                    // Text field card
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Group name")
                            .font(.subheadline.bold())
                            .foregroundColor(.primary)
                        
                        TextField("e.g. Friday Movie Night", text: $groupName)
                            .padding(12)
                            .background(Color.white)
                            .cornerRadius(12)
                            .shadow(color: .black.opacity(0.02), radius: 3, y: 1)
                            .submitLabel(.done)
                    }
                    .padding()
                    .background(Color.white.opacity(0.95))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
                    .padding(.horizontal)
                    
                    // Create button
                    Button(action: addGroup) {
                        HStack {
                            if isSubmitting {
                                ProgressView()
                            } else {
                                Image(systemName: "plus.circle.fill")
                                Text("Create Group")
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(groupName.trimmingCharacters(in: .whitespaces).isEmpty || isSubmitting
                                    ? Color.blue.opacity(0.35)
                                    : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.18), radius: 6, y: 3)
                    }
                    .disabled(groupName.trimmingCharacters(in: .whitespaces).isEmpty || isSubmitting)
                    .padding(.horizontal)
                    
                    Spacer()
                }
            }
            .navigationTitle("New Group")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .alert("Error", isPresented: $showError) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Could not create group. Please try again.")
            }
        }
    }
    
    private func addGroup() {
        isSubmitting = true
        APIService.shared.createGroup(name: groupName, leaderID: userID) { success in
            DispatchQueue.main.async {
                isSubmitting = false
                if success {
                    onAdd()
                    dismiss()
                } else {
                    showError = true
                }
            }
        }
    }
}

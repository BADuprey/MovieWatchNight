import SwiftUI

struct ResetPasswordView: View {
    let username: String

    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var isLoading = false
    @State private var success = false
    @State private var errorMessage: String?

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Reset password for")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Text(username)
                    .font(.headline)

                SecureField("New password", text: $newPassword)
                    .padding(10)
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)

                SecureField("Confirm password", text: $confirmPassword)
                    .padding(10)
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)

                if let error = errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .font(.footnote)
                }

                if success {
                    Text("Password updated")
                        .foregroundColor(.green)
                        .font(.footnote)
                }

                Button(action: submitReset) {
                    HStack {
                        if isLoading {
                            ProgressView().tint(.white)
                        } else {
                            Text("Update Password")
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(canSubmit ? Color.blue : Color.blue.opacity(0.4))
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                }
                .disabled(!canSubmit || isLoading)

                Spacer()
            }
            .padding(.top, 30)
            .background(Color(red: 0.95, green: 0.97, blue: 1.0).ignoresSafeArea())
            .navigationTitle("Reset Password")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") {
                        dismiss()
                    }
                }
            }
        }
    }

    private var canSubmit: Bool {
        !newPassword.isEmpty && newPassword == confirmPassword
    }

    private func submitReset() {
        guard canSubmit else { return }
        isLoading = true
        errorMessage = nil
        success = false

        APIService.shared.resetPassword(username: username, newPassword: newPassword) { ok in
            DispatchQueue.main.async {
                self.isLoading = false
                if ok {
                    self.success = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {  // for auto-close after a sec
                        dismiss()
                    }
                } else {
                    self.errorMessage = "Could not update password."
                }
            }
        }
    }
}

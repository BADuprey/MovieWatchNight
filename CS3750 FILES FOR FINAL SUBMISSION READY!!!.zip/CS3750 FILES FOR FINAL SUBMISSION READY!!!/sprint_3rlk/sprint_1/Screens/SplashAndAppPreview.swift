import SwiftUI

struct SplashFlowPreview: View {
    @State private var showSplash = true

    var body: some View {
        ZStack {
            if showSplash {
                PopcornSplashView {
                    withAnimation(.easeInOut) {
                        showSplash = false
                    }
                }
            } else {
                ContentView()
            }
        }
    }
}

#Preview {
    SplashFlowPreview()
}

// I am so happy :D - Sasha

import SwiftUI

struct ListsView: View {
    var userID: Int
    
    var body: some View {
        Version1(ownerID: userID, isGroupList: false)
    }
}

struct Version1: View {
    var ownerID: Int
    var isGroupList: Bool
    
    @State var currentScreen = 0
    var body: some View {
        if currentScreen == 0 {
            HStack {
                Button(action: setToAntiWatchList) {Text("AntiWatchList")}
                Spacer()
                Button(action: setToWatchList) {Text("WatchList")}
            }
        } else {
            VStack{
                if currentScreen == -1 {
                    WatchListView(ownerID: ownerID, isAnti: true, isGroupList: isGroupList)
                } else {
                    WatchListView(ownerID: ownerID, isAnti: false, isGroupList: isGroupList)
                }
                Button(action: setToHome) {Text("Back")}
            }
        }
    }
    
    private func setToAntiWatchList(){
        currentScreen = -1
    }
    
    private func setToWatchList(){
        currentScreen = 1
    }
    
    private func setToHome(){
        currentScreen = 0
    }
}

struct Version2: View {
    var ownerID: Int
    var isGroupList: Bool
    
    var body: some View {
        HStack {
            WatchListView(ownerID: ownerID, isAnti: true, isGroupList: isGroupList)
            Spacer()
            WatchListView(ownerID: ownerID, isAnti: false, isGroupList: isGroupList)
        }
    }
}


struct WatchListView: View {
    @State private var movies: [MovieSummary] = []
    @State private var showingAlert: Bool = false
    @State private var currentMovie: MovieSummary!
    var ownerID: Int
    var isAnti: Bool
    var isGroupList: Bool
    
    @State private var isLoading = false
    var body: some View {
        List(movies) {movie in
            movieListRow(movieName: movie.title).swipeActions(edge: .trailing) {Button("Remove?", action: {showingAlert = true; currentMovie = movie})}
        }.listStyle(PlainListStyle()).alert(currentMovie == nil ? "Remove?" : "Remove \(currentMovie.title)?", isPresented: $showingAlert) {
            Button("Confirm", role: .destructive) {
                removeMovie() }
            Button("Cancel", role: .cancel) {}
        }.onAppear(perform: getMovieList)
    }
    
    private func removeMovie(){
        isLoading = true
        APIService.shared.removeMovieFromList(ownerID: ownerID, movieID: currentMovie.id, isGroupList: isGroupList, isAntiList: isAnti) { result in
            DispatchQueue.main.async {
                isLoading = false
                getMovieList()
            }
        }
    }
    
    private func getMovieList(){
        isLoading = true
        APIService.shared.getWatchList(ownerID: ownerID, isGroupList: isGroupList, isAntiList: isAnti) { movies in
            DispatchQueue.main.async {
                self.movies = movies
                self.isLoading = false
            }
        }
    }
}


struct movieListRow: View {
    @State var movieName: String
    var body: some View {
        Text(movieName)
    }
}



#Preview {
    ListsView(userID: 0)
}

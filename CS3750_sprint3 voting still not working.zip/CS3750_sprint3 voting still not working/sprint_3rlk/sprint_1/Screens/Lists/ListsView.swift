import SwiftUI


struct ListsView: View {
    var userID: Int
    
    var body: some View {
        Version1(ownerID: userID, isGroupList: false)
    }
}

struct Version1: View {
    var ownerID: Int
    var isGroupList: Bool
    
    @State private var currentScreen = 0   // 0 = choose list, -1 = Ignore, 1 = Watch
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.93, green: 0.97, blue: 1.0),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 18) {
                if currentScreen == 0 {
                    // --------- choose list screen ----------
                    HStack(alignment: .center, spacing: 10) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Your Movie Lists")
                                .font(.title3.bold())
                                .foregroundColor(.primary)
                            Text("Pick a list to manage your movies.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        Image(systemName: "film.stack")
                            .font(.title2)
                            .foregroundColor(Color(red: 0.12, green: 0.45, blue: 0.9))
                            .padding(10)
                            .background(.white)
                            .clipShape(Circle())
                            .shadow(color: .black.opacity(0.06), radius: 4, y: 2)
                    }
                    .padding()
                    .background(Color.white.opacity(0.7))
                    .background(.ultraThinMaterial)
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Personal lists")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        // Ignore / Anti-watch list
                        Button(action: setToAntiWatchList) {
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle()
                                        .fill(Color.white)
                                        .frame(width: 40, height: 40)
                                        .shadow(color: .black.opacity(0.05), radius: 3, y: 2)
                                    
                                    Image(systemName: "hand.thumbsdown.fill")
                                        .foregroundColor(Color(red: 0.9, green: 0.25, blue: 0.25))
                                }
                                
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Ignore List")
                                        .font(.subheadline.bold())
                                        .foregroundColor(.primary)
                                    Text("Movies you want to avoid.")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(16)
                            .shadow(color: .black.opacity(0.03), radius: 4, y: 2)
                        }
                        
                        // Watch / Favorite list
                        Button(action: setToWatchList) {
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle()
                                        .fill(Color.white)
                                        .frame(width: 40, height: 40)
                                        .shadow(color: .black.opacity(0.05), radius: 3, y: 2)
                                    
                                    Image(systemName: "heart.fill")
                                        .foregroundColor(Color(red: 0.12, green: 0.45, blue: 0.9))
                                }
                                
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Watch / Favorite List")
                                        .font(.subheadline.bold())
                                        .foregroundColor(.primary)
                                    Text("Movies you like or plan to watch.")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(16)
                            .shadow(color: .black.opacity(0.03), radius: 4, y: 2)
                        }
                    }
                } else {
                    // --------- List content screen ----------
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(currentScreen == -1 ? "Ignore List" : "Watch / Favorite List")
                                .font(.title3.bold())
                                .foregroundColor(.primary)
                            Text(currentScreen == -1
                                 ? "Movies you’re avoiding."
                                 : "Movies you love or want to watch.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        Button(action: setToHome) {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left")
                                Text("Back")
                            }
                            .font(.subheadline.bold())
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(Color.white.opacity(0.9))
                        .cornerRadius(20)
                        .shadow(color: .black.opacity(0.05), radius: 3, y: 2)
                    }
                    .padding()
                    .background(Color.white.opacity(0.7))
                    .background(.ultraThinMaterial)
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
                    
                    WatchListView(
                        ownerID: ownerID,
                        isAnti: currentScreen == -1,
                        isGroupList: isGroupList
                    )
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                
                Spacer(minLength: 30)
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
        }
    }
    
    private func setToAntiWatchList() {
        currentScreen = -1
    }
    
    private func setToWatchList() {
        currentScreen = 1
    }
    
    private func setToHome() {
        currentScreen = 0
    }
}

struct Version2: View {
    var ownerID: Int
    var isGroupList: Bool
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.93, green: 0.97, blue: 1.0),
                    Color.white
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            HStack(spacing: 12) {
                WatchListCard(
                    title: "Ignore List",
                    subtitle: "Movies you want to avoid.",
                    ownerID: ownerID,
                    isAnti: true,
                    isGroupList: isGroupList
                )
                WatchListCard(
                    title: "Watch List",
                    subtitle: "Movies you like or plan to watch.",
                    ownerID: ownerID,
                    isAnti: false,
                    isGroupList: isGroupList
                )
            }
            .padding()
        }
    }
}

private struct WatchListCard: View {
    let title: String
    let subtitle: String
    let ownerID: Int
    let isAnti: Bool
    let isGroupList: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
            Text(subtitle)
                .font(.caption)
                .foregroundColor(.secondary)
            
            Divider()
            
            WatchListView(ownerID: ownerID, isAnti: isAnti, isGroupList: isGroupList)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.05), radius: 4, y: 3)
    }
}

// WatchListView

struct WatchListView: View {
    @State private var movies: [MovieSummary] = []
    @State private var showingAlert: Bool = false
    @State private var currentMovie: MovieSummary?
    
    // User types a title + add to list
    @State private var newMovieTitle: String = ""
    
    var ownerID: Int
    var isAnti: Bool
    var isGroupList: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Add-movie card
            VStack(alignment: .leading, spacing: 10) {
                Text("Add a movie")
                    .font(.headline)
                
                Text("Type any movie name to add it to this list.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                TextField("Movie title", text: $newMovieTitle)
                    .padding(10)
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(color: .black.opacity(0.01), radius: 2, y: 1)
                
                Button(action: addMovie) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Add to list")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(newMovieTitle.trimmingCharacters(in: .whitespaces).isEmpty
                                ? Color.blue.opacity(0.35)
                                : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                }
                .disabled(newMovieTitle.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(18)
            .shadow(color: .black.opacity(0.02), radius: 5, y: 3)
            
            // Movies section
            VStack(alignment: .leading, spacing: 10) {
                Text("Movies in this list")
                    .font(.headline)
                
                if movies.isEmpty {
                    Text("No movies in this list yet.")
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.02), radius: 4, y: 2)
                } else {
                    ScrollView {
                        VStack(spacing: 10) {
                            ForEach(movies) { movie in
                                movieRowCard(movie)
                            }
                        }
                    }
                }
            }
            
            Spacer()
        }
        .alert(
            currentMovie == nil ? "Remove movie?" : "Remove \(currentMovie!.title)?",
            isPresented: $showingAlert
        ) {
            Button("Remove", role: .destructive) {
                removeMovie()
            }
            Button("Cancel", role: .cancel) { }
        }
        .onAppear(perform: getMovieList)
    }
    
    
    private func movieRowCard(_ movie: MovieSummary) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "popcorn.fill")
                .foregroundColor(Color(red: 0.12, green: 0.45, blue: 0.9))
                .frame(width: 32, height: 32)
                .background(Color.white)
                .cornerRadius(8)
                .shadow(color: .black.opacity(0.04), radius: 2, y: 1)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(movie.title)
                    .font(.subheadline.bold())
                    .foregroundColor(.primary)
                
                if let rating = movie.rating {
                    Text("Rating: \(String(format: "%.1f", rating))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else if let release = movie.release {
                    Text(release)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            Button {
                currentMovie = movie
                showingAlert = true
            } label: {
                Image(systemName: "trash")
                    .foregroundColor(.red)
                    .padding(8)
                    .background(Color.white.opacity(0.9))
                    .clipShape(Circle())
            }
            .buttonStyle(.borderless)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.02), radius: 4, y: 2)
    }
    
  // API CALLS
    private func addMovie() {
        let title = newMovieTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty else { return }
        
        APIService.shared.addFreeTextMovieToList(
            ownerID: ownerID,
            title: title,
            isGroupList: isGroupList,
            isAntiList: isAnti
        ) { ok in
            DispatchQueue.main.async {
                if ok {
                    self.newMovieTitle = ""
                    self.getMovieList()
                }
            }
        }
    }
    
    private func removeMovie() {
        guard let movie = currentMovie else { return }
        
        APIService.shared.removeMovieFromList(
            ownerID: ownerID,
            movieID: movie.id,
            isGroupList: isGroupList,
            isAntiList: isAnti
        ) { _ in
            DispatchQueue.main.async {
                self.currentMovie = nil
                self.getMovieList()
            }
        }
    }
    
    private func getMovieList() {
        APIService.shared.getWatchList(
            ownerID: ownerID,
            isGroupList: isGroupList,
            isAntiList: isAnti
        ) { movies in
            DispatchQueue.main.async {
                self.movies = movies
            }
        }
    }
}

struct movieListRow: View {
    @State var movieName: String
    var body: some View {
        Text(movieName)
    }
}


#Preview {
    ListsView(userID: 0)
}

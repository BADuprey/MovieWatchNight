import SwiftUI

struct GenreMoviesView: View {
    let genre: String
    var preselectedMovieID: Int? = nil

    @State private var movies: [MovieSummary] = []
    @State private var isLoading = true

    @State private var showPreselectedDetail = false
    @State private var resolvedPreselectedID: Int? = nil
    @State private var didAutoNavigate = false

    private let backgroundColor = Color(red: 0.95, green: 0.96, blue: 0.99)

    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()

            List {
                if isLoading {
                    HStack {
                        ProgressView()
                        Text("Loading \(genre) movies...")
                    }
                } else if movies.isEmpty {
                    Text("No movies found.")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(movies) { movie in
                        NavigationLink {
                            MovieDetailView(movieID: movie.movieID)
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(movie.title)
                                    .font(.headline)

                                HStack(spacing: 10) {
                                    if let rating = movie.rating {
                                        Text("⭐️ \(rating, specifier: "%.1f")")
                                            .font(.caption)
                                    }
                                    if let release = movie.release, !release.isEmpty {
                                        Text(release)
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                }
                            }
                            .padding(.vertical, 2)
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .listStyle(.insetGrouped)
        }
        .navigationTitle(genre)
        .navigationDestination(isPresented: $showPreselectedDetail) {
            MovieDetailView(movieID: resolvedPreselectedID ?? 0)
        }
        .onAppear {
            APIService.shared.fetchMovies(genre: genre) { result in
                DispatchQueue.main.async {
                    self.movies = result
                    self.isLoading = false

                    // auto-navigate to preselected movie if present
                    if !didAutoNavigate,
                       let target = preselectedMovieID,
                       result.contains(where: { $0.movieID == target }) {

                        self.resolvedPreselectedID = target
                        self.didAutoNavigate = true

                        DispatchQueue.main.async {
                            self.showPreselectedDetail = true
                        }
                    }
                }
            }
        }
    }
}

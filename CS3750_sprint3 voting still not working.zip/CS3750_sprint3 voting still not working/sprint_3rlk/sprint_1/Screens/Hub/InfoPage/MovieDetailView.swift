import SwiftUI

struct MovieDetailView: View {
    let movieID: Int
    @State private var detail: MovieDetail?
    @State private var isLoading = true

    private var backgroundGradient: LinearGradient {
        LinearGradient(
            colors: [
                Color(red: 0.93, green: 0.96, blue: 1.0),
                Color(red: 0.86, green: 0.91, blue: 0.99)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    var body: some View {
        ZStack {
            backgroundGradient.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {
                    if isLoading {
                        // simple loading state
                        HStack {
                            ProgressView()
                            Text("Loading…")
                        }
                        .padding()
                    } else if let detail = detail {
                        // single white card
                        VStack(alignment: .leading, spacing: 12) {
                            // Title
                            Text(detail.title)
                                .font(.title2.bold())

                            // Rating / release row
                            HStack(spacing: 12) {
                                if let rating = detail.rating {
                                    Text("⭐️ \(rating, specifier: "%.1f")")
                                }
                                if let release = detail.release {
                                    Text(release)
                                }
                            }
                            .font(.subheadline)
                            .foregroundColor(.secondary)

                            Divider()

                            Text("Overview")
                                .font(.headline)

                            if let overview = detail.overview, !overview.isEmpty {
                                Text(overview)
                                    .font(.body)
                            } else {
                                Text("No overview available.")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(16)
                        .background(Color.white)
                        .cornerRadius(16)
                        .shadow(color: Color.black.opacity(0.08), radius: 4, y: 2)
                        .padding(.horizontal, 16)
                        .padding(.top, 12)
                    } else {
                        Text("Movie not found")
                            .foregroundColor(.secondary)
                            .padding()
                    }

                    Spacer(minLength: 24)
                }
            }
        }
        .navigationTitle("Movie")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            APIService.shared.fetchMovieDetail(id: movieID) { result in
                DispatchQueue.main.async {
                    self.detail = result
                    self.isLoading = false
                }
            }
        }
    }
}

import SwiftUI
import UIKit

struct DetailedGroupView: View {
    let group: Group
    let currentUserID: Int
    
    @State private var members: [UserProfile] = []
    @State private var isLoadingMembers = false
    @State private var showingRemoveAlert = false
    @State private var memberPendingRemoval: UserProfile?
    @State private var copyButtonLabel = "Link to Add Members"

    @State private var currentRound: VotingRoundInfo?
    @State private var isLoadingRound = false

    var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    headerCard
                    topMoviesCard
                    actionsCard

                    if isLoadingRound {
                        loadingRoundCard
                    } else if let round = currentRound {
                        dateStatusCard(for: round)
                    }

                    membersCard
                    groupListsCard

                    Spacer(minLength: 24)
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)
            }
        }
        .navigationTitle(group.name)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            loadMembers()
            loadRound()
        }
        .alert(
            alertTitle,
            isPresented: $showingRemoveAlert
        ) {
            Button("Remove", role: .destructive) {
                if let member = memberPendingRemoval {
                    removeMember(member: member)
                }
            }
            Button("Cancel", role: .cancel) {
                memberPendingRemoval = nil
            }
        } message: {
            if let member = memberPendingRemoval {
                Text("This will remove \(member.username) from the group.")
            }
        }
    }


    //The cards
    private var headerCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(group.name)
                .font(.title2.bold())
                .foregroundColor(.primary)

            Text("Group ID: \(group.groupID)")
                .font(.footnote)
                .foregroundColor(.secondary)

            Text("Plan movie nights, vote on movies and dates, and manage group lists.")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.04), radius: 5, y: 3)
    }

    private var topMoviesCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Top Movies")
                .font(.headline)
                .foregroundColor(.secondary)

            VStack {
                PodiumView(groupID: group.groupID)
                    .padding(.vertical, 8)
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 4)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
    }

    private var actionsCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Group Actions")
                .font(.headline)
                .foregroundColor(.secondary)

            VStack(spacing: 0) {
                NavigationLink(
                    destination: SchedulesView(
                        ownerID: group.groupID,
                        mode: .group(name: group.name)
                    )
                ) {
                    actionRow(title: "Group Schedule", systemImage: "calendar")
                }

                Divider()

                NavigationLink(destination: SuggestMovieView(group: group, currentUserID: currentUserID)) {
                    actionRow(title: "Suggest a Movie", systemImage: "plus.square.on.square")
                }

                Divider()

                NavigationLink(destination: VoteView(group: group, currentUserID: currentUserID)) {
                    actionRow(title: "Vote on Movies", systemImage: "hand.thumbsup")
                }
                
                // NEW:
                if let round = currentRound, !round.isComplete {
                    Divider()
                    
                    NavigationLink(
                        destination: DateVoteView(
                            group: group,
                            round: round,
                            currentUserID: currentUserID
                        )
                    ){
                        actionRow(title: "Vote on Date", systemImage: "calendar.badge.clock")
                    }
                }
            }
            .background(Color.white)
            .cornerRadius(14)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
    }

    private func actionRow(title: String, systemImage: String) -> some View {
        HStack {
            Image(systemName: systemImage)
                .foregroundColor(.blue)
            Text(title)
                .foregroundColor(.primary)
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundColor(.secondary)
                .font(.footnote)
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
    }

    private var loadingRoundCard: some View {
        VStack {
            HStack {
                Spacer()
                ProgressView("Checking round status…")
                Spacer()
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
    }

    private func dateStatusCard(for round: VotingRoundInfo) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            if let winningDate = round.winningDate, round.isComplete {
                Text("Movie Night Scheduled")
                    .font(.headline)

                Text("\(round.movieTitle) on \(winningDate)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            } else {
                Text("Next Step")
                    .font(.headline)

                Text("Pick a date for \(round.movieTitle)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                NavigationLink(
                    destination: DateVoteView(
                        group: group,
                        round: round,
                        currentUserID: currentUserID
                    )
                ) {
                    HStack {
                        Image(systemName: "calendar.badge.plus")
                        Text("Vote on Date")
                            .fontWeight(.semibold)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.secondary)
                            .font(.footnote)
                    }
                    .padding()
                    .background(Color.purple.opacity(0.12))
                    .foregroundColor(.purple)
                    .cornerRadius(12)
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
    }

    private var membersCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Members")
                .font(.headline)
                .foregroundColor(.secondary)
            
            Button(action: copyLinkToClipboard) {
                        Text(copyButtonLabel)
                            .font(.subheadline.bold())
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                    }
                    .buttonStyle(.borderedProminent)
            
            if isLoadingMembers {
                HStack {
                    Spacer()
                    ProgressView()
                    Spacer()
                }
                .padding(.vertical, 8)
            } else if members.isEmpty {
                Text("No members yet.")
                    .foregroundColor(.secondary)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(14)
                    .shadow(color: .black.opacity(0.02), radius: 4, y: 2)
            } else {
                VStack(spacing: 8) {
                    ForEach(members) { member in
                        HStack {
                            Text(member.username)
                                .foregroundColor(.primary)
                            Spacer()
                            Button {
                                memberPendingRemoval = member
                                showingRemoveAlert = true
                            } label: {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                                    .padding(8)
                                    .background(Color.white.opacity(0.9))
                                    .clipShape(Circle())
                            }
                            .buttonStyle(.borderless)
                        }
                        .padding(10)
                        .background(Color.white)
                        .cornerRadius(12)
                        .shadow(color: .black.opacity(0.02), radius: 3, y: 2)
                    }
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
    }

    private var groupListsCard: some View {
        NavigationLink(destination: GroupListsView(group: group)) {
            HStack(alignment: .center, spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color.white)
                        .frame(width: 42, height: 42)
                        .shadow(color: .black.opacity(0.05), radius: 3, y: 2)

                    Image(systemName: "list.and.film")
                        .font(.title3)
                        .foregroundColor(Color.blue)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text("Group Movie Lists")
                        .font(.headline)
                        .foregroundColor(.primary)
                    Text("Manage this group’s ignore and watch lists.")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }

                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
                    .font(.footnote)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(18)
            .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
        }
        .buttonStyle(.plain)
    }

    //Helper functions
    private var alertTitle: String {
        if let member = memberPendingRemoval {
            return "Remove \(member.username)?"
        } else {
            return "Remove member?"
        }
    }

    private func removeMember(member: UserProfile) {
        isLoadingMembers = true
        APIService.shared.removeMemberFromGroup(
            groupID: group.groupID,
            userID: member.userID
        ) { _ in
            DispatchQueue.main.async {
                isLoadingMembers = false
                loadMembers()
            }
        }
    }

    private func loadMembers() {
        isLoadingMembers = true
        APIService.shared.fetchGroupMembers(groupID: group.groupID) { members in
            DispatchQueue.main.async {
                self.members = members
                self.isLoadingMembers = false
            }
        }
    }

    private func loadRound() {
        isLoadingRound = true
        APIService.shared.fetchCurrentRound(groupID: group.groupID) { round in
            DispatchQueue.main.async {
                self.currentRound = round
                self.isLoadingRound = false
            }
        }
    }
    
    private func copyLinkToClipboard(){
      UIPasteboard.general.string = ServerConfig.shared.baseURLString + "/joinGroup/" + String(group.groupID)
      copyButtonLabel = "Link Copied!"
    }
}


#Preview {
    DetailedGroupView(
        group: Group(groupID: 1, name: "Example Group", leaderID: 1),
        currentUserID: 1
    )
}

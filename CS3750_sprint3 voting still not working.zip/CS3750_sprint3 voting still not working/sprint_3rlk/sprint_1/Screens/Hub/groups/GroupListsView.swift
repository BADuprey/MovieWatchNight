import SwiftUI

struct GroupListsView: View {
    let group: Group

    var body: some View {
        Version1(ownerID: group.groupID, isGroupList: true)
            .navigationTitle("\(group.name) Lists")
            .navigationBarTitleDisplayMode(.inline)
    }
}

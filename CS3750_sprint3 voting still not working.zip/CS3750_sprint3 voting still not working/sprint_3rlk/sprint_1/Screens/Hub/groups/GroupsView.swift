import SwiftUI

struct GroupsView: View {
    @State private var groups: [Group] = []
    @State private var isLoading = false
    @State private var showAddGroup = false
    @State private var errorMessage: String?

    let userID: Int
    let username: String

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                VStack {
                    if isLoading {
                        ProgressView("Loading groups...")
                            .padding()
                    } else if groups.isEmpty {
                        // Empty state
                        VStack(spacing: 10) {
                            Spacer()

                            Text("You’re not in any groups yet.")
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)

                            Text("Join a group!")
                                .font(.headline)
                                .foregroundColor(.gray)

                            Button(action: { showAddGroup = true }) {
                                Text("Create Group")
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.blue.opacity(0.2))
                                    .cornerRadius(10)
                            }
                            .padding(.horizontal)

                            Spacer()
                        }
                    } else {
                        // Group list
                        ScrollView {
                            VStack(spacing: 16) {
                                ForEach(groups) { group in
                                    GroupRow(group: group, currentUserID: userID)
                                }
                            }
                            .padding(.horizontal)
                            .padding(.top, 8)
                        }
                    }
                }
                .padding(.top)
                .background(Color(.systemGray6))
                .navigationTitle("My Groups")
                .onAppear(perform: loadGroups)

                // Floating add button
                Button(action: { showAddGroup = true }) {
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 50, height: 40)
                        .background(Color.blue)
                        .clipShape(Circle())
                        .shadow(radius: 4, y: 2)
                }
                .padding()
            }
            // Sheet for creating / joining a group
            .sheet(isPresented: $showAddGroup, onDismiss: loadGroups) {
                AddGroupView(userID: userID, onAdd: loadGroups)
            }
        }
    }

    // Fetch groups from database
    private func loadGroups() {
        isLoading = true
        errorMessage = nil

        APIService.shared.fetchGroups(userID: userID) { groups in
            DispatchQueue.main.async {
                self.groups = groups
                self.isLoading = false
            }
        }
    }
}

struct GroupRow: View {
    let group: Group
    let currentUserID: Int

    var body: some View {
        NavigationLink(
            destination: DetailedGroupView(
                group: group,
                currentUserID: currentUserID
            )
        ) {
            HStack {
                Text(group.name)
                    .font(.headline)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.white)
            .cornerRadius(12)
            .shadow(radius: 1, y: 1)
        }
    }
}

#Preview {
    GroupsView(userID: 1, username: "ExampleUser")
}

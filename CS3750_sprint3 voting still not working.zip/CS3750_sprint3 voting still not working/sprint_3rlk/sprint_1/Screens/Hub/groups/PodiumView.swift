import SwiftUI

struct PodiumView: View {
    let groupID: Int

    @State private var suggestions: [MovieSuggestion] = []
    @State private var isLoading = false

    var body: some View {
        VStack(spacing: 20) {
            if isLoading {
                ProgressView("Loading podium…")
            } else if suggestions.isEmpty {
                Text("No votes yet.")
                    .foregroundColor(.gray)
            } else {
                podiumLayout
            }
        }
        .onAppear(perform: loadSuggestions)
    }

    private var podiumLayout: some View {
        let top3 = Array(suggestions.prefix(3))

        return HStack(alignment: .bottom, spacing: 16) {

            if top3.count > 1 {
                podiumColumn(
                    place: "2nd",
                    suggestion: top3[1],
                    color: Color.gray.opacity(0.3),
                    height: 120
                )
            }

            podiumColumn(
                place: "1st",
                suggestion: top3[0],
                color: Color.yellow.opacity(0.5),
                height: 180
            )

            if top3.count > 2 {
                podiumColumn(
                    place: "3rd",
                    suggestion: top3[2],
                    color: Color.orange.opacity(0.3),
                    height: 90
                )
            }
        }
        .padding(.top, 10)
    }

    private func podiumColumn(place: String, suggestion: MovieSuggestion, color: Color, height: CGFloat) -> some View {
        VStack(spacing: 6) {
            Text(place)
                .font(.caption)
                .foregroundColor(.secondary)

            VStack(spacing: 4) {
                Text(suggestion.movieTitle)
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)

                Text("\(suggestion.voteCount) votes")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .frame(height: height)
            .frame(maxWidth: .infinity)
            .background(color)
            .cornerRadius(10)
        }
        .frame(maxWidth: .infinity)
    }

    private func loadSuggestions() {
        isLoading = true
        APIService.shared.fetchSuggestions(groupID: groupID) { items in
            DispatchQueue.main.async {
                self.suggestions = items.sorted { $0.voteCount > $1.voteCount }
                self.isLoading = false
            }
        }
    }
}


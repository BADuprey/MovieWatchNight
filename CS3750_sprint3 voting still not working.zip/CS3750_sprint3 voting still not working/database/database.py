import sqlite3
import json
import csv
import re

ENCODING = "utf8"
DATABASE_NAME = "movieWatchNight.db"
MOVIES_FILENAME = "movies_metadata.json"
CLEANED_MOVIES = "cleanedMovies.json"

# OPENING AND CLOSING CONNECTIONS ===================================
def openConnection():
    connection = sqlite3.connect(DATABASE_NAME)
    cursor = connection.cursor()
    return connection, cursor

def closeConnection(cursor, connection):
    if cursor is not None:
        cursor.close()
    if connection is not None:
        connection.close()

def createTables():
    conn, c = openConnection()
    commands = []

    # USERS
    commandString = """CREATE TABLE users (
        userID INTEGER PRIMARY KEY AUTOINCREMENT,
        username text UNIQUE,
        passHash text,
        emailAddress text
    );
    """
    commands.append(commandString)

    # MOVIES
    commandString = """CREATE TABLE movies (
        movieID int PRIMARY KEY,
        title text,
        overview text,
        rating float,
        release date
    );
    """
    commands.append(commandString)

    # USER WATCHLIST
    commandString = """CREATE TABLE userWatchList (
        userID int,
        movieID int,
        FOREIGN KEY (userID) REFERENCES users(userID),
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # USER ANTI-WATCHLIST 
    commandString = """CREATE TABLE userAntiWatchList (
        userID int,
        movieID int,
        FOREIGN KEY (userID) REFERENCES users(userID),
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # GROUPS
    commandString = """CREATE TABLE groups (
        groupID INTEGER PRIMARY KEY AUTOINCREMENT,
        groupName text,
        leaderID int,
        FOREIGN KEY (leaderID) REFERENCES users(userID)
    );
    """
    commands.append(commandString)

    # GROUP MEMBER RELATION
    commandString = """CREATE TABLE groupMemberRelation (
        groupID int,
        userID int,
        vote int,
        FOREIGN KEY (groupID) REFERENCES groups(groupID),
        FOREIGN KEY (userID) REFERENCES users(userID),
        FOREIGN KEY (vote) REFERENCES movies(movieID),
        PRIMARY KEY (groupID, userID)
    );
    """
    commands.append(commandString)

    # GROUP WATCHLIST
    commandString = """CREATE TABLE groupWatchList (
        groupID int,
        movieID int,
        FOREIGN KEY (groupID) REFERENCES groups(groupID),
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # GROUP ANTI-WATCHLIST 
    commandString = """CREATE TABLE groupAntiWatchList (
        groupID int,
        movieID int,
        FOREIGN KEY (groupID) REFERENCES groups(groupID),
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)
   
    # GROUP MOVIE SUGGESTIONS
    commandString = """CREATE TABLE groupMovieSuggestions (
        suggestionID INTEGER PRIMARY KEY AUTOINCREMENT,
        movieRoundID int,
        groupID int,
        userID int,
        movieTitle text,
        createdAt text,
        FOREIGN KEY (movieRoundID) REFERENCES movieRounds(movieRoundID),
        FOREIGN KEY (groupID) REFERENCES groups(groupID),
        FOREIGN KEY (userID) REFERENCES users(userID)
    );
    """
    commands.append(commandString)
    # GROUP MOVIE VOTES
    commandString = """CREATE TABLE groupMovieVotes (
        voteID INTEGER PRIMARY KEY AUTOINCREMENT,
        movieRoundID int,
        suggestionID int,
        userID int,
        FOREIGN KEY(movieRoundID) REFERENCES movieRounds(movieRoundID),
        FOREIGN KEY(suggestionID) REFERENCES groupMovieSuggestions(suggestionID),
        FOREIGN KEY(userID) REFERENCES users(userID)
    );
    """
    commands.append(commandString)

    # VOTING ROUNDS (for date voting after movie winner is chosen)
    commandString = """CREATE TABLE votingRounds (
        roundID INTEGER PRIMARY KEY AUTOINCREMENT,
        groupID int,
        winningSuggestionID int,
        winningDate text,
        isComplete int DEFAULT 0,
        FOREIGN KEY (groupID) REFERENCES groups(groupID),
        FOREIGN KEY (winningSuggestionID) REFERENCES groupMovieSuggestions(suggestionID)
    );
    """
    commands.append(commandString)

    # DATE VOTES (each user picks a date in the round)
    commandString = """CREATE TABLE dateVotes (
        voteID INTEGER PRIMARY KEY AUTOINCREMENT,
        roundID int,
        userID int,
        dateChoice text,
        FOREIGN KEY (roundID) REFERENCES votingRounds(roundID),
        FOREIGN KEY (userID) REFERENCES users(userID)
    );
    """
    commands.append(commandString)

    # MOVIE ROUNDS
    commandString = """CREATE TABLE movieRounds (
    movieRoundID INTEGER PRIMARY KEY AUTOINCREMENT,
    groupID int,
    isComplete int DEFAULT 0,
    FOREIGN KEY (groupID) REFERENCES groups(groupID)
    );
    """
    commands.append(commandString)


    # GENRE ↔ MOVIE
    commandString = """CREATE TABLE genreMovieRelation (
        movieID int,
        genre text,
        FOREIGN KEY (movieID) REFERENCES movies(movieID)
    );
    """
    commands.append(commandString)

    # EVENTS
    commandString = """CREATE TABLE events (
        eventID INTEGER PRIMARY KEY AUTOINCREMENT,
        title text,
        date date
    );
    """
    commands.append(commandString)

    # GROUP ↔ EVENT
    commandString = """CREATE TABLE groupEventRelation (
        groupID int,
        eventID int,
        FOREIGN KEY (eventID) REFERENCES events(eventID),
        FOREIGN KEY (groupID) REFERENCES groups(groupID)
    );
    """
    commands.append(commandString)

    # USER ↔ EVENT
    commandString = """CREATE TABLE userEventRelation (
        userID int,
        eventID int,
        FOREIGN KEY (userID) REFERENCES users(userID),
        FOREIGN KEY (eventID) REFERENCES events(eventID)
    );
    """
    commands.append(commandString)

    for command in commands:
        c.execute(command)

    conn.commit()
    closeConnection(c, conn)

# USER SECTION =================================================
def loginUser(username: str, passwordHash: str) -> bool:
    conn, c = openConnection()

    commandString = f"SELECT COUNT(*) FROM users \
                      WHERE username = '{username}' AND passHash = '{passwordHash}'"
    c.execute(commandString)
    result = c.fetchone()
    closeConnection(c, conn)
    if result[0] == 1:
        return True
    else:
        return False

def createUser(username: str, passwordHash: str, emailAddress: str) -> bool:
    conn, c = openConnection()
    try:
        commandString = f"INSERT INTO users (username, passHash, emailAddress) \
                        VALUES ('{username}', '{passwordHash}', '{emailAddress}');"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    return True
    
def deleteUser(userID: int) -> bool:
    conn, c = openConnection()

    try:
        commandString = f"DELETE FROM groupMemberRelation \
                          WHERE userID = {userID}"
        c.execute(commandString)

        commandString = f"DELETE FROM groups \
                          WHERE leaderID = {userID}"
        c.execute(commandString)

        commandString = f"DELETE FROM users \
                          WHERE userID = {userID}"
        c.execute(commandString)

        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    
def getUserByUsername(username: str):
    conn, c = openConnection()
    c.execute(
        "SELECT userID, username, emailAddress FROM users WHERE username = ?;",
        (username,)
    )
    row = c.fetchone()
    closeConnection(c, conn)
    return row 

def updateUserPassword(username: str, new_pass_hash: str) -> bool:
    conn, c = openConnection()
    c.execute(
        "UPDATE users SET passHash = ? WHERE username = ?;",
        (new_pass_hash, username)
    )
    conn.commit()
    changed = c.rowcount 
    closeConnection(c, conn)
    return changed == 1

# GROUPS SECTION =======================================
def getGroups(userID: int) -> list:
    conn, c = openConnection()
    c.execute("""
        SELECT g.groupID, g.groupName, g.leaderID
        FROM groups g
        JOIN groupMemberRelation r ON g.groupID = r.groupID
        WHERE r.userID = ?
        ORDER BY g.groupID ASC;
    """, (userID,))
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

# NEW -- makesure group memebers still fetch properly
def getGroupMembers(groupID: int) -> list:
    conn, c = openConnection()
    c.execute("""
        SELECT userID
        FROM groupMemberRelation
        WHERE groupID = ?;
    """, (groupID,))
    rows = c.fetchall()
    closeConnection(c, conn)
    return [r[0] for r in rows]


def createGroup(name: str, leaderID: int) -> bool:
    conn, c = openConnection()
    try:
        # create the group
        c.execute(
            "INSERT INTO groups (groupName, leaderID) VALUES (?, ?);",
            (name, leaderID)
        )
        group_id = c.lastrowid

        # automatically add the leader as a member
        c.execute(
            "INSERT INTO groupMemberRelation (groupID, userID) VALUES (?, ?);",
            (group_id, leaderID)
        )

        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

def addMember2Group(groupID: int, userID: int) -> bool:
    conn, c = openConnection()
    try:
        commandString = f"INSERT INTO groupMemberRelation (groupID, userID) \
                        VALUES ({groupID}, {userID});"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

def deleteGroup(groupID: int) -> bool:
    conn, c = openConnection()
    try:
        commandString = f"DELETE FROM groupMemberRelation \
                        WHERE groupID = {groupID};"
        c.execute(commandString)
        
        commandString = f"DELETE FROM groups \
                        WHERE groupID = {groupID};"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    
def getEventsForGroup(group_id: int) -> list:
    """
    Return all events linked to a specific group via groupEventRelation.
    Rows: (eventID, title, date)
    """
    conn, c = openConnection()
    c.execute("""
        SELECT e.eventID, e.title, e.date
        FROM events e
        JOIN groupEventRelation ger ON e.eventID = ger.eventID
        WHERE ger.groupID = ?
        ORDER BY e.date ASC;
    """, (group_id,))
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

def addEventForGroup(group_id: int, title: str, date_str: str) -> bool:
    """
    Create an event and link it to a group in groupEventRelation.
    """
    conn, c = openConnection()
    try:
        # Insert event
        c.execute(
            "INSERT INTO events (title, date) VALUES (?, ?);",
            (title, date_str)
        )
        event_id = c.lastrowid

        # Link event to group
        c.execute(
            "INSERT INTO groupEventRelation (groupID, eventID) VALUES (?, ?);",
            (group_id, event_id)
        )

        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

# Changes made 
def _userHasVotedInRound(c, movieRoundID, userID):
    c.execute("""
        SELECT COUNT(*)
        FROM groupMovieVotes
        WHERE movieRoundID = ? AND userID = ?;
    """, (movieRoundID, userID))
    return c.fetchone()[0] > 0

def suggestMovie(groupID: int, userID: int, movieTitle: str) -> bool:
    conn, c = openConnection()
    try:
        movieRoundID = getActiveMovieRound(groupID)

        # Has this user voted already?
        c.execute("""
            SELECT COUNT(*)
            FROM groupMovieVotes
            WHERE movieRoundID = ? AND userID = ?;
        """, (movieRoundID, userID))

        if c.fetchone()[0] > 0:
            closeConnection(c, conn)
            return False

        # Create suggestion
        c.execute("""
            INSERT INTO groupMovieSuggestions
            (movieRoundID, groupID, userID, movieTitle, createdAt)
            VALUES (?, ?, ?, ?, datetime('now'));
        """, (movieRoundID, groupID, userID, movieTitle))

        suggestionID = c.lastrowid

        # Vote for your own suggestion
        c.execute("""
            INSERT INTO groupMovieVotes (movieRoundID, suggestionID, userID)
            VALUES (?, ?, ?);
        """, (movieRoundID, suggestionID, userID))

        conn.commit()
        closeConnection(c, conn)
        return True

    except Exception as e:
        print("suggestMovie ERROR:", e)
        closeConnection(c, conn)
        return False


def voteForSuggestion(suggestionID: int, userID: int) -> bool:
    conn, c = openConnection()
    try:
        # Find round + group
        c.execute("""
            SELECT movieRoundID, groupID
            FROM groupMovieSuggestions
            WHERE suggestionID = ?;
        """, (suggestionID,))
        row = c.fetchone()
        if row is None:
            closeConnection(c, conn)
            return False

        movieRoundID, groupID = row

        # Already voted?
        c.execute("""
            SELECT COUNT(*)
            FROM groupMovieVotes
            WHERE movieRoundID = ? AND userID = ?;
        """, (movieRoundID, userID))

        if c.fetchone()[0] > 0:
            closeConnection(c, conn)
            return False

        # Insert vote
        c.execute("""
            INSERT INTO groupMovieVotes (movieRoundID, suggestionID, userID)
            VALUES (?, ?, ?);
        """, (movieRoundID, suggestionID, userID))

        # Count voters
        voters = countMovieVoters(movieRoundID)
        members = countGroupMembers(groupID)

        if voters == members:
            _closeMovieRound(c, movieRoundID, groupID)

        conn.commit()
        closeConnection(c, conn)
        return True

    except Exception as e:
        print("voteForSuggestion ERROR:", e)
        closeConnection(c, conn)
        return False

# Changes made --> function added 
def _closeMovieRound(cursor, movieRoundID: int, groupID: int):
    """
    Closes the active movie round:
    - determines winning movie suggestion
    - marks movie round complete
    - creates a NEW date voting round
    """

    # 1. Determine winner of movie round
    cursor.execute("""
        SELECT s.suggestionID, s.movieTitle, COUNT(v.voteID) as votes
        FROM groupMovieSuggestions s
        LEFT JOIN groupMovieVotes v ON s.suggestionID = v.suggestionID
        WHERE s.movieRoundID = ?
        GROUP BY s.suggestionID, s.movieTitle
        ORDER BY votes DESC, s.suggestionID ASC
        LIMIT 1;
    """, (groupID, movieRoundID))
    winner = cursor.fetchone()

    if winner is None:
        return

    winningSuggestionID = winner[0]

    # Mark movie round complete
    cursor.execute("""
        UPDATE movieRounds
        SET isComplete = 1
        WHERE movieRoundID = ?;
    """, (movieRoundID,))

    # Create date-voting round
    cursor.execute("""
        INSERT INTO votingRounds (groupID, winningSuggestionID, winningDate, isComplete)
        VALUES (?, ?, NULL, 0);
    """, (groupID, winningSuggestionID))

def countGroupMembers(groupID: int) -> int:
    conn, c = openConnection()
    c.execute("SELECT COUNT(*) FROM groupMemberRelation WHERE groupID = ?;", (groupID,))
    num = c.fetchone()[0]
    closeConnection(c, conn)
    return num

# Changes made 
def countMovieVoters(movieRoundID: int) -> int:
    conn, c = openConnection()
    c.execute("""
        SELECT COUNT(DISTINCT userID)
        FROM groupMovieVotes
        WHERE movieRoundID = ?;
    """, (movieRoundID,))
    num = c.fetchone()[0]
    closeConnection(c, conn)
    return num

def getCurrentRoundForGroup(groupID: int):
    """
    Returns the most recent voting round for this group, with movie title.
    Row: (roundID, groupID, winningSuggestionID, movieTitle, winningDate, isComplete)
    or None if no round yet.
    """
    conn, c = openConnection()
    c.execute("""
        SELECT
            r.roundID,
            r.groupID,
            r.winningSuggestionID,
            s.movieTitle,
            r.winningDate,
            r.isComplete
        FROM votingRounds r
        JOIN groupMovieSuggestions s ON r.winningSuggestionID = s.suggestionID
        WHERE r.groupID = ?
        ORDER BY r.roundID DESC
        LIMIT 1;
    """, (groupID,))
    row = c.fetchone()
    closeConnection(c, conn)
    return row

def countDateVoters(roundID: int) -> int:
    conn, c = openConnection()
    c.execute("""
        SELECT COUNT(DISTINCT userID)
        FROM dateVotes
        WHERE roundID = ?;
    """, (roundID,))
    num = c.fetchone()[0]
    closeConnection(c, conn)
    return num

# Changes made
def voteForDate(roundID: int, userID: int, dateChoice: str) -> bool:
    conn, c = openConnection()
    try:
        # Already voted?
        c.execute("""
            SELECT COUNT(*)
            FROM dateVotes
            WHERE roundID = ? AND userID = ?;
        """, (roundID, userID))

        if c.fetchone()[0] > 0:
            closeConnection(c, conn)
            return False

        # Submit vote
        c.execute("""
            INSERT INTO dateVotes (roundID, userID, dateChoice)
            VALUES (?, ?, ?);
        """, (roundID, userID, dateChoice))

        # Determine group
        c.execute("SELECT groupID FROM votingRounds WHERE roundID = ?;", (roundID,))
        groupID = c.fetchone()[0]

        voters = countDateVoters(roundID)
        members = countGroupMembers(groupID)

        if voters == members:
            _closeDateRound(c, roundID, groupID)

        conn.commit()
        closeConnection(c, conn)
        return True

    except Exception as e:
        print("voteForDate ERROR:", e)
        closeConnection(c, conn)
        return False

# Changes made
def _closeDateRound(cursor, roundID: int, groupID: int):
    # Determine winning date
    cursor.execute("""
        SELECT dateChoice, COUNT(*) AS votes
        FROM dateVotes
        WHERE roundID = ?
        GROUP BY dateChoice
        ORDER BY votes DESC, dateChoice ASC
        LIMIT 1;
    """, (roundID,))
    row = cursor.fetchone()

    if row is None:
        return

    winningDate = row[0]

    # Get movie title from winningSuggestionID
    cursor.execute("""
        SELECT s.movieTitle
        FROM votingRounds r
        JOIN groupMovieSuggestions s ON r.winningSuggestionID = s.suggestionID
        WHERE r.roundID = ?;
    """, (roundID,))
    movieTitle = cursor.fetchone()[0]

    # Create event
    cursor.execute("""
        INSERT INTO events (title, date)
        VALUES (?, ?);
    """, (movieTitle, winningDate))
    eventID = cursor.lastrowid

    # Link event to group
    cursor.execute("""
        INSERT INTO groupEventRelation (groupID, eventID)
        VALUES (?, ?);
    """, (groupID, eventID))

    # Mark round complete
    cursor.execute("""
        UPDATE votingRounds
        SET winningDate = ?, isComplete = 1
        WHERE roundID = ?;
    """, (winningDate, roundID))

    # Start next movie round
    cursor.execute("""
        INSERT INTO movieRounds (groupID, isComplete)
        VALUES (?, 0);
    """, (groupID,))

# Changes made
def getActiveMovieRound(groupID: int):
    conn, c = openConnection()
    c.execute("""
        SELECT movieRoundID
        FROM movieRounds
        WHERE groupID = ? AND isComplete = 0
        ORDER BY movieRoundID DESC LIMIT 1;
    """, (groupID,))
    row = c.fetchone()

    if row:
        closeConnection(c, conn)
        return row[0]

    # create new movie round
    c.execute("INSERT INTO movieRounds (groupID, isComplete) VALUES (?, 0);", (groupID,))
    newID = c.lastrowid
    conn.commit()
    closeConnection(c, conn)
    return newID

# MOVIES SECTION ===================================================
# util for converting csv files to json files
def csv2Json(inputFile, outputFile):
    with open(inputFile, "r", encoding=ENCODING) as inFile:
        with open(outputFile, "w", encoding=ENCODING) as outFile:
            reader = csv.DictReader(inFile)
            data = list(reader)
            json.dump(data, outFile, indent = 4)

def cleanMovieFile():
    with open(MOVIES_FILENAME, "r", encoding=ENCODING) as file:
        content = json.load(file)
    
    foundIDs = []
    output = []

    for movie in content:
        try:
            id = int(movie["id"])
            if id not in foundIDs and movie["title"] != None:
                movie["title"] = movie["title"].replace("\"", "'")
                
                foundIDs.append(id)
                output.append(movie)
        except ValueError:
            continue
    
    with open(CLEANED_MOVIES, "w", encoding=ENCODING) as file:
        json.dump(output, file, indent = 4)

def addMovies():
    with open(CLEANED_MOVIES, "r", encoding=ENCODING) as file:
        content = json.load(file)
    
    conn, c = openConnection()
    for movie in content:
        id = int(movie["id"])
        title = movie["title"]
        rating = float(movie["vote_average"])
        release = movie["release_date"]
        overview = movie["overview"].replace("\"", "'")
        print(overview)
        commandString = f'INSERT INTO movies (movieID, title, overview, rating, release) \
                          VALUES ({id}, "{title}", "{overview}", {rating}, "{release}");'
        c.execute(commandString)
    
    conn.commit()
    
def addGenres():
    genreMatch = r"'name': '(.+?)'}"
    conn, c = openConnection()
    with open(CLEANED_MOVIES, "r", encoding=ENCODING) as file:
        content = json.load(file)
    for movie in content:
        genres = movie["genres"]
        movieID = int(movie["id"])
        hits = re.findall(genreMatch, genres)
        for hit in hits:
            commandString = f"INSERT INTO genreMovieRelation (movieID, genre) VALUES \
                             ({movieID}, '{hit}');"
            c.execute(commandString)
    conn.commit()
    closeConnection(c, conn)

# EVENTS SECTION =====================================================  
def getEvents() -> list:
    conn, c = openConnection()
    c.execute("SELECT eventID, title, date FROM events ORDER BY date ASC;")
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

def addEvent(title: str, date_str: str) -> bool:
    conn, c = openConnection()
    try:
        c.execute(
            "INSERT INTO events (title, date) VALUES (?, ?);",
            (title, date_str)
        )
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

def deleteEvent(event_id: int) -> bool:
    conn, c = openConnection()
    try:
        c.execute("DELETE FROM events WHERE eventID = ?;", (event_id,))
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    
def updateEvent(event_id: int, title: str, date_str: str) -> bool:
    conn, c = openConnection()
    try:
        c.execute(
            "UPDATE events SET title = ?, date = ? WHERE eventID = ?;",
            (title, date_str, event_id)
        )
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    
def getEventsForUser(user_id: int) -> list:
    conn, c = openConnection()
    c.execute("""
        SELECT eventID, title, date, groupName FROM (
            -- personal events
            SELECT
                e.eventID AS eventID,
                e.title   AS title,
                e.date    AS date,
                NULL      AS groupName
            FROM events e
            JOIN userEventRelation uer ON e.eventID = uer.eventID
            WHERE uer.userID = ?

            UNION

            -- group events for groups this user belongs to
            SELECT
                e.eventID,
                e.title,
                e.date,
                g.groupName AS groupName
            FROM events e
            JOIN groupEventRelation ger ON e.eventID = ger.eventID
            JOIN groupMemberRelation gmr ON ger.groupID = gmr.groupID
            JOIN groups g              ON g.groupID   = ger.groupID
            WHERE gmr.userID = ?
        )
        ORDER BY date ASC;
    """, (user_id, user_id))
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

def addEventForUser(user_id: int, title: str, date_str: str) -> bool:
    conn, c = openConnection()
    try:
        # insert event
        c.execute(
            "INSERT INTO events (title, date) VALUES (?, ?);",
            (title, date_str)
        )
        event_id = c.lastrowid
        # link event to user
        c.execute(
            "INSERT INTO userEventRelation (userID, eventID) VALUES (?, ?);",
            (user_id, event_id)
        )
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False
    
# RECOMMENDATIONS SECTION =============================================
def getRandomMovies(limit: int = 20) -> list:
    conn, c = openConnection()
    c.execute("""
        SELECT movieID, title, rating, release
        FROM movies
        ORDER BY RANDOM()
        LIMIT ?;
    """, (limit,))
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

def getRecommendedMovies(user_id: int, limit: int = 20) -> list:
    """
    - look at movies in the user's watch list
    - grab other movies that share those genres
    - exclude movies already in the user's watch list and anti-watch list
    - order by rating
    """
    conn, c = openConnection()
    c.execute("""
        SELECT DISTINCT m.movieID, m.title, m.rating, m.release
        FROM userWatchList uw
        JOIN genreMovieRelation g1 ON uw.movieID = g1.movieID
        JOIN genreMovieRelation g2 ON g1.genre = g2.genre
        JOIN movies m ON g2.movieID = m.movieID
        WHERE uw.userID = ?
          AND m.movieID NOT IN (
              SELECT movieID FROM userWatchList WHERE userID = ?
          )
          AND m.movieID NOT IN (
              SELECT movieID FROM userAntiWatchList WHERE userID = ?
          )
        ORDER BY m.rating DESC
        LIMIT ?;
    """, (user_id, user_id, user_id, limit))
    rows = c.fetchall()
    closeConnection(c, conn)
    return rows

# WATCHLISTS SECTION ===================================================
def add2WatchList(ownerID: int, movieID: int, isGroupList: bool, isAntiList: bool):
    conn, c = openConnection()
    ownerType = "user"
    prefix = ""

    if isGroupList:
        ownerType = "group"
    
    if isAntiList:
        prefix = "Anti"
        
    try:
        commandString = f"INSERT INTO {ownerType}{prefix}WatchList ({ownerType}ID, movieID) \
                        VALUES ({ownerID}, {movieID});"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

def getWatchList(ownerID: int, isGroupList: bool, isAntiList: bool):
    conn, c = openConnection()
    ownerType = "user"
    prefix = ""

    if isGroupList:
        ownerType = "group"
    
    if isAntiList:
        prefix = "Anti"
        
    try:
        commandString = f"SELECT m.movieID, m.title, m.rating, m.release FROM movies m\
                            INNER JOIN {ownerType}{prefix}WatchList w\
                            ON m.movieID = w.movieID\
                            WHERE {ownerType}ID = {ownerID};"
        c.execute(commandString)
        output = c.fetchall()
        closeConnection(c, conn)
        return output
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return []

def createCustomMovie(title: str):
    """
    Insert a new movie with only a title and return its new movieID.
    Other fields are left empty/NULL.
    """
    conn, c = openConnection()
    try:
        # find next movieID = max + 1
        c.execute("SELECT COALESCE(MAX(movieID), 0) + 1 FROM movies;")
        new_id = c.fetchone()[0]

        c.execute(
            "INSERT INTO movies (movieID, title, overview, rating, release) VALUES (?, ?, ?, ?, ?);",
            (new_id, title, "", None, None)
        )

        conn.commit()
        closeConnection(c, conn)
        return new_id
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return None

def removeFromWatchList(ownerID: int, movieID: int, isGroupList: bool, isAntiList: bool):
    conn, c = openConnection()
    ownerType = "user"
    prefix = ""

    if isGroupList:
        ownerType = "group"
    
    if isAntiList:
        prefix = "Anti"
        
    try:
        commandString = f"DELETE FROM {ownerType}{prefix}WatchList \
                            WHERE {ownerType}ID = {ownerID} AND movieID = {movieID};"
        c.execute(commandString)
        conn.commit()
        closeConnection(c, conn)
        return True
    except sqlite3.IntegrityError:
        closeConnection(c, conn)
        return False

# RESETS DATABASE ============================================
# DESTROYS ALL TABLES - DONT USE UNLESS ITS LAST RESORT
def dropTables():
    conn, c = openConnection()
    tableNames = ["userWatchList",
        "userAntiWatchList",
        "groupMovieVotes",
        "groupMovieSuggestions",
        "movieRounds",
        "votingRounds",
        "dateVotes",
        "groupWatchList",
        "groupAntiWatchList",
        "groupEventRelation",
        "userEventRelation",
        "events",
        "genreMovieRelation",
        "groupMemberRelation",
        "groups",
        "movies",
        "users"]

    for table in tableNames:
        commandString = "DROP TABLE IF EXISTS " + table + ";"
        c.execute(commandString)
    
    conn.commit()
    closeConnection(c, conn)
    
def resetDB():
    dropTables()
    createTables()

def test():
    resetDB()
    if not createUser("test", "test", "test@test.com"):
        print("Create Test Failed")
    createUser("test2", "test2", "test2@test.com")


    if not loginUser("test", "test"):
        print("Login Test Failed")
    
    if not createGroup("testGroup", 0):
        print("Create Group Failed")
    
    if not addMember2Group(0, 1):
        print("Add member2Group Failed")
    
    if not getGroups(1):
        print("GetGroups failed")
    
    if not deleteGroup(0):
        print("Delete Group failed")
    
    if not deleteUser(1):
        print("Delete User failed")

if __name__ == "__main__":
    #resetDB()
    #addMovies()
    addGenres()


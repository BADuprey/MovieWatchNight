//
//  AddGroupView.swift
//  sprint_2
//
//
import SwiftUI

struct AddGroupView: View {
    @Environment(\.dismiss) var dismiss
    @State private var groupName = ""
    @State private var isSubmitting = false
    @State private var showError = false
    
    let userID: Int
    let onAdd: () -> Void
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Create a New Group")
                    .font(.title2).bold()
                    .padding(.top)
                
                TextField("Enter group name", text: $groupName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
                
                Button(action: addGroup) {
                    if isSubmitting {
                        ProgressView()
                    } else {
                        Text("Create Group")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(radius: 1, y: 1)
                    }
                }
                .disabled(groupName.isEmpty || isSubmitting)
                .padding(.horizontal)
                
                Spacer()
            }
            .navigationTitle("New Group")
            .alert("Error", isPresented: $showError) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Could not create group. Please try again.")
            }
        }
    }
    
    private func addGroup() {
        isSubmitting = true
        APIService.shared.createGroup(name: groupName, leaderID: userID) { success in
            DispatchQueue.main.async {
                isSubmitting = false
                if success {
                    onAdd()
                    dismiss()
                } else {
                    showError = true
                }
            }
        }
    }
}


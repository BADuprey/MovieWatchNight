//
//  DetailedGroupView.swift
//  sprint_2
//
//
import SwiftUI

struct DetailedGroupView: View {
    let group: Group  // Passed from GroupView

    var body: some View {
        VStack(spacing: 20) {
            Text("Group Detail Page")
                .font(.largeTitle)
                .bold()
            
            Text("Group Name: \(group.name)")
                .font(.title3)
            
            Text("Group ID: \(group.groupID)")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
        }
        .padding()
        .navigationTitle(group.name)
        .background(Color(.systemGray6))
    }
}

#Preview {
    DetailedGroupView(group: Group(groupID: 1, name: "Example Group", leaderID: 1))
}

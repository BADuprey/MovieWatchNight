import SwiftUI

struct InfoView: View {
    @State private var genres: [String] = []
    @State private var isLoading = true
    @State private var message: String?

    var body: some View {
        List {
            if let message = message {
                Text(message)
                    .foregroundColor(.red)
            } else if isLoading {
                Text("Loading genres...")
            } else if genres.isEmpty {
                Text("No genres returned from server.")
                    .foregroundColor(.secondary)
            } else {
                ForEach(genres, id: \.self) { genre in
                    NavigationLink(genre) {
                        GenreMoviesView(genre: genre)
                    }
                }
            }
        }
        .navigationTitle("Genres")
        .onAppear {
            APIService.shared.fetchGenres { result in
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.genres = result
                    if result.isEmpty {
                        self.message = "Got empty list from /genres"
                    }
                }
            }
        }
    }
}

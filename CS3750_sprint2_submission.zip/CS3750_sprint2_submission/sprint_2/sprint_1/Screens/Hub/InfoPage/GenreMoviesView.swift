import SwiftUI

struct GenreMoviesView: View {
    let genre: String
    @State private var movies: [MovieSummary] = []
    @State private var isLoading = true

    var body: some View {
        List {
            if isLoading {
                Text("Loading \(genre) movies...")
            } else if movies.isEmpty {
                Text("No movies found.")
            } else {
                ForEach(movies) { movie in
                    NavigationLink(movie.title) {
                        MovieDetailView(movieID: movie.movieID)
                    }
                }
            }
        }
        .navigationTitle(genre)
        .onAppear {
            APIService.shared.fetchMovies(genre: genre) { result in
                DispatchQueue.main.async {
                    self.movies = result
                    self.isLoading = false
                }
            }
        }
    }
}

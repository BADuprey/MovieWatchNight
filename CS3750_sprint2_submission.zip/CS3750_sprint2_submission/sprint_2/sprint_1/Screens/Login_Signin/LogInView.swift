import SwiftUI

let textFieldColor = Color(red: 200/255, green: 200/255, blue: 255/255, opacity: 0.5)

struct LogInView: View {
    @Binding var isLoggedIn: Bool
    @Binding var currentUsername: String
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var loginFailed = false
    @State private var isLoading = false
    
    var body: some View {
        VStack(alignment: .center) {
            Spacer()
            Text("Log In").font(.title)
            Spacer()
            VStack {
                TextField("Username", text: $username)
                    .background(textFieldColor)
                    .textFieldStyle(.roundedBorder)
                    .border(.black, width: 1)
                
                SecureField("Password", text: $password)
                    .background(textFieldColor)
                    .textFieldStyle(.roundedBorder)
                    .border(.black, width: 1)
            }
            .padding(50)
            
            Spacer()
            
            if loginFailed {
                Text("Login Failed").foregroundColor(.red)
            }
            if isLoading {
                Text("Logging in...")
            }
            
            Spacer()
            Button("Log In", action: handleLogin)
            Spacer()
        }
    }
    
    private func handleLogin() {
        loginFailed = false
        isLoading = true
        
        APIService.shared.login(username: username, password: password) { success in
            DispatchQueue.main.async {
                if success {
                    self.currentUsername = self.username
                    self.isLoggedIn = true
                    self.isLoading = false
                    
                    // then try to fetch the nice name from the backend
                    APIService.shared.fetchUser(username: self.username) { profile in
                        DispatchQueue.main.async {
                            if let profile = profile {
                                self.currentUsername = profile.username
                            }
                        }
                    }
                    
                } else {
                    self.isLoading = false
                    self.loginFailed = true
                }
            }
        }
    }
}

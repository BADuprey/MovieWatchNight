import SwiftUI

struct AccountView: View {
    var body: some View {
        NavigationStack {
            Text("Account info (placeholder)")
                .padding()
                .navigationTitle("Account")
        }
    }
}

#Preview {
    AccountView()
}

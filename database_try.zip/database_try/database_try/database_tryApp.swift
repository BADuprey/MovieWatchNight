import SwiftUI

@main
struct MovieWatchNightApp: App {
    var body: some Scene {
        WindowGroup {
            FirstMovieView()
        }
    }
}

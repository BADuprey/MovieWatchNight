import Foundation
import SQLite3

// I HAVE THE DOCUMENTATION LINKS IN A NOTES APP, I WILL ADD THEM HERE LATER.
struct Movie: Identifiable {
    let id: Int
    let title: String
    let rating: Double?
    let release: String?
}

final class Database {
    static let shared = Database()
    private var db: OpaquePointer?

    //Opening the file
    private init() {
        do {
            let path = try Self.prepareDatabaseFileIfNeeded(resourceName: "movieWatchNight", ext: "db")
            try open(at: path)
        } catch {
            print("DB init error: \(error)")
        }
    }

    private func open(at path: String) throws {
        if sqlite3_open(path, &db) != SQLITE_OK {
            let message = String(cString: sqlite3_errmsg(db))
            throw NSError(domain: "Database", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Failed to open DB: \(message)"])
        }
    }

    // I THUBK I CAN REMOVE THIS BUT IDK YET.
    private static func prepareDatabaseFileIfNeeded(resourceName: String, ext: String) throws -> String {
        let fm = FileManager.default
        let docs = try fm.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let dstURL = docs.appendingPathComponent("\(resourceName).\(ext)")
        if !fm.fileExists(atPath: dstURL.path) {
            guard let srcURL = Bundle.main.url(forResource: resourceName, withExtension: ext) else {
                throw NSError(domain: "Database", code: 2,
                              userInfo: [NSLocalizedDescriptionKey: "Bundled DB not found"])
            }
            try fm.copyItem(at: srcURL, to: dstURL)
        }
        return dstURL.path
    }

    // Simple exec helper
    private func exec(_ sql: String) throws {
        var errmsg: UnsafeMutablePointer<Int8>?
        if sqlite3_exec(db, sql, nil, nil, &errmsg) != SQLITE_OK {
            let message: String
            if let e = errmsg { message = String(cString: e); sqlite3_free(e) } else { message = "Unknown error" }
            throw NSError(domain: "Database", code: 4,
                          userInfo: [NSLocalizedDescriptionKey: "Exec failed: \(message)"])
        }
    }

    // EXMAPLE HERE: Fetch first movie row --> to see how we can get info from the database:
    func fetchFirstMovie() throws -> Movie? {
        let sql = #"SELECT movieID, title, rating, "release" FROM movies ORDER BY movieID LIMIT 1;"#
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }

        if sqlite3_prepare_v2(db, sql, -1, &stmt, nil) != SQLITE_OK {
            let message = String(cString: sqlite3_errmsg(db))
            throw NSError(domain: "Database", code: 3,
                          userInfo: [NSLocalizedDescriptionKey: "Prepare failed: \(message)"])
        }

        if sqlite3_step(stmt) == SQLITE_ROW {
            let id = Int(sqlite3_column_int(stmt, 0))
            let title = String(cString: sqlite3_column_text(stmt, 1))
            let rating: Double? = sqlite3_column_type(stmt, 2) == SQLITE_NULL ? nil : sqlite3_column_double(stmt, 2)
            let releaseStr: String? = sqlite3_column_type(stmt, 3) == SQLITE_NULL ? nil : String(cString: sqlite3_column_text(stmt, 3))
            return Movie(id: id, title: title, rating: rating, release: releaseStr)
        }
        return nil
    }

    //For debugging to see if the DB file is included in the prooject. We wanna see "Found DB in bundle"
    // otherwise the DB file has not been properly added to the project.
    
    func debugCheckDBPresence() {
        if let url = Bundle.main.url(forResource: "movieWatchNight", withExtension: "db") {
            print("Found DB in bundle at: \(url.path)")
        } else {
            print("DB NOT found in bundle")
        }
    }
}

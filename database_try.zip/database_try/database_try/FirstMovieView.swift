import SwiftUI

struct FirstMovieView: View {
    @State private var movie: Movie?
    @State private var errorMessage: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("First Movie").font(.title).bold()

            if let m = movie {
                Text(m.title).font(.headline)
                if let date = m.release, let year = date.split(separator: "-").first {
                    Text("Year: \(year)")
                }
                if let r = m.rating {
                    Text("Rating: \(r)")
                }
                Text("ID: \(m.id)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } else if let err = errorMessage {
                Text("Error: \(err)").foregroundStyle(.red)
            } else {
                Text("No movie found.").foregroundStyle(.secondary)
            }

            Button("Load First Row") {
                load()
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .onAppear {
            Database.shared.debugCheckDBPresence()
            if movie == nil && errorMessage == nil { load() }
        }
    }

    private func load() {
        do {
            movie = try Database.shared.fetchFirstMovie()
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

//
//  database_tryTests.swift
//  database_tryTests
//
//  Created by Sasha Jazmin Abuin on 11/1/25.
//

import Testing
@testable import database_try

struct database_tryTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

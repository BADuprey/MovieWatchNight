import SwiftUI

struct SchedulesView: View {

    enum Mode {
        case user // personal schedule
        case group(name: String) // group schedule
    }

    let ownerID: Int  // userID for personal, groupID for group
    let mode: Mode

    @State private var selectedDate = Date()
    @State private var timeForNew = Date()
    @State private var newTitle: String = ""
    @State private var events: [DBEvent] = []

    // for editing the event
    @State private var editingEvent: DBEvent? = nil
    @State private var editTitle: String = ""
    @State private var editDate: Date = Date()
    @State private var showingEdit = false


    private var navTitle: String {
        switch mode {
        case .user:
            return "Schedules"
        case .group(let name):
            return "\(name) Schedule"
        }
    }

    private var headerTitle: String {
        switch mode {
        case .user:
            return "Movie Night Calendar"
        case .group(let name):
            return "\(name) Calendar"
        }
    }

    private var headerSubtitle: String {
        switch mode {
        case .user:
            return "Pick a day to see what’s playing."
        case .group:
            return "Pick a day to see what this group is watching."
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.93, green: 0.97, blue: 1.0),
                        Color.white
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {

                        // top heading card
                        HStack(alignment: .center, spacing: 10) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(headerTitle)
                                    .font(.title3.bold())
                                    .foregroundColor(.primary)
                                Text(headerSubtitle)
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "calendar.badge.clock")
                                .font(.title2)
                                .foregroundColor(Color(red: 0.12, green: 0.45, blue: 0.9))
                                .padding(10)
                                .background(.white)
                                .clipShape(Circle())
                                .shadow(color: .black.opacity(0.06), radius: 4, y: 2)
                        }
                        .padding()
                        .background(Color.white.opacity(0.7))
                        .background(.ultraThinMaterial)
                        .cornerRadius(18)
                        .shadow(color: .black.opacity(0.03), radius: 5, y: 3)

                        // date picker
                        DatePicker("Select date",
                                   selection: $selectedDate,
                                   displayedComponents: .date)
                            .datePickerStyle(.graphical)
                            .frame(height: 340)
                            .background(.white)
                            .cornerRadius(20)
                            .shadow(color: .black.opacity(0.02), radius: 4, y: 2)

                        // events list
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Movies on this day")
                                .font(.headline)
                                .foregroundColor(.primary)

                            if eventsForSelectedDay.isEmpty {
                                Text("No movies for this day.")
                                    .foregroundColor(.secondary)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(14)
                                    .shadow(color: .black.opacity(0.02), radius: 4, y: 2)
                            } else {
                                VStack(spacing: 10) {
                                    ForEach(eventsForSelectedDay) { event in
                                        HStack(spacing: 12) {
                                            VStack(alignment: .leading, spacing: 2) {
                                                if case .user = mode, let name = event.groupName {
                                                    Text("[Group: \(name)]")
                                                        .font(.caption2)
                                                        .foregroundColor(.secondary)
                                                }

                                                Text(event.title)
                                                    .font(.subheadline.bold())

                                                if let d = parseDate(event.date) {
                                                    Text(timeString(from: d))
                                                        .font(.caption)
                                                        .foregroundColor(.secondary)
                                                }
                                            }

                                            Spacer()

                                            Button {
                                                deleteEvent(event)
                                            } label: {
                                                Image(systemName: "trash")
                                                    .foregroundColor(.red)
                                            }
                                            .buttonStyle(.borderless)
                                        }
                                        .padding()
                                        .background(.white)
                                        .cornerRadius(14)
                                        .shadow(color: .black.opacity(0.02), radius: 4, y: 2)
                                        .onTapGesture {
                                            startEditing(event)
                                        }
                                    }                                }
                            }
                        }

                        // add card
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Add a movie for this day")
                                .font(.headline)

                            TextField("Movie title", text: $newTitle)
                                .padding(10)
                                .background(Color.white)
                                .cornerRadius(10)
                                .shadow(color: .black.opacity(0.01), radius: 2, y: 1)

                            HStack {
                                Text("Time")
                                Spacer()
                                DatePicker("",
                                           selection: $timeForNew,
                                           displayedComponents: .hourAndMinute)
                                    .labelsHidden()
                            }

                            Button(action: addEvent) {
                                HStack {
                                    Image(systemName: "plus.circle.fill")
                                    Text("Add movie")
                                        .fontWeight(.semibold)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(newTitle.isEmpty ? Color.blue.opacity(0.35) : Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(12)
                            }
                            .disabled(newTitle.isEmpty)
                        }
                        .padding()
                        .background(.white)
                        .cornerRadius(18)
                        .shadow(color: .black.opacity(0.02), radius: 5, y: 3)

                        Spacer(minLength: 30)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 16)
                }
            }
            .navigationTitle(navTitle)
            .onAppear {
                loadEvents()
            }
            .sheet(isPresented: $showingEdit) {
                editSheet
            }
        }
    }

    //Editing
    private var editSheet: some View {
        NavigationStack {
            Form {
                Section("Title") {
                    TextField("Title", text: $editTitle)
                }
                Section("Date & time") {
                    DatePicker("When", selection: $editDate)
                }
            }
            .navigationTitle("Edit event")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showingEdit = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { saveEdit() }
                }
            }
        }
    }

    private func startEditing(_ event: DBEvent) {
        editingEvent = event
        editTitle = event.title
        editDate = parseDate(event.date) ?? Date()
        showingEdit = true
    }

    private func saveEdit() {
        guard let event = editingEvent else { return }
        let dateString = formatDate(editDate)

        APIService.shared.updateEvent(
            eventID: event.eventID,
            title: editTitle,
            dateString: dateString
        ) { ok in
            if ok {
                loadEvents()
            }
        }
        showingEdit = false
    }

    //Events for selected day

    private var eventsForSelectedDay: [DBEvent] {
        events
            .filter {
                if let d = parseDate($0.date) {
                    return Calendar.current.isDate(d, inSameDayAs: selectedDate)
                }
                return false
            }
            .sorted {
                guard let d1 = parseDate($0.date), let d2 = parseDate($1.date) else { return false }
                return d1 < d2
            }
    }

    //API CALLS
    private func loadEvents() {
        switch mode {
        case .user:
            APIService.shared.fetchEvents(userID: ownerID) { items in
                DispatchQueue.main.async { self.events = items }
            }
        case .group:
            APIService.shared.fetchGroupEvents(groupID: ownerID) { items in
                DispatchQueue.main.async { self.events = items }
            }
        }
    }

    private func addEvent() {
        guard !newTitle.isEmpty else { return }

        let fullDate = mergeDateAndTime(day: selectedDate, time: timeForNew)
        let dateString = formatDate(fullDate)

        switch mode {
        case .user:
            APIService.shared.addEvent(
                userID: ownerID,
                title: newTitle,
                dateString: dateString
            ) { ok in
                if ok { loadEvents() }
            }

        case .group:
            APIService.shared.addGroupEvent(
                groupID: ownerID,
                title: newTitle,
                dateString: dateString
            ) { ok in
                if ok { loadEvents() }
            }
        }

        newTitle = ""
    }

    private func deleteEvent(_ event: DBEvent) {
        APIService.shared.deleteEvent(eventID: event.eventID) { ok in
            if ok {
                DispatchQueue.main.async {
                    self.events.removeAll { $0.eventID == event.eventID }
                }
            }
        }
    }

    //Date helpers

    private func mergeDateAndTime(day: Date, time: Date) -> Date {
        let cal = Calendar.current
        let d = cal.dateComponents([.year, .month, .day], from: day)
        let t = cal.dateComponents([.hour, .minute], from: time)

        var comps = DateComponents()
        comps.year = d.year
        comps.month = d.month
        comps.day = d.day
        comps.hour = t.hour
        comps.minute = t.minute

        return cal.date(from: comps) ?? day
    }

    private func formatDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm"
        return f.string(from: date)
    }

    private func parseDate(_ s: String) -> Date? {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm"
        return f.date(from: s)
    }

    private func timeString(from date: Date) -> String {
        let f = DateFormatter()
        f.timeStyle = .short
        return f.string(from: date)
    }
}

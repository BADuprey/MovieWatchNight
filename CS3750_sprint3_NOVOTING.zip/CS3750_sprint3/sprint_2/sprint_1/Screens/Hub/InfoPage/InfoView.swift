import SwiftUI

struct InfoView: View {
    // optional movie info coming from Hub
    var movieTitle: String? = nil
    var movieID: Int? = nil

    @State private var genres: [String] = []
    @State private var isLoading = true
    @State private var message: String?

    private let backgroundColor = Color(red: 0.95, green: 0.96, blue: 0.99)

    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()

            List {
                // if we came from the hub with a movie, show it first
                if let movieTitle = movieTitle {
                    Section("Selected movie") {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(movieTitle)
                                .font(.headline)

                            if let movieID = movieID {
                                Text("ID: \(movieID)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }

                            Text("Browse genres below to find similar movies.")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                }

                if let message = message {
                    Section {
                        Text(message)
                            .foregroundColor(.red)
                    }
                } else if isLoading {
                    Section {
                        HStack {
                            ProgressView()
                            Text("Loading genres...")
                        }
                    }
                } else if genres.isEmpty {
                    Section {
                        Text("No genres returned from server.")
                            .foregroundColor(.secondary)
                    }
                } else {
                    Section("Genres") {
                        ForEach(genres, id: \.self) { genre in
                            NavigationLink {
                                GenreMoviesView(genre: genre)
                            } label: {
                                HStack {
                                    Text(genre)
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden) 
            .listStyle(.insetGrouped)
        }
        .navigationTitle(movieTitle == nil ? "Genres" : "Movie info")
        .onAppear {
            APIService.shared.fetchGenres { result in
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.genres = result
                    if result.isEmpty {
                        self.message = "Got empty list from /genres"
                    }
                }
            }
        }
    }
}

import SwiftUI

struct MovieJump: Hashable {
    let genre: String
    let movieID: Int?
    let movieTitle: String
}

struct HubView: View {
    let username: String
    let userID: Int

    @State private var genres: [String] = []
    @State private var currentMovieTitle: String = "Tap the button to get a movie 🎬"
    @State private var currentMovieID: Int? = nil
    @State private var currentMovieGenre: String? = nil
    @State private var isFetchingMovie = false

    // for navigation to GenreMoviesView
    @State private var jumpToGenre: MovieJump?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {

                    // welcome card
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Welcome to Movie Watch Night!")
                            .font(.title3).bold()
                        Text(username.isEmpty ? "Guest" : username)
                            .foregroundColor(Color(red: 0.29, green: 0.55, blue: 0.98))
                            .font(.subheadline)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(16)
                    .shadow(color: Color.black.opacity(0.03), radius: 6, y: 3)

                    // upcoming movie card
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Movie coming up on xx.xx!")
                                .font(.subheadline)
                            Text("From - group name")
                                .font(.subheadline.weight(.semibold))
                        }
                        Spacer()
                        Image(systemName: "paperclip.circle.fill")
                            .foregroundColor(Color(red: 0.29, green: 0.55, blue: 0.98))
                            .font(.title3)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(16)
                    .shadow(color: Color.black.opacity(0.03), radius: 6, y: 3)

                    // buttons row
                    HStack(spacing: 12) {
                        NavigationLink(destination: GroupsView(userID: userID, username: username)) {
                            Text("Groups")
                                .font(.subheadline.bold())
                                .foregroundColor(.primary)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.white)
                                .cornerRadius(14)
                                .shadow(color: Color.black.opacity(0.02), radius: 3, y: 2)
                        }

                        NavigationLink("Info page") {
                            InfoView()
                        }
                        .font(.subheadline.bold())
                        .foregroundColor(.primary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.white)
                        .cornerRadius(14)
                        .shadow(color: Color.black.opacity(0.02), radius: 3, y: 2)
                    }

                    // RANDOM MOVIE CARD
                    Button {
                        // only navigate if we have a genre
                        if let g = currentMovieGenre {
                            jumpToGenre = MovieJump(
                                genre: g,
                                movieID: currentMovieID,
                                movieTitle: currentMovieTitle
                            )
                        }
                    } label: {
                        ZStack {
                            LinearGradient(
                                colors: [
                                    Color(red: 0.11, green: 0.42, blue: 0.87),
                                    Color(red: 0.22, green: 0.74, blue: 0.95)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                            .cornerRadius(20)
                            .shadow(color: Color(red: 0.11, green: 0.42, blue: 0.87).opacity(0.35),
                                    radius: 10, y: 6)

                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    HStack(spacing: 4) {
                                        Image(systemName: "sparkles")
                                        Text("Random movie")
                                    }
                                    .font(.caption.bold())
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 4)
                                    .background(Color.white.opacity(0.18))
                                    .clipShape(Capsule())

                                    Spacer()
                                    Text("🍿")
                                        .font(.title2)
                                }

                                Text(currentMovieTitle)
                                    .foregroundColor(.white)
                                    .font(.title3.weight(.semibold))
                                    .multilineTextAlignment(.leading)

                                Button(action: loadRandomMovie) {
                                    HStack(spacing: 6) {
                                        Image(systemName: "film.fill")
                                        if isFetchingMovie {
                                            ProgressView().tint(.white)
                                        } else {
                                            Text("Show me a movie!")
                                        }
                                    }
                                    .font(.subheadline.bold())
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 9)
                                    .background(Color.white.opacity(0.22))
                                    .foregroundColor(.white)
                                    .clipShape(Capsule())
                                }
                                .buttonStyle(.plain)
                            }
                            .padding(18)
                        }
                    }
                    .buttonStyle(.plain)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)

                    Spacer(minLength: 20)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
            }
            .background(Color(red: 0.95, green: 0.96, blue: 0.99))
            .navigationTitle("Hub")
         
            .navigationDestination(item: $jumpToGenre) { info in
                GenreMoviesView(
                    genre: info.genre,
                    preselectedMovieID: info.movieID
                )
            }
        }
        .onAppear {
            loadGenresIfNeeded()
        }
    }

// functions
    private func loadGenresIfNeeded() {
        guard genres.isEmpty else { return }
        APIService.shared.fetchGenres { result in
            DispatchQueue.main.async {
                self.genres = result
            }
        }
    }

    private func loadRandomMovie() {
        guard !genres.isEmpty else {
            currentMovieTitle = "No genres available"
            currentMovieID = nil
            currentMovieGenre = nil
            return
        }

        isFetchingMovie = true
        let genre = genres.randomElement() ?? genres[0]

        APIService.shared.fetchMovies(genre: genre) { movies in
            DispatchQueue.main.async {
                self.isFetchingMovie = false
                if movies.isEmpty {
                    self.currentMovieTitle = "No movies found in \(genre)"
                    self.currentMovieID = nil
                    self.currentMovieGenre = genre
                } else {
                    let movie = movies.randomElement()!
                    self.currentMovieTitle = movie.title
                    self.currentMovieID = movie.movieID
                    self.currentMovieGenre = genre 
                }
            }
        }
    }
}

import SwiftUI

struct DateVoteView: View {
    let group: Group
    let round: VotingRoundInfo
    let currentUserID: Int

    @Environment(\.dismiss) private var dismiss
    @State private var selectedDate = Date()
    @State private var isSubmitting = false
    @State private var errorMessage: String?

    var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 24) {
                    // Header card
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Vote on a Date")
                            .font(.title2.bold())
                            .foregroundColor(.primary)
                        
                        Text("Movie: \(round.movieTitle)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white.opacity(0.95))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.04), radius: 5, y: 3)
                    .padding(.horizontal)
                    .padding(.top, 8)
                    
                    // Date picker card
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Pick a date")
                            .font(.subheadline.bold())
                            .foregroundColor(.primary)
                        
                        DatePicker(
                            "",
                            selection: $selectedDate,
                            displayedComponents: .date
                        )
                        .datePickerStyle(.graphical)
                        .background(Color.white)
                        .cornerRadius(18)
                    }
                    .padding()
                    .background(Color.white.opacity(0.95))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.03), radius: 5, y: 3)
                    .padding(.horizontal)
                    
                    if let errorMessage {
                        Text(errorMessage)
                            .font(.footnote)
                            .foregroundColor(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal)
                    }
                    
                    // Submit button
                    Button(action: submitVote) {
                        HStack {
                            if isSubmitting {
                                ProgressView()
                            } else {
                                Image(systemName: "paperplane.fill")
                                Text("Submit Date Vote")
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple.opacity(0.9))
                        .foregroundColor(.white)
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.18), radius: 6, y: 3)
                    }
                    .disabled(isSubmitting)
                    .padding(.horizontal)
                    
                    Spacer(minLength: 30)
                }
            }
        }
        .navigationTitle("Pick a Date")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func submitVote() {
        isSubmitting = true
        errorMessage = nil

        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let dateString = formatter.string(from: selectedDate)

        APIService.shared.voteForDate(
            roundID: round.roundID,
            userID: currentUserID,
            dateChoice: dateString
        ) { success in
            DispatchQueue.main.async {
                isSubmitting = false
                if success {
                    dismiss()
                } else {
                    errorMessage = "You might have already voted for this round."
                }
            }
        }
    }
}

import SwiftUI

struct SuggestMovieView: View {
    let group: Group
    let currentUserID: Int

    @Environment(\.dismiss) private var dismiss
    @State private var movieTitle: String = ""
    @State private var isSubmitting = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 20) {
            Text("Suggest a Movie")
                .font(.largeTitle)
                .bold()

            Text("Group: \(group.name)")
                .foregroundColor(.secondary)

            TextField("Enter movie title", text: $movieTitle)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)

            if let errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
            }

            Button(action: submitSuggestion) {
                if isSubmitting {
                    ProgressView()
                } else {
                    Text("Submit Suggestion")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(radius: 1, y: 1)
                }
            }
            .disabled(movieTitle.trimmingCharacters(in: .whitespaces).isEmpty || isSubmitting)
            .padding(.horizontal)

            Spacer()
        }
        .padding(.top, 30)
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Suggest Movie")
    }

    private func submitSuggestion() {
        isSubmitting = true
        errorMessage = nil

        APIService.shared.suggestMovie(groupID: group.groupID, userID: currentUserID, movieTitle: movieTitle) { success in
            DispatchQueue.main.async {
                isSubmitting = false
                if success {
                    dismiss()
                } else {
                    errorMessage = "You have already voted this round."
                }
            }
        }
    }
}

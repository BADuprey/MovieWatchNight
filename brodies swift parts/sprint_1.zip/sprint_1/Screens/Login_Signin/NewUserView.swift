import SwiftUI

struct NewUserView: View {
    @State private var username: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var confirmedPassword: String = ""

    @State private var showWarning = false
    @State private var warningText = ""
    @State private var isLoading = false
    @State private var signupOK = false

    var body: some View {
        VStack {
            Text("New User").font(.title)
            Spacer()

            TextField("Username", text: $username)
                .background(textFieldColor)
                .textFieldStyle(.roundedBorder)
                .border(.black, width: 1)

            TextField("Email", text: $email)
                .background(textFieldColor)
                .textFieldStyle(.roundedBorder)
                .border(.black, width: 1)

            SecureField("Password", text: $password)
                .background(textFieldColor)
                .textFieldStyle(.roundedBorder)
                .border(.black, width: 1)

            SecureField("Confirm Password", text: $confirmedPassword)
                .background(textFieldColor)
                .textFieldStyle(.roundedBorder)
                .border(.black, width: 1)

            if showWarning {
                Text(warningText).foregroundColor(.red)
            }

            if signupOK {
                Text("Account created!").foregroundColor(.green)
            }

            if isLoading {
                Text("Creating user...")
            }

            Spacer()

            Button("Sign Up", action: makeUser)
        }
        .padding(50)
    }

    private func makeUser() {
        showWarning = false
        signupOK = false

        guard !username.isEmpty, !email.isEmpty, !password.isEmpty else {
            showWarning = true
            warningText = "Please fill in all fields"
            return
        }

        guard password == confirmedPassword else {
            showWarning = true
            warningText = "Passwords do not match"
            return
        }

        isLoading = true
        APIService.shared.signup(username: username, password: password, email: email) { success in
            DispatchQueue.main.async {
                self.isLoading = false
                if success {
                    self.signupOK = true
                } else {
                    self.showWarning = true
                    self.warningText = "Username already taken or server error"
                }
            }
        }
    }
}

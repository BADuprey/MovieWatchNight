import SwiftUI

struct PopcornSplashView: View {
    @State private var kernels: [FallingPopcorn] = []
    @State private var showTitle = false
    let onDone: () -> Void
    

    var body: some View {
        ZStack {
            // background
            LinearGradient(
                colors: [
                    Color(red: 0.10, green: 0.22, blue: 0.50),
                    Color(red: 0.25, green: 0.45, blue: 0.80),
                    Color(red: 0.70, green: 0.82, blue: 1.0)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            // falling popcorn
            ZStack {
                ForEach(kernels) { kernel in
                    PopcornFallingView(kernel: kernel)
                }
            }

            // title after
            if showTitle {
                Text("Movie Watch Night")
                    .font(.system(size: 34, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .shadow(radius: 6)
            }
        }
        .onAppear {
            startSpawning()
        }
    }

    private func startSpawning() {
        let screenWidth = UIScreen.main.bounds.width
        let screenHeight = UIScreen.main.bounds.height

        // spawn lots of popcorns
        for i in 0..<25 {
            let delay = Double(i) * 0.08
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                let x = CGFloat.random(in: 20...(screenWidth - 20))
                let size = CGFloat.random(in: 70...130)
                let duration = Double.random(in: 1.0...1.7)

                let kernel = FallingPopcorn(
                    id: UUID(),
                    x: x,
                    startY: -160,
                    endY: screenHeight + 180,
                    size: size,
                    duration: duration
                )
                kernels.append(kernel)
            }
        }

        // show title
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation(.spring()) {
                showTitle = true
            }
        }

        // go to the actual app
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            onDone()
        }
    }
}

//Helpers
struct FallingPopcorn: Identifiable {
    let id: UUID
    let x: CGFloat
    let startY: CGFloat
    let endY: CGFloat
    let size: CGFloat
    let duration: Double
}

struct PopcornFallingView: View {
    let kernel: FallingPopcorn
    @State private var y: CGFloat = 0
    @State private var opacity: Double = 1

    var body: some View {
        Image("popcorn")
            .resizable()
            .scaledToFit()
            .frame(width: kernel.size, height: kernel.size)
            .position(x: kernel.x, y: y)
            .opacity(opacity)
            .onAppear {
                y = kernel.startY
                withAnimation(.easeOut(duration: kernel.duration)) {
                    y = kernel.endY
                    opacity = 0
                }
            }
    }
}

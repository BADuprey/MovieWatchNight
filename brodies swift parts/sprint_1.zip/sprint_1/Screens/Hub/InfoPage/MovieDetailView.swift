import SwiftUI

struct MovieDetailView: View {
    let movieID: Int
    @State private var detail: MovieDetail?
    @State private var isLoading = true

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if isLoading {
                Text("Loading...")
            } else if let detail = detail {
                Text(detail.title)
                    .font(.title)
                if let rating = detail.rating {
                    Text("Rating: \(String(format: "%.1f", rating))")
                }
                if let release = detail.release {
                    Text("Release: \(release)")
                }
                if let overview = detail.overview {
                    Text(overview)
                        .padding(.top, 8)
                } else {
                    Text("No overview available.")
                        .foregroundColor(.secondary)
                }
            } else {
                Text("Movie not found")
            }
            Spacer()
        }
        .padding()
        .navigationTitle("Movie")
        .onAppear {
            APIService.shared.fetchMovieDetail(id: movieID) { result in
                DispatchQueue.main.async {
                    self.detail = result
                    self.isLoading = false
                }
            }
        }
    }
}

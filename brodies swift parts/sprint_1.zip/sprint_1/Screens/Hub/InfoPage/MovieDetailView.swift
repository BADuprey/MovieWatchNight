import SwiftUI

struct MovieDetailView: View {
    let movieID: Int
    @State private var detail: MovieDetail?
    @State private var isLoading = true
    
    var userID: Int
    @State private var groups: [Group] = []

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if isLoading {
                Text("Loading...")
            } else if let detail = detail {
                Text(detail.title)
                    .font(.title)
                if let rating = detail.rating {
                    Text("Rating: \(String(format: "%.1f", rating))")
                }
                if let release = detail.release {
                    Text("Release: \(release)")
                }
                if let overview = detail.overview {
                    Text(overview)
                        .padding(.top, 8)
                } else {
                    Text("No overview available.")
                        .foregroundColor(.secondary)
                }
            } else {
                Text("Movie not found")
            }
            Spacer()
            
            ScrollView{
                // UserWatchLists
                WatchListRow(ownerID: userID, movieID: detail!.id, isGroupList: false)
                
                // GroupWatchLists
                VStack{
                    ForEach(groups) { group in
                        WatchListRow(ownerID: group.id, movieID: detail!.id, isGroupList: true, groupName: group.name)
                    }
                }
            }
            
        }
        .padding()
        .navigationTitle("Movie")
        .onAppear {
            APIService.shared.fetchMovieDetail(id: movieID) { result in
                DispatchQueue.main.async {
                    self.detail = result
                }
            }
            APIService.shared.fetchGroups(userID: userID) { fetchedGroups in
                self.groups = fetchedGroups
                self.isLoading = false
            }
        }
    }
}

struct WatchListButton: View {
    var ownerID: Int
    var movieID: Int
    var isGroupList: Bool
    var isAntiList: Bool
    var groupName: String = ""
    @State private var buttonLabel: String = "Add to "
    
    var body: some View {
        Button(action: addToWatchList) {Text(buttonLabel)}.onAppear(perform: generateLabel)
    }
    
    private func addToWatchList(){
        APIService.shared.add2WatchList(ownerID: ownerID, movieID: movieID, isGroupList: isGroupList, isAntiList: isAntiList, completion: { _ in })
        buttonLabel = "Added!"
    }
    
    
    private func generateLabel(){
        if isGroupList{
            buttonLabel += groupName + " "
        } else {
            buttonLabel += "Your "
        }
        
        if isAntiList{
            buttonLabel += "Anti "
        }
        buttonLabel += "List"
    }
}

struct WatchListRow: View {
    var ownerID: Int
    var movieID: Int
    var isGroupList: Bool
    var groupName: String = ""
    
    var body: some View {
        HStack{
            WatchListButton(ownerID: ownerID, movieID: movieID, isGroupList: isGroupList, isAntiList: false, groupName: groupName)
            WatchListButton(ownerID: ownerID, movieID: movieID, isGroupList: isGroupList, isAntiList: true, groupName: groupName)
        }
    }
}

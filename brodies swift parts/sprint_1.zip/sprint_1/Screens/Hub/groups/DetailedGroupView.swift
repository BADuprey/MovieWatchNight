import SwiftUI
import UIKit

struct DetailedGroupView: View {
    let group: Group  // Passed from GroupView
    @State var members: [UserProfile] = []
    @State var showingAlert = false
    @State var currentMember: UserProfile!
    @State var isLoading = false
    @State private var copyButtonLabel = "Link to Add Members"
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Group Detail Page")
                .font(.largeTitle)
                .bold()
            
            Text("Group Name: \(group.name)")
                .font(.title3)
            
            Text("Group ID: \(group.groupID)")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
        }
        .padding()
        .navigationTitle(group.name)
        .background(Color(.systemGray6))
        
        Button(action: copyLinkToClipboard) {Text(copyButtonLabel)}
        
        List(members) {member in
            memberListRow(memberName: member.username).swipeActions(edge: .trailing) {Button("Remove?", action: {showingAlert = true; currentMember = member})}
        }.listStyle(PlainListStyle()).alert(currentMember == nil ? "Remove?" : "Remove \(currentMember.username)?", isPresented: $showingAlert) {
            Button("Confirm", role: .destructive) {
                removeMember(member: currentMember) }
            Button("Cancel", role: .cancel) {}
        }
        
        Version1(ownerID: group.groupID, isGroupList: true)
    }
    
    private func copyLinkToClipboard(){
        UIPasteboard.general.string = ServerConfig.shared.baseURLString + "/joinGroup/" + String(group.groupID)
        copyButtonLabel = "Link Copied!"
    }
    
    private func removeMember(member: UserProfile){
        isLoading = true
        APIService.shared.removeMemberFromGroup(groupID: group.groupID, userID: currentMember.userID) { result in
            DispatchQueue.main.async {
                isLoading = false
                loadMembers()
            }
        }
    }
    
    private func loadMembers() {
        isLoading = true
        APIService.shared.fetchGroupMembers(groupID: group.groupID) { members in
            DispatchQueue.main.async {
                self.members = members
                self.isLoading = false
            }
        }
    }
}

struct memberListRow: View {
    var memberName: String
    var body: some View{
        Text(memberName)
    }
}


#Preview {
    DetailedGroupView(group: Group(groupID: 1, name: "Example Group", leaderID: 1))
}
